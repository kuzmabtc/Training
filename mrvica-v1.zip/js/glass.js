// Pozadina: mekane pastelne mrlje boja koje lagano dišu i reagiraju na dodir.
// Crta se na malenom canvasu koji preglednik razvuče, pa je jeftino i na iPhoneu.

const dark = () => window.matchMedia('(prefers-color-scheme: dark)').matches;
let canvas = null;

// Živa pozadina: mekane pastelne kugle (blush, lavanda, kadulja) koje lagano "dišu".
// Na svaki dodir kugle se opružno povuku prema točki dodira, iz nje krene mekani val,
// pa se sve vrati u disanje. Crta se na pola rezolucije jer je ionako mutno (štedi bateriju).

// [x, y (udio ekrana), radijus (udio veće stranice), boja svijetlo, boja tamno]
const ORBS = [
  [0.08, 0.06, 0.62, [246, 166, 192, 0.62], [214, 92, 140, 0.34]],   // blush
  [0.96, 0.14, 0.56, [196, 180, 244, 0.62], [138, 112, 226, 0.34]],  // lavanda
  [0.16, 0.56, 0.58, [178, 216, 190, 0.55], [92, 160, 122, 0.22]],   // kadulja
  [0.92, 0.66, 0.52, [250, 190, 210, 0.50], [214, 92, 140, 0.24]],   // blush 2
  [0.46, 0.98, 0.60, [214, 202, 248, 0.55], [120, 100, 210, 0.22]],  // lavanda 2
  [0.62, 0.34, 0.34, [255, 226, 214, 0.55], [240, 180, 150, 0.10]],  // topli sjaj
];
const state = ORBS.map(() => ({ x: 0, y: 0, vx: 0, vy: 0, s: 0, vs: 0 }));
const ripples = [];
let t0 = performance.now();
let lastT = t0;
let energy = 0;
// vrlo mala rezolucija: gradijenti su ionako mutni, a crtanje i slanje na GPU je skoro besplatno
const SCALE = 0.2;

function rgba([r, g, b, a], k = 1) { return `rgba(${r},${g},${b},${(a * k).toFixed(3)})`; }

function step(now) {
  const dt = Math.min(0.05, Math.max(0.001, (now - lastT) / 1000));
  lastT = now;
  const W = window.innerWidth, H = window.innerHeight;
  const tt = (now - t0) / 1000;
  energy = 0;
  state.forEach((o, i) => {
    // cilj = disanje (polagani lissajous) ; opruga: mekana i malo "želatinasta"
    const tx = Math.sin(tt * 0.11 + i * 1.7) * W * 0.07;
    const ty = Math.cos(tt * 0.09 + i * 2.3) * H * 0.045;
    const ts = Math.sin(tt * 0.35 + i) * 0.05;
    const k = 38, c = 7.5;
    for (let n = 0; n < 3; n++) {
      const h = dt / 3;
      o.vx += (-k * (o.x - tx) - c * o.vx) * h; o.x += o.vx * h;
      o.vy += (-k * (o.y - ty) - c * o.vy) * h; o.y += o.vy * h;
      o.vs += (-60 * (o.s - ts) - 9 * o.vs) * h; o.s += o.vs * h;
    }
    energy += Math.abs(o.vx) + Math.abs(o.vy) + Math.abs(o.vs) * 400;
  });
  for (let i = ripples.length - 1; i >= 0; i--) if (now - ripples[i].t > 1400) ripples.splice(i, 1);
}

export function paintBackdrop(time = performance.now()) {
  canvas = canvas || document.getElementById('backdrop');
  if (!canvas) return;
  const W = window.innerWidth, H = window.innerHeight;
  const cw = Math.max(1, Math.round(W * SCALE)), ch = Math.max(1, Math.round(H * SCALE));
  if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
  const ctx = canvas.getContext('2d');
  ctx.setTransform(SCALE, 0, 0, SCALE, 0, 0);
  const d = dark();
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = d ? '#141116' : '#FBF5F3';
  ctx.fillRect(0, 0, W, H);
  const size = Math.max(W, H * 0.62, 430);
  ORBS.forEach(([x0, y0, r, cl, cd], i) => {
    const o = state[i];
    const x = x0 * W + o.x, y = y0 * H + o.y;
    const R = r * size * (1 + o.s);
    const col = d ? cd : cl;
    const g = ctx.createRadialGradient(x, y, 0, x, y, R);
    g.addColorStop(0, rgba(col));
    g.addColorStop(0.45, rgba(col, 0.55));
    g.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  });
  // val iz točke dodira: mekani prsten + kratki sjaj u središtu
  for (const rp of ripples) {
    const p = Math.min(1, (time - rp.t) / 1400);
    const e = 1 - Math.pow(1 - p, 3);
    const R = 30 + e * size * 0.75;
    const a = (1 - p) * (d ? 0.22 : 0.5);
    const w = 70 + e * 90;
    const g = ctx.createRadialGradient(rp.x, rp.y, Math.max(0, R - w), rp.x, rp.y, R + w * 0.4);
    const tint = d ? '255,170,205' : '255,255,255';
    g.addColorStop(0, `rgba(${tint},0)`);
    g.addColorStop(0.7, `rgba(${tint},${a.toFixed(3)})`);
    g.addColorStop(1, `rgba(${tint},0)`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    if (p < 0.5) {
      const ga = (1 - p * 2) * (d ? 0.18 : 0.35);
      const gg = ctx.createRadialGradient(rp.x, rp.y, 0, rp.x, rp.y, 140);
      gg.addColorStop(0, d ? `rgba(243,131,168,${ga})` : `rgba(246,166,192,${ga})`);
      gg.addColorStop(1, 'rgba(246,166,192,0)');
      ctx.fillStyle = gg;
      ctx.fillRect(0, 0, W, H);
    }
  }
}

// Dodir: kugle se povuku prema prstu (bliže = jače), malo nabubre, krene val.
export function pulse(px, py) {
  const W = window.innerWidth, H = window.innerHeight;
  const size = Math.max(W, H * 0.62, 430);
  ORBS.forEach(([x0, y0], i) => {
    const o = state[i];
    const dx = px - (x0 * W + o.x), dy = py - (y0 * H + o.y);
    const dist = Math.hypot(dx, dy) || 1;
    const f = Math.exp(-dist / (size * 0.55));
    const pull = Math.min(dist, 260) * 3.2 * f;
    o.vx += (dx / dist) * pull;
    o.vy += (dy / dist) * pull;
    o.vs += 0.9 * f;
  });
  ripples.push({ x: px, y: py, t: performance.now() });
  if (ripples.length > 4) ripples.shift();
  wake();
}

let wakeFn = null;
const wake = () => wakeFn?.();

// Petlja: ~30 fps dok traje val, ~8 fps dok samo diše, stoji kad je aplikacija skrivena.
function animateMesh() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  let last = 0, raf = 0;
  const frame = (now) => {
    raf = 0;
    if (document.hidden) return;
    const busy = ripples.length > 0 || energy > 6;
    if (now - last > (busy ? 32 : 120)) {
      step(now);
      paintBackdrop(now);
      last = now;
    }
    raf = requestAnimationFrame(frame);
  };
  wakeFn = () => { if (!raf) { lastT = performance.now(); raf = requestAnimationFrame(frame); } };
  document.addEventListener('visibilitychange', () => { if (!document.hidden) wakeFn(); });
  document.addEventListener('pointerdown', (e) => { if (e.isPrimary !== false) pulse(e.clientX, e.clientY); }, { passive: true, capture: true });
  wakeFn();
}

// Bez WebGL-a: staklo na trakama je obični CSS (backdrop-filter), što iPhone radi glatko.
export async function initGlass() {
  paintBackdrop();
  animateMesh();
  let rt;
  window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(paintBackdrop, 150); });
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => paintBackdrop());
  const solid = window.matchMedia('(prefers-reduced-transparency: reduce)').matches || window.matchMedia('(prefers-contrast: more)').matches;
  if (solid) { document.body.classList.add('glass-solid'); return 'solid'; }
  return 'css';
}

export const glassChanged = () => {};
