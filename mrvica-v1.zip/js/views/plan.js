// Plan: raspored (ovaj i sljedeći tjedan), sve vježbe i spremljeno, na jednom mjestu.

import { PHASES } from '../data.js';
import { store } from '../store.js';
import { sessionFor, startMonday, weekOf, TOTAL_WEEKS, sessionColor } from '../engine.js';
import { icon } from '../ui/icons.js';
import { segmented, safetyCard } from '../ui/components.js';
import { addDays, today, keyOf, esc, fmtShort, DAYS_MON } from '../util.js';
import { DELOAD_WEEKS } from '../data.js';
import { renderList as renderExercises } from './exercises.js';
import { render as renderSaved } from './saved.js';
import { stagger } from '../motion.js';

export const title = 'Plan';

let mode = 'raspored';
let openWeek = null;
let showAll = false;

export const setMode = (m) => { mode = m; };

const MODES = [{ id: 'raspored', name: 'Raspored' }, { id: 'vjezbe', name: 'Vježbe' }, { id: 'spremljeno', name: 'Spremljeno' }];

function head() {
  const w = Math.max(1, Math.min(TOTAL_WEEKS, weekOf(today())));
  const ph = PHASES.find((p) => w >= p.from && w <= p.to) || PHASES[0];
  return `<header class="large-head"><p class="eyebrow">Tjedan ${w} od ${TOTAL_WEEKS} · ${esc(ph.name)}</p><h1 class="large-title">Plan</h1></header>
    ${segmented('mode', MODES, mode, 'Prikaz')}`;
}

function weekCard(w, curWeek, t, done, mon) {
  const wMon = addDays(mon, (w - 1) * 7);
  const days = Array.from({ length: 7 }, (_, i) => sessionFor(addDays(wMon, i)));
  const planned = days.filter((d) => d.type !== 'rest');
  const completed = planned.filter((d) => done[d.key]).length;
  const isCur = w === curWeek;
  const isOpen = w === openWeek;
  return `
    <article class="glass-card week ${isCur ? 'current' : ''} ${isOpen ? 'open' : ''}">
      <button class="week-head" data-week="${w}" aria-expanded="${isOpen}">
        <span class="lr-main">
          <span class="week-title">Tjedan ${w}${isCur ? ' <span class="pill pill-rose">sad</span>' : ''}${DELOAD_WEEKS.includes(w) ? ' <span class="pill pill-sage">lakši</span>' : ''}</span>
          <span class="lr-sub">${fmtShort(wMon)} – ${fmtShort(addDays(wMon, 6))}</span>
        </span>
        <span class="week-count tabular">${completed}/${planned.length}</span>
        ${icon('chevron', 'chev rot')}
      </button>
      ${isOpen ? `<div class="list-group inset">
        ${days.map((d, i) => `<button class="list-row tappable" data-day="${d.key}">
          <span class="day-dot dd-${sessionColor(d.type)} ${done[d.key] ? 'done' : ''}" aria-hidden="true">${done[d.key] ? icon('check') : ''}</span>
          <span class="lr-main"><span class="lr-label">${DAYS_MON[i]}${keyOf(d.date) === keyOf(t) ? ' · danas' : ''}</span>
            <span class="lr-sub">${esc(d.title)}${d.type !== 'rest' ? ` · ${d.minutes} min` : ''}</span></span>
          ${done[d.key] ? '<span class="sr-only">odrađeno</span>' : ''}
          ${icon('chevron', 'chev')}
        </button>`).join('')}
      </div>` : ''}
    </article>`;
}

export function render(el) {
  if (mode === 'vjezbe') {
    el.innerHTML = `${head()}<div class="sub"></div>`;
    renderExercises(el.querySelector('.sub'));
    bindMode(el);
    return;
  }
  if (mode === 'spremljeno') {
    el.innerHTML = `${head()}<div class="sub"></div>`;
    renderSaved(el.querySelector('.sub'), { embedded: true });
    bindMode(el);
    return;
  }
  const t = today();
  const curWeek = Math.max(1, Math.min(TOTAL_WEEKS, weekOf(t)));
  if (openWeek == null) openWeek = curWeek;
  const done = store.get().done;
  const mon = startMonday();
  // jednostavno: prikazan je samo ovaj i sljedeći tjedan, ostalo na jedan dodir
  const list = showAll ? Array.from({ length: TOTAL_WEEKS }, (_, i) => i + 1) : [curWeek, curWeek + 1].filter((w) => w <= TOTAL_WEEKS);
  const ph = PHASES.find((p) => curWeek >= p.from && curWeek <= p.to) || PHASES[0];

  el.innerHTML = `
    ${head()}
    <article class="glass-card phase-card">
      <p class="body-text"><b>${esc(ph.name)}:</b> ${esc(ph.short)}</p>
      <div class="legend">
        <span><i class="lg lg-rose"></i>Snaga pon, sri, pet</span>
        <span><i class="lg lg-lilac"></i>Šetnja uto, sub</span>
        <span><i class="lg lg-sage"></i>Odmor čet, ned</span>
      </div>
    </article>
    ${list.map((w) => weekCard(w, curWeek, t, done, mon)).join('')}
    <button class="btn btn-tinted all-weeks" data-allweeks>${showAll ? 'Prikaži manje' : `Svih ${TOTAL_WEEKS} tjedana`}</button>
    ${safetyCard()}`;

  bindMode(el);
  el.querySelector('[data-allweeks]').addEventListener('click', () => { showAll = !showAll; render(el); });
  el.querySelectorAll('[data-week]').forEach((b) => b.addEventListener('click', () => {
    const w = +b.dataset.week;
    openWeek = openWeek === w ? 0 : w;
    render(el);
  }));
}

function bindMode(el) {
  el.querySelector('[data-seg="mode"]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-val]');
    if (!b || b.dataset.val === mode) return;
    mode = b.dataset.val;
    render(el);
    stagger(el.querySelectorAll('.week, .ex-card, .sub > .stack > *'), { step: 25 });
  });
}
