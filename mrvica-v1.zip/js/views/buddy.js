// Buddy: razgovor s Mrvicom u stilu Messages. Jedan mozak na backendu (Val Town) za web i Telegram:
// ista povijest, isto pamćenje, iste brojke. Tekst modela prikazujemo samo kroz textContent.
// Bez backenda (ili kad nije dostupan) radi lokalni način s provjerenim odgovorima.

import { BUDDY_CHIPS } from '../data.js';
import { store, addChat, addMemory } from '../store.js';
import { Mascot, NAME } from '../mascot.js';
import { parseReply, visibleText, detectCare, careReply, localReply, openingLine, weeklyRecap, painExercise, validateAction, ERROR_TEXT } from '../ai.js';
import { configured, chat as apiChat, getHistory, addMemoryApi, getMemory } from '../api.js';
import { syncStats } from '../sync.js';
import { runAction, actionLabel } from '../actions.js';
import { weekOf } from '../engine.js';
import { openSheet } from '../ui/sheet.js';
import { toast } from '../ui/feedback.js';
import { icon } from '../ui/icons.js';
import { animate, reduced, tick } from '../motion.js';
import { today, keyOf, haptic } from '../util.js';

export const title = 'Buddy';
export const live = true; // ovaj ekran sam osvježava poruke (zbog streaminga i povlačenja povijesti)

let el = null, list = null, head = null, status = null, busy = false, pollT = null;
let online = null; // null = još ne znamo, true/false nakon zadnjeg poziva

const nearBottom = () => !el || el.scrollHeight - el.scrollTop - el.clientHeight < 160;
function toBottom(force) {
  if (!el || !(force || nearBottom())) return;
  const go = () => el.scrollTo({ top: el.scrollHeight, behavior: reduced() ? 'auto' : 'smooth' });
  go();
  // ponovno nakon što se mjehurić "otvori" (animacija mijenja visinu), da zadnja poruka bude cijela vidljiva
  requestAnimationFrame(go);
  setTimeout(go, 420);
}

// ── Povijest: spajanje lokalnog cachea i backenda bez duplikata ──

const sig = (m) => `${m.role}|${String(m.text || '').trim().slice(0, 160)}`;

function merge(server) {
  const cache = store.get().chat;
  // dodatke koje backend ne vraća (gumbi, izraz) prenosimo s lokalne kopije iste poruke
  const extras = new Map();
  for (const m of cache) if (m.role === 'buddy' && (m.actions?.length || m.mood || m.quick)) extras.set(sig(m), m);
  const srv = server.map((m) => {
    const x = extras.get(sig(m));
    return x ? { ...m, actions: x.actions || [], mood: m.mood || x.mood, quick: x.quick } : m;
  });
  const oldest = srv.length ? srv[0].ts : Infinity;
  const srvSigs = new Set(srv.map(sig));
  const olderServer = cache.filter((m) => m.sid && m.ts < oldest);
  const locals = cache.filter((m) => !m.sid && !m.ephemeral && !m.synced && !srvSigs.has(sig(m)));
  const seen = new Set();
  const merged = [...olderServer, ...srv, ...locals]
    .sort((a, b) => a.ts - b.ts)
    .filter((m) => (seen.has(m.id) ? false : (seen.add(m.id), true)))
    .slice(-100);
  const changed = merged.length !== cache.length || merged.some((m, i) => m.id !== cache[i]?.id);
  if (changed) store.set({ chat: merged });
  return changed;
}

export async function refresh({ quiet = true } = {}) {
  if (!configured() || busy) return false;
  try {
    const server = await getHistory(50);
    setOnline(true);
    let changed = merge(server);
    if (!server.length && !store.get().chat.length) { ensureLocalMessages(true); changed = true; }
    if (changed && list?.isConnected) rebuild();
    updateUnread();
    return changed;
  } catch {
    setOnline(false);
    if (!store.get().chat.length) { ensureLocalMessages(true); if (list?.isConnected) rebuild(); }
    if (!quiet) toast(ERROR_TEXT);
    return false;
  }
}

// Lokalne poruke samo kad nema backenda (backend sam šalje pregled tjedna i podsjetnike na Telegram).
function ensureLocalMessages(serverEmpty = false) {
  const st = store.get();
  const b = st.buddy || {};
  const k = keyOf(today());
  const patch = { ...b };
  const add = [];
  if (!configured()) {
    const w = weekOf(today());
    if (w >= 2 && b.recapWeek !== w - 1) {
      const r = weeklyRecap();
      if (r) add.push({ role: 'buddy', ...r });
      patch.recapWeek = w - 1;
    }
  }
  const todayBuddy = st.chat.some((m) => m.role === 'buddy' && keyOf(new Date(m.ts)) === k);
  // pozdrav: bez backenda svaki dan; s backendom samo kad je i povijest na backendu prazna (bez izmišljenih brojki)
  if (!configured() && b.lastOpen !== k) {
    if (!todayBuddy) add.push({ role: 'buddy', ...openingLine(), kind: 'opening' });
    patch.lastOpen = k;
  }
  if (configured() && serverEmpty && !st.chat.length) add.push({ role: 'buddy', ...openingLine(), kind: 'opening' });
  if (add.length) {
    const chat = [...st.chat];
    const last = chat[chat.length - 1];
    const keepLast = last?.kind === 'ask' ? chat.pop() : null; // "Kako je prošlo?" ostaje zadnje
    const now = Date.now();
    add.forEach((m, i) => chat.push({ id: `l-${Math.random().toString(36).slice(2, 9)}`, ts: now - (add.length - i) * 10, ...m }));
    if (keepLast) chat.push(keepLast);
    store.set({ chat: chat.slice(-100), buddy: patch });
  } else if (patch.lastOpen !== b.lastOpen || patch.recapWeek !== b.recapWeek) store.set({ buddy: patch });
}

// ── Prikaz ──

function bubble(m, { animateIn = false } = {}) {
  const row = document.createElement('div');
  row.className = `msg ${m.role === 'user' ? 'me' : 'bot'}`;
  row.dataset.id = m.id;
  if (m.role !== 'user') {
    const av = document.createElement('div');
    av.className = 'msg-av';
    row.append(av);
    new Mascot(av, { expr: m.mood || 'happy', size: 32, interactive: false, still: true, label: NAME });
  }
  const col = document.createElement('div');
  col.className = 'msg-col';
  const b = document.createElement('div');
  b.className = `bubble ${m.role === 'user' ? '' : 'glass-card'}`;
  b.textContent = m.text || '';
  if (m.pending) b.innerHTML = '<span class="typing" aria-label="Mrvica piše"><i></i><i></i><i></i></span>';
  col.append(b);
  if (m.source === 'telegram' || m.source === 'proactive') {
    const s = document.createElement('span');
    s.className = 'msg-src';
    s.innerHTML = icon('plane');
    s.append(document.createTextNode(m.source === 'proactive' ? ' Telegram · Mrvica se javila' : ' Telegram'));
    col.append(s);
  }
  if (m.actions?.length) col.append(actionRow(m));
  if (m.quick?.length) col.append(quickRow(m.quick));
  if (m.retry) {
    const w = document.createElement('div');
    w.className = 'msg-actions qr-row';
    const b2 = document.createElement('button');
    b2.className = 'chip qr';
    b2.textContent = 'Pošalji ponovno';
    b2.addEventListener('click', () => {
      row.remove();
      list?.querySelector(`[data-id="${m.retryOf}"]`)?.remove();
      store.set({ chat: store.get().chat.filter((x) => x.id !== m.id && x.id !== m.retryOf) });
      send(m.retry);
    });
    w.append(b2);
    col.append(w);
  }
  row.append(col);
  // dugi pritisak: kopiraj ili spremi
  let t;
  b.addEventListener('pointerdown', () => { t = setTimeout(() => { tick(); msgMenu(m); }, 520); });
  ['pointerup', 'pointerleave', 'pointercancel', 'pointermove'].forEach((ev) => b.addEventListener(ev, (e) => { if (ev !== 'pointermove' || Math.abs(e.movementY) > 3) clearTimeout(t); }));
  b.addEventListener('contextmenu', (e) => { e.preventDefault(); msgMenu(m); });
  if (animateIn && !reduced()) {
    animate(row, [{ opacity: 0, transform: 'translateY(14px) scale(0.92)', transformOrigin: m.role === 'user' ? '100% 100%' : '0 100%' }, { opacity: 1, transform: 'none' }], { spring: 'bouncy', fill: 'none' });
  }
  return row;
}

function actionRow(m) {
  const wrap = document.createElement('div');
  wrap.className = 'msg-actions';
  for (const a of m.actions) {
    if (!validateAction(a)) continue;
    const btn = document.createElement('button');
    btn.className = 'btn glass-btn small';
    btn.textContent = actionLabel(a);
    btn.addEventListener('click', () => { haptic(); runAction(a, { messageText: m.text }); });
    wrap.append(btn);
  }
  return wrap;
}

function quickRow(items) {
  const wrap = document.createElement('div');
  wrap.className = 'msg-actions qr-row';
  items.forEach((q, i) => {
    const btn = document.createElement('button');
    btn.className = 'chip qr';
    btn.style.setProperty('--i', i);
    btn.textContent = q;
    btn.addEventListener('click', () => send(q));
    wrap.append(btn);
  });
  return wrap;
}

function msgMenu(m) {
  const body = document.createElement('div');
  body.innerHTML = `<div class="btn-stack"><button class="btn btn-tinted" data-copy>${icon('check')} Kopiraj</button><button class="btn btn-tinted" data-keep>${icon('bookmark')} Spremi u Spremljeno</button></div>`;
  const sh = openSheet({ title: 'Poruka', body });
  body.querySelector('[data-copy]').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(m.text); toast('Kopirano', { icon: '📋' }); } catch { toast('Kopiranje nije uspjelo. Označi tekst prstom.'); }
    sh.close();
  });
  body.querySelector('[data-keep]').addEventListener('click', () => { runAction({ id: 'save' }, { messageText: m.text }); sh.close(); });
}

function setMood(mood, { lean = false } = {}) {
  const m = head?._mascot;
  if (!m) return;
  m.set(mood || 'happy', mood === 'caring' ? 'hug' : 'idle');
  if (lean) m.lean(); else m.unlean();
  if (mood === 'celebrating' || mood === 'excited' || mood === 'proud') m.hop(12);
}

function setOnline(v) {
  online = v;
  if (!status) return;
  status.textContent = !configured() ? 'Tvoj Buddy · osnovni način bez interneta'
    : v === false ? ERROR_TEXT
      : 'Tvoj Buddy · isti razgovor kao na Telegramu';
  status.classList.toggle('warn', v === false && configured());
}

function rebuild() {
  if (!list) return;
  const stick = nearBottom();
  list.textContent = '';
  for (const m of store.get().chat) list.append(bubble(m));
  if (stick) requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
}

// ── Slanje ──

async function remember(text) {
  const same = (list) => list.some((m) => m.text.trim().toLowerCase() === text.trim().toLowerCase());
  if (configured()) {
    try {
      const existing = await getMemory().catch(() => store.get().memory);
      if (same(existing)) return;
      await addMemoryApi(text); getMemory().then((f) => store.set({ memory: f.map((x) => ({ id: x.id, text: x.text, ts: Date.now() })) })).catch(() => {}); toast('Mrvica je zapamtila novu stvar o tebi', { icon: '🧠', ms: 2200 }); return; } catch { /* lokalno */ }
  }
  if (addMemory(text)) toast('Mrvica je zapamtila novu stvar o tebi', { icon: '🧠', ms: 2200 });
}

export async function send(text) {
  text = String(text || '').trim().slice(0, 1000);
  if (!text || busy) return;
  busy = true;
  haptic();
  const userMsg = addChat({ role: 'user', text, source: 'web' });
  list?.append(bubble(userMsg, { animateIn: true }));
  toBottom(true);

  // brzi odgovor na "Kako je prošlo?" sprema se uz današnji trening (radi i bez AI-ja)
  const feel = /^(lako|taman|teško|tesko)$/i.test(text) ? text.toLowerCase().replace('tesko', 'teško') : null;
  // ono što stvarno ide Buddyju: brzi odgovor dobije kontekst, da Buddy (i na Telegramu) zna o čemu se radi
  let outgoing = text;
  if (feel) {
    const k = keyOf(today());
    const done = store.get().done;
    if (done[k]) { store.set({ done: { ...done, [k]: { ...done[k], feel } } }); syncStats({ delay: 0, force: true }); }
    outgoing = `Upravo sam odradila današnji trening. Bilo mi je: ${feel}.`;
  }

  const care = detectCare(text);
  // bez interneta: najosjetljivije teme (hrana, vrtoglavica) dobiju provjeren lokalni odgovor.
  // S backendom sve ide istom Buddyju (on ima ista sigurnosna pravila), da web i Telegram budu jedan razgovor.
  if (!configured() && care && (care.kind === 'food' || care.kind === 'dizzy')) {
    setMood('thinking');
    await new Promise((r) => setTimeout(r, 650));
    const r = careReply(care);
    finish({ role: 'buddy', text: r.text, mood: 'caring', actions: r.actions }, { lean: true });
    return;
  }

  const pendingRow = bubble({ id: 'pending', role: 'buddy', pending: true, mood: 'thinking' }, { animateIn: true });
  list?.append(pendingRow);
  toBottom(true);
  setMood('thinking');

  const pain = care?.kind === 'pain' ? careReply(care) : null;
  if (pain?.memory) remember(pain.memory);

  if (!configured()) {
    await new Promise((r) => setTimeout(r, 700));
    pendingRow.remove();
    const r = pain || localReply(text);
    finish({ role: 'buddy', text: r.text, mood: r.mood, actions: r.actions }, { lean: !!pain || care?.kind === 'low' });
    return;
  }

  const bubbleEl = pendingRow.querySelector('.bubble');
  try {
    let started = false;
    const res = await apiChat(outgoing, {
      onDelta: (full) => {
        const v = visibleText(full);
        if (!v) return;
        if (!started) { started = true; bubbleEl.textContent = ''; }
        bubbleEl.textContent = v;
        toBottom();
      },
    });
    setOnline(true);
    const p = parseReply(res.text || '');
    pendingRow.remove();
    if (!p.text) throw new Error('empty');
    let actions = p.actions.length ? p.actions : (res.actions || []).map(validateAction).filter(Boolean).slice(0, 2);
    let mood = p.mood || res.mood || (care?.kind === 'low' ? 'caring' : 'happy');
    // bol: uvijek brižno, i uvijek ponudi zamjenu vježbe (radi i ako je model zaboravi)
    if (pain) {
      mood = 'caring';
      if (!actions.some((a) => a.id === 'swap')) actions = [{ id: 'swap', ...(painExercise(care.part) ? { ex: painExercise(care.part) } : {}) }, ...actions].slice(0, 2);
    }
    store.set({ chat: store.get().chat.map((m) => (m.id === userMsg.id ? { ...m, synced: true } : m)) });
    finish({ role: 'buddy', text: p.text, mood, actions, synced: true, source: 'web' }, { lean: !!pain || care?.kind === 'low', noAnim: started });
    setTimeout(() => refresh(), 1500);
  } catch {
    pendingRow.remove();
    setOnline(false);
    // nema drugog "lokalnog" bota koji bi odgovorio umjesto Buddyja: samo kratka poruka i gumb za ponovno slanje
    finish({ role: 'buddy', text: 'Poruka nije stigla do mene, internet je zapeo. Probaj ponovno 💛', mood: 'sleepy', ephemeral: true, retry: text, retryOf: userMsg.id });
  }
}

function finish(msg, { lean = false, noAnim = false } = {}) {
  const saved = addChat(msg);
  list?.append(bubble(saved, { animateIn: !noAnim }));
  setMood(msg.mood, { lean });
  busy = false;
  toBottom(true);
  updateUnread();
}

export function updateUnread() {
  const chat = store.get().chat;
  const seen = store.get().buddy?.seen || 0;
  const unread = chat.some((m) => m.role === 'buddy' && m.ts > seen);
  const onTab = document.body.classList.contains('tab-buddy');
  if (onTab && unread) store.set({ buddy: { ...store.get().buddy, seen: Date.now() } });
  document.querySelector('[data-tab="buddy"]')?.classList.toggle('unread', unread && !onTab);
}

function startPolling() {
  clearInterval(pollT);
  if (!configured()) return;
  pollT = setInterval(() => {
    if (!list?.isConnected || !document.body.classList.contains('tab-buddy')) { clearInterval(pollT); return; }
    if (!document.hidden) refresh();
  }, 20000);
}

export function render(container) {
  el = container;
  ensureLocalMessages();
  const st = store.get();
  container.innerHTML = `
    <header class="buddy-head" aria-label="${NAME}">
      <div class="bh-m"></div>
      <div><h1 class="large-title">${NAME}</h1><p class="muted small bh-status"></p></div>
    </header>
    <div class="chat" role="log" aria-live="polite" aria-label="Razgovor s Mrvicom"></div>
    <div class="qr-row buddy-chips" role="group" aria-label="Brzi odgovori">${BUDDY_CHIPS.map((c, i) => `<button class="chip qr" style="--i:${i}" data-chip="${c}">${c}</button>`).join('')}</div>`;
  head = container.querySelector('.buddy-head');
  status = container.querySelector('.bh-status');
  setOnline(online);
  const last = st.chat.filter((m) => m.role === 'buddy').slice(-1)[0];
  head._mascot = new Mascot(head.querySelector('.bh-m'), { expr: last?.mood || 'happy', size: 64 });
  list = container.querySelector('.chat');
  for (const m of st.chat) list.append(bubble(m));
  container.querySelectorAll('[data-chip]').forEach((b) => b.addEventListener('click', () => send(b.dataset.chip)));
  store.set({ buddy: { ...store.get().buddy, seen: Date.now() } });
  requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
  updateUnread();
  refresh();
  startPolling();
}

// unosna traka (staklena, u funkcionalnom sloju)
export function initBar() {
  const bar = document.getElementById('buddy-bar');
  if (!bar) return;
  const ta = bar.querySelector('textarea');
  const btn = bar.querySelector('button');
  const grow = () => { ta.style.height = 'auto'; ta.style.height = `${Math.min(120, ta.scrollHeight)}px`; document.documentElement.style.setProperty('--bar-h', `${bar.offsetHeight}px`); };
  ta.addEventListener('input', () => { grow(); btn.disabled = !ta.value.trim(); });
  const go = () => { const v = ta.value; if (!v.trim() || busy) return; ta.value = ''; grow(); btn.disabled = true; send(v); };
  btn.addEventListener('click', go);
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); go(); } });
  btn.disabled = true;
  grow();
  // tipkovnica: traka ostaje iznad nje (iOS preko visualViewporta, Android preko resizes-content)
  const vv = window.visualViewport;
  const onVV = () => {
    const kb = vv ? Math.max(0, window.innerHeight - vv.height - vv.offsetTop) : 0;
    document.documentElement.style.setProperty('--kb', `${kb}px`);
    document.body.classList.toggle('kb-open', kb > 80 || (document.activeElement === ta && window.innerHeight < screen.height * 0.6));
  };
  vv?.addEventListener('resize', onVV);
  vv?.addEventListener('scroll', onVV);
  ta.addEventListener('focus', () => { setTimeout(onVV, 300); setTimeout(() => toBottom(true), 350); });
  ta.addEventListener('blur', () => setTimeout(onVV, 200));
}

// pitanje iz drugog ekrana (npr. "Objasni mi") stiže ovdje
export function ask(text) {
  location.hash = '#buddy';
  setTimeout(() => send(text), 350);
}
