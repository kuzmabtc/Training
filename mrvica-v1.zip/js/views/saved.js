// Spremljeno: sve označene vježbe, jela, savjeti i misli, s filtrima.

import { EX, FOOD, TIPS, RULES, MESSAGES } from '../data.js';
import { store } from '../store.js';
import { exerciseThumb } from '../illustrations.js';
import { icon } from '../ui/icons.js';
import { segmented, saveBtn, foodCard, tipCard, emptyState } from '../ui/components.js';
import { esc } from '../util.js';

export const title = 'Spremljeno';
let filter = 'all';

const FOOD_BY_ID = Object.fromEntries([...FOOD.breakfast, ...FOOD.meals, ...FOOD.snacks].map((f) => [f.id, f]));
const TIP_BY_ID = Object.fromEntries([...TIPS.more, ...TIPS.pre, ...TIPS.post, ...TIPS.water, ...RULES.map((r) => ({ id: r.id, title: r.title, text: r.text }))].map((t) => [t.id, t]));

const FILTERS = [
  { id: 'all', name: 'Sve' },
  { id: 'ex', name: 'Vježbe' },
  { id: 'food', name: 'Hrana' },
  { id: 'tip', name: 'Savjeti' },
];

function card(key) {
  const [type, id] = key.split(':');
  if (type === 'ex' && EX[id]) {
    const e = EX[id];
    return `<article class="glass-card saved-ex">
      <button class="saved-ex-open" data-ex="${id}">
        <span class="ex-thumb small">${exerciseThumb(id)}</span>
        <span class="lr-main"><span class="lr-label">${esc(e.name)}</span><span class="lr-sub">${esc(e.muscles)}</span></span>
      </button>
      ${saveBtn(key, e.name)}
    </article>`;
  }
  if (type === 'food' && FOOD_BY_ID[id]) return foodCard(FOOD_BY_ID[id]);
  if (type === 'tip' && TIP_BY_ID[id]) return tipCard(TIP_BY_ID[id]);
  if (type === 'note') {
    const n = store.get().notes.find((x) => x.id === id);
    if (!n) return '';
    return `<article class="glass-card quote"><div class="card-row"><p class="eyebrow">Bilješka · ${esc(n.d.split('-').reverse().slice(0, 2).join('. '))}.</p><button class="icon-btn" data-delnote="${n.id}" aria-label="Obriši bilješku">${icon('close')}</button></div><p class="note-text">${esc(n.text)}</p></article>`;
  }
  if (type === 'msg' && MESSAGES[+id]) {
    return `<article class="glass-card quote"><div class="card-row"><p class="eyebrow">Misao</p>${saveBtn(key, 'Misao')}</div><p class="quote-text">${esc(MESSAGES[+id])}</p></article>`;
  }
  return '';
}

export function render(el, { embedded = false } = {}) {
  const saved = [...store.get().saved, ...store.get().notes.map((n) => `note:${n.id}`)];
  const match = (k) => filter === 'all' || k.startsWith(`${filter}:`) || (filter === 'tip' && (k.startsWith('msg:') || k.startsWith('note:')));
  const items = saved.filter(match).map(card).filter(Boolean);
  const counts = Object.fromEntries(FILTERS.map((f) => [f.id, saved.filter((k) => f.id === 'all' || k.startsWith(`${f.id}:`) || (f.id === 'tip' && (k.startsWith('msg:') || k.startsWith('note:')))).length]));
  el.innerHTML = `
    ${embedded ? '' : `<header class="large-head">
      <p class="eyebrow">${saved.length ? `${saved.length} spremljeno` : 'Tvoja zbirka'}</p>
      <h1 class="large-title">Spremljeno</h1>
    </header>`}
    ${saved.length ? segmented('sfilter', FILTERS.map((f) => ({ ...f, name: counts[f.id] ? `${f.name} ${counts[f.id]}` : f.name })), filter, 'Vrsta spremljenog') : ''}
    <div class="stack">${items.join('')}</div>`;
  if (!items.length) {
    el.querySelector('.stack').append(emptyState(
      saved.length ? 'Ovdje još ništa nema' : 'Još ništa nije spremljeno',
      'Tapni 🔖 na vježbi ili jelu i bit će ovdje.',
    ));
  }
  el.querySelectorAll('[data-delnote]').forEach((b) => b.addEventListener('click', () => {
    store.set({ notes: store.get().notes.filter((n) => n.id !== b.dataset.delnote) });
  }));
  el.querySelector('[data-seg="sfilter"]')?.addEventListener('click', (e) => {
    const b = e.target.closest('[data-val]');
    if (!b) return;
    filter = b.dataset.val;
    render(el, { embedded });
  });
}

export { icon };
