// Sav sadržaj aplikacije: vježbe, plan, prehrana, poruke, značke.
// Kalorije i proteini su okvirne vrijednosti za orijentaciju, ne za brojanje.

export const USER = { name: 'Dora', weightKg: 44.5, heightCm: 157 };

export const CATEGORIES = [
  { id: 'sve', name: 'Sve' },
  { id: 'noge', name: 'Noge i guza' },
  { id: 'leda', name: 'Leđa' },
  { id: 'prsa-ruke', name: 'Prsa i ruke' },
  { id: 'ramena', name: 'Ramena' },
  { id: 'trup', name: 'Trup' },
];

export const EXERCISES = [
  {
    id: 'goblet-squat', name: 'Goblet čučanj', cat: 'noge',
    muscles: 'Bedra, guza, trup', equip: 'Jedna bučica',
    cues: ['Bučicu drži uz prsa, laktovi prema dolje', 'Stopala malo šire od kukova, prsti blago van', 'Koljena prate prste', 'Spusti se s ravnim leđima, pa se odgurni cijelim stopalom'],
    mistakes: ['Pete se odvajaju od poda', 'Koljena padaju prema unutra', 'Leđa se zaobljuju na dnu'],
    easier: 'Čučanj na stolicu: sjedni i ustani bez utega',
    harder: 'Pauza od 2 s na dnu ili teža bučica',
  },
  {
    id: 'rdl', name: 'Rumunjsko mrtvo dizanje', cat: 'noge',
    muscles: 'Stražnja loža, guza, donja leđa', equip: 'Dvije bučice',
    cues: ['Koljena blago savijena i takva ostaju', 'Guraj kukove unatrag kao da guzom zatvaraš vrata', 'Bučice klize uz bedra', 'Leđa ravna, pogled pola metra ispred stopala'],
    mistakes: ['Čučanj umjesto guranja kukova unatrag', 'Zaobljena leđa', 'Bučice odlaze daleko od nogu'],
    easier: 'Bez utega, ruke na bokovima',
    harder: 'Jednonožni RDL uz oslonac na zid',
  },
  {
    id: 'floor-press', name: 'Potisak s poda', cat: 'prsa-ruke',
    muscles: 'Prsa, triceps, prednja ramena', equip: 'Dvije bučice, podloga',
    cues: ['Lezi na leđa, koljena savijena, stopala na podu', 'Laktovi oko 45° od tijela', 'Spusti dok nadlaktice lagano ne dotaknu pod', 'Potisni ravno iznad prsa uz izdah'],
    mistakes: ['Laktovi raširenih u stranu, kao slovo T', 'Bučice se njišu i sudaraju', 'Odbijanje laktova od poda'],
    easier: 'Sklekovi uz zid ili na koljenima',
    harder: 'Jednoručni potisak s poda (trup se ne okreće)',
  },
  {
    id: 'one-arm-row', name: 'Jednoručno veslanje', cat: 'leda',
    muscles: 'Leđa, stražnja ramena, biceps', equip: 'Bučica, stolica',
    cues: ['Slobodna ruka na stolici, leđa ravna', 'Povuci lakat prema kuku, ne prema uhu', 'Na vrhu stisni lopaticu prema kralježnici', 'Spuštaj polako do ispružene ruke'],
    mistakes: ['Okretanje trupa da se uteg podigne', 'Rame se diže prema uhu', 'Trzanje umjesto kontrole'],
    easier: 'Lakša bučica i kraći pokret',
    harder: 'Pauza 1 s na vrhu ili teža bučica',
  },
  {
    id: 'ohp', name: 'Potisak iznad glave', cat: 'ramena',
    muscles: 'Ramena, triceps, gornja leđa', equip: 'Dvije bučice',
    cues: ['Stoj stabilno, stisni guzu i trbuh', 'Bučice kreću s visine ramena', 'Potisni gore dok ruke nisu uz uši', 'Rebra dolje, bez savijanja u leđima'],
    mistakes: ['Previše savijena donja leđa', 'Laktovi skroz u stranu', 'Pokret samo do pola'],
    easier: 'Sjedeći potisak na stolici',
    harder: 'Jednoručni potisak (trup ostaje miran)',
  },
  {
    id: 'glute-bridge', name: 'Most / hip thrust', cat: 'noge',
    muscles: 'Guza, stražnja loža', equip: 'Bučica, podloga (kauč za hip thrust)',
    cues: ['Pete blizu guze, stopala u širini kukova', 'Bučicu drži na kukovima', 'Guraj kroz pete do ravne linije koljena–kukovi–ramena', 'Na vrhu stisni guzu 1–2 s'],
    mistakes: ['Previše izvijena donja leđa na vrhu', 'Guranje kroz prste umjesto kroz pete', 'Koljena bježe van ili unutra'],
    easier: 'Most bez utega',
    harder: 'Hip thrust: gornji dio leđa na rubu kauča',
  },
  {
    id: 'reverse-lunge', name: 'Iskorak unatrag', cat: 'noge',
    muscles: 'Bedra, guza, ravnoteža', equip: 'Dvije bučice (ili bez)',
    cues: ['Iskorači unatrag dovoljno daleko', 'Stražnje koljeno spusti prema podu', 'Prednje koljeno iznad stopala', 'Vrati se guranjem kroz prednju petu'],
    mistakes: ['Prekratak korak', 'Trup pada naprijed', 'Žurba: ravnoteža dolazi sa sporijim tempom'],
    easier: 'Bez utega, s rukom na naslonu stolice',
    harder: 'Split čučanj: stopala ostaju na mjestu, sporo spuštanje',
  },
  {
    id: 'lateral-raise', name: 'Odručenje', cat: 'ramena',
    muscles: 'Bočni dio ramena', equip: 'Dvije lakše bučice',
    cues: ['Laktovi lagano savijeni', 'Podiži ruke u stranu do visine ramena', 'Vodi laktovima, ne šakama', 'Spuštaj sporo, 2–3 s'],
    mistakes: ['Preteške bučice i ljuljanje', 'Ramena se dižu prema ušima', 'Ruke iznad visine ramena'],
    easier: 'Jedna ruka pa druga, ili bez utega',
    harder: 'Pauza 1 s na vrhu',
  },
  {
    id: 'biceps-curl', name: 'Pregib za biceps', cat: 'prsa-ruke',
    muscles: 'Biceps, podlaktice', equip: 'Dvije bučice',
    cues: ['Laktovi uz tijelo', 'Podiži bez ljuljanja', 'Stisni na vrhu', 'Spuštaj kontrolirano do kraja'],
    mistakes: ['Ljuljanje trupom', 'Laktovi bježe naprijed', 'Ruke se ne ispruže do kraja'],
    easier: 'Naizmjence, jedna ruka po jedna',
    harder: 'Sporo spuštanje 3 s',
  },
  {
    id: 'triceps-ext', name: 'Triceps iznad glave', cat: 'prsa-ruke',
    muscles: 'Triceps', equip: 'Jedna bučica',
    cues: ['Bučicu drži objema rukama iznad glave', 'Nadlaktice uz glavu, laktovi gledaju naprijed', 'Spuštaj bučicu iza glave', 'Ispruži ruke bez trzaja'],
    mistakes: ['Laktovi se šire u stranu', 'Savijanje u donjim leđima', 'Prebrzo spuštanje'],
    easier: 'Sjedeći na stolici, lakša bučica',
    harder: 'Jednoručna verzija',
  },
  {
    id: 'plank', name: 'Daska (plank)', cat: 'trup',
    muscles: 'Trup, ramena', equip: 'Podloga',
    cues: ['Laktovi ispod ramena', 'Tijelo u ravnoj liniji od glave do peta', 'Stisni guzu i trbuh', 'Diši mirno'],
    mistakes: ['Kukovi propadaju prema podu', 'Guza previsoko', 'Zadržavanje daha'],
    easier: 'Daska na koljenima',
    harder: 'Naizmjence podiži jednu nogu',
    frames: ['Na koljenima', 'Puna daska'],
  },
  {
    id: 'dead-bug', name: 'Mrtva buba', cat: 'trup',
    muscles: 'Duboki trbušni mišići', equip: 'Podloga',
    cues: ['Donja leđa pritisnuta u pod', 'Ruke prema stropu, koljena iznad kukova', 'Ispruži suprotnu ruku i nogu', 'Polako, uz izdah dok ispružuješ'],
    mistakes: ['Leđa se odvajaju od poda', 'Prebrzo', 'Zadržavanje daha'],
    easier: 'Miču se samo noge, ruke miruju',
    harder: 'Mala bučica u rukama',
  },
  {
    id: 'bird-dog', name: 'Bird-dog', cat: 'trup',
    muscles: 'Trup, guza, leđa', equip: 'Podloga',
    cues: ['Dlanovi ispod ramena, koljena ispod kukova', 'Ispruži suprotnu ruku i nogu', 'Kukovi ravni, kao da na leđima držiš čašu vode', 'Zadrži 2 s, pa zamijeni strane'],
    mistakes: ['Kukovi se okreću', 'Noga ide previsoko', 'Ulegnuta donja leđa'],
    easier: 'Samo ruka ili samo noga',
    harder: 'Ispod tijela spoji lakat i koljeno, pa opet ispruži',
  },
  {
    id: 'calf-raise', name: 'Podizanje na prste', cat: 'noge',
    muscles: 'Listovi', equip: 'Bučice (neobavezno)',
    cues: ['Stopala u širini kukova', 'Podigni se što više na prste', 'Zadrži 1 s na vrhu', 'Spuštaj sporo'],
    mistakes: ['Poskakivanje', 'Težina na malim prstima', 'Pokret samo do pola'],
    easier: 'Uz oslonac na zid',
    harder: 'Na rubu stepenice ili na jednoj nozi',
  },
];

export const EX = Object.fromEntries(EXERCISES.map((e) => [e.id, e]));

// ── Plan ────────────────────────────────────────────────

export const PHASES = [
  {
    n: 1, from: 1, to: 4, name: 'Temelji', short: 'Učimo pokrete',
    text: 'Prva četiri tjedna su za tehniku. Biraj lagane bučice i fokusiraj se na to kako se pokret osjeća. Prva dva tjedna radiš 2 serije, onda 3.',
  },
  {
    n: 2, from: 5, to: 8, name: 'Snaga', short: 'Teže bučice',
    text: 'Pokreti su ti sad poznati, pa kilaže mogu rasti. 3 serije po 8–12 ponavljanja. Kad u svim serijama dođeš do 12, sljedeći put uzmi težu bučicu.',
  },
  {
    n: 3, from: 9, to: 12, name: 'Kontrola', short: 'Sporiji tempo, jedna strana',
    text: 'Usporavamo spuštanje (3 s) i više radimo jednu stranu tijela. Tako mišići rade dulje, a ravnoteža i držanje postaju jači. Od 11. tjedna 4 serije glavnih vježbi.',
  },
];

// Uloga u treningu određuje serije i ponavljanja po fazi.
// main = glavne vježbe, acc = pomoćne, calf = listovi, time = izdržaj, side = po strani
export const DAY_TEMPLATES = {
  A: {
    name: 'Snaga A', focus: 'Čučanj, potisak, veslanje',
    items: [
      { ex: 'goblet-squat', role: 'main' },
      { ex: 'floor-press', role: 'main', p3: 'Jednoručni potisak s poda' },
      { ex: 'one-arm-row', role: 'main' },
      { ex: 'glute-bridge', role: 'main', p2: 'Hip thrust (leđa na kauču)', p3: 'Hip thrust, jednonožni na zadnjoj seriji' },
      { ex: 'lateral-raise', role: 'acc' },
      { ex: 'dead-bug', role: 'side' },
      { ex: 'calf-raise', role: 'calf' },
    ],
  },
  B: {
    name: 'Snaga B', focus: 'Mrtvo dizanje, ramena, ruke',
    items: [
      { ex: 'rdl', role: 'main', p3: 'Jednonožni RDL uz zid' },
      { ex: 'ohp', role: 'main', p3: 'Jednoručni potisak iznad glave' },
      { ex: 'goblet-squat', role: 'main' },
      { ex: 'one-arm-row', role: 'main' },
      { ex: 'biceps-curl', role: 'acc' },
      { ex: 'triceps-ext', role: 'acc' },
      { ex: 'plank', role: 'time' },
    ],
  },
  C: {
    name: 'Snaga C', focus: 'Iskorak, guza, stabilnost',
    items: [
      { ex: 'reverse-lunge', role: 'main', p3: 'Split čučanj (sporo spuštanje)' },
      { ex: 'floor-press', role: 'main' },
      { ex: 'glute-bridge', role: 'main', p2: 'Hip thrust (leđa na kauču)' },
      { ex: 'one-arm-row', role: 'main' },
      { ex: 'lateral-raise', role: 'acc' },
      { ex: 'bird-dog', role: 'side' },
      { ex: 'plank', role: 'time' },
    ],
  },
};

// Ponedjeljak = 0 … nedjelja = 6
export const WEEK_SCHEDULE = [
  { type: 'strength', day: 'A' },
  { type: 'walk', walk: 'steady' },
  { type: 'strength', day: 'B' },
  { type: 'rest' },
  { type: 'strength', day: 'C' },
  { type: 'walk', walk: 'intervals' },
  { type: 'rest' },
];

export const DELOAD_WEEKS = [8];

export const WARMUP = [
  { name: 'Lagano hodanje (na mjestu ili na traci)', secs: 120 },
  { name: 'Kruženje ramenima naprijed i nazad', secs: 30 },
  { name: 'Mačka–krava na sve četiri', secs: 40 },
  { name: 'Čučanj bez utega, 10 puta', secs: 40 },
  { name: 'Most bez utega, 10 puta', secs: 35 },
  { name: 'Iskorak unatrag naizmjence, 6 po nozi', secs: 35 },
];

export const COOLDOWN = [
  { name: 'Istezanje prsa uz okvir vrata', secs: 40 },
  { name: 'Stražnja loža: noga na stolici, nagib naprijed', secs: 60 },
  { name: 'Prednja bedra: peta prema guzi, uz zid', secs: 60 },
  { name: 'Dječji položaj, duboko disanje', secs: 60 },
  { name: 'Ležeća rotacija leđa, koljena u stranu', secs: 60 },
];

export const MOBILITY = [
  { name: 'Mačka–krava, polako s disanjem', secs: 60 },
  { name: 'Dječji položaj s rukama naprijed', secs: 60 },
  { name: 'Iskorak na koljenu, kukovi naprijed (lijevo)', secs: 45 },
  { name: 'Iskorak na koljenu, kukovi naprijed (desno)', secs: 45 },
  { name: 'Sjed 90/90, okreti koljena s jedne strane na drugu', secs: 75 },
  { name: 'Otvaranje prsa: ležanje na boku, ruka u luk', secs: 75 },
  { name: 'Leđa uz zid: klizanje rukama gore-dolje', secs: 60 },
  { name: 'Duboki čučanj uz oslonac, opušteno', secs: 60 },
  { name: 'Ležeća rotacija leđa', secs: 60 },
  { name: 'Ležanje na leđima, 5 dubokih udaha', secs: 60 },
];

// Šetnje: lagano tempo, uz koji možeš razgovarati u cijelim rečenicama.
export const WALKS = {
  steady: {
    name: 'Ujednačena šetnja',
    byPhase: {
      1: [{ name: 'Zagrijavanje', secs: 180, speed: 4.5 }, { name: 'Ujednačeno', secs: 1200, speed: 5.0 }, { name: 'Hlađenje', secs: 120, speed: 4.3 }],
      2: [{ name: 'Zagrijavanje', secs: 180, speed: 4.5 }, { name: 'Ujednačeno', secs: 1500, speed: 5.3 }, { name: 'Hlađenje', secs: 120, speed: 4.3 }],
      3: [{ name: 'Zagrijavanje', secs: 180, speed: 4.6 }, { name: 'Ujednačeno', secs: 1800, speed: 5.5 }, { name: 'Hlađenje', secs: 120, speed: 4.4 }],
    },
  },
  intervals: {
    name: 'Šetnja s intervalima',
    byPhase: {
      1: { warm: 300, rounds: 4, fast: 5.6, easy: 4.8, cool: 240 },
      2: { warm: 300, rounds: 5, fast: 5.8, easy: 4.8, cool: 300 },
      3: { warm: 300, rounds: 8, fast: 6.0, easy: 5.0, cool: 180 },
    },
  },
};

export const RULES = [
  {
    id: 'rule-progression', title: 'Pravilo dvostruke progresije',
    text: 'Svaka vježba ima raspon ponavljanja, npr. 8–12. Kreni s kilažom s kojom možeš napraviti 8. Svaki trening pokušaj dodati ponavljanje. Kad u svim serijama napraviš 12, sljedeći put uzmi težu bučicu i opet kreni od 8.',
  },
  {
    id: 'rule-rpe', title: 'Kako izabrati kilažu',
    text: 'Zadnja dva ponavljanja trebaju biti teška, ali forma i dalje savršena. Ako se tehnika raspada, uteg je pretežak. Ako bi mogla još pet, uzmi teži.',
  },
  {
    id: 'rule-deload', title: 'Lakši tjedan',
    text: '8. tjedan je lakši: ista kilaža, serija manje. Tijelo tada sustigne sav trud. Ako se bilo kad osjećaš iscrpljeno ili loše spavaš, slobodno ubaci lakši tjedan i ranije.',
  },
  {
    id: 'rule-short', title: 'Loš dan? Kratka verzija',
    text: 'Imaš manje vremena ili energije? Kratka verzija traje oko 15 minuta: prve tri vježbe dana po 2 serije i jedna vježba za trup. I to se računa kao trening.',
  },
];

export const SAFETY = 'Kreni polako i dopusti tijelu da se navikne. Lagana nelagoda u mišićima je normalna, ali ako osjetiš oštru bol, vrtoglavicu ili mučninu, stani i odmori se. Budući da je tvoj BMI na nižoj granici, dobro je prije početka popričati s liječnikom ili nutricionistom. Oni ti mogu pomoći da plan bude baš po mjeri.';

// ── Prehrana ────────────────────────────────────────────

export const NUTRITION_PRINCIPLES = [
  { icon: '🕒', title: 'Jedi redovito', text: '3 obroka i 2–3 međuobroka, svaka 3–4 sata.' },
  { icon: '🥚', title: 'Proteini u svakom obroku', text: 'Jaja, jogurt, sir, meso, riba, grah ili leća.' },
  { icon: '💛', title: 'Nema zabranjene hrane', text: 'I burek i ćevapi imaju mjesto. Sve se uklapa.' },
];

export const FOOD = {
  breakfast: [
    { id: 'b1', name: 'Zobena kaša s bananom i kikiriki maslacem', items: '60 g zobenih, 250 ml mlijeka, banana, žlica kikiriki maslaca, žličica meda', kcal: 600, protein: 21, note: 'Zobene skuhaj u mlijeku, dodaj ostalo. Gotovo za 5 minuta.' },
    { id: 'b2', name: 'Kajgana s pršutom i kruhom', items: '3 jaja, 30 g pršuta, 2 kriške kruha, malo maslaca', kcal: 480, protein: 32, note: 'Brzo, slano i drži do ručka.' },
    { id: 'b3', name: 'Jogurt s granolom, orasima i medom', items: '200 g punomasnog grčkog jogurta, 40 g granole, šaka oraha, med', kcal: 570, protein: 25, note: 'Složi u čašu večer prije pa samo uzmi iz hladnjaka.' },
    { id: 'b4', name: 'Kruh sa svježim sirom, jajem i rajčicom', items: '2 kriške integralnog kruha, 100 g svježeg sira, kuhano jaje, rajčica, maslinovo ulje', kcal: 420, protein: 26, note: 'Klasika. Pokapaj maslinovim uljem i posoli.' },
    { id: 'b5', name: 'Smoothie banana i kakao', items: '300 ml mlijeka, banana, 30 g zobenih, žlica kikiriki maslaca, žličica kakaa', kcal: 500, protein: 19, note: 'Odličan kad ujutro nisi gladna. Lakše se pije nego jede.' },
    { id: 'b6', name: 'Zobene palačinke s jogurtom', items: '2 jaja, banana, 40 g zobenih (izmiksaj), 100 g jogurta za preljev', kcal: 450, protein: 22, note: 'Smjesu izmiksaj i peci male palačinke na malo ulja.' },
    { id: 'b7', name: 'Pita sa sirom i jogurt', items: '1 komad pite sa sirom (150 g), 250 ml jogurta', kcal: 600, protein: 22, note: 'Vikend doručak. Uz jogurt je i hranjiviji.' },
  ],
  meals: [
    { id: 'l1', name: 'Piletina s rižom i povrćem', items: '150 g pilećih prsa, 80 g riže (suhe), povrće po želji, žlica maslinova ulja', kcal: 620, protein: 42, note: 'Skuhaj više riže odjednom za dva dana.' },
    { id: 'l2', name: 'Grah varivo s kruhom', items: 'Tanjur graha (s malo suhog mesa), kriška kruha', kcal: 500, protein: 24, note: 'Grah je pun proteina i vlakana. Ostatak je super sutradan.' },
    { id: 'l3', name: 'Tjestenina s tunom i rajčicom', items: '100 g tjestenine, konzerva tune, umak od rajčice, žlica maslinova ulja, malo naribanog sira', kcal: 720, protein: 42, note: 'Gotova za 15 minuta, a jako zasitna.' },
    { id: 'l4', name: 'Ćevapi u lepinji s kajmakom', items: '5 ćevapa, pola lepinje, žlica kajmaka, luk, salata', kcal: 600, protein: 26, note: 'Obrok za uživanje. Dodaj salatu sa strane.' },
    { id: 'l5', name: 'Sarma s pire krumpirom', items: '2 sarme, 200 g pirea', kcal: 600, protein: 26, note: 'Domaća hrana je super gorivo za mišiće.' },
    { id: 'l6', name: 'Riba s krumpirom i mahunama', items: '150 g oslića ili lososa, 250 g krumpira, mahune, žlica maslinova ulja', kcal: 560, protein: 34, note: 'S lososom je obrok još bogatiji energijom.' },
    { id: 'l7', name: 'Leća s jajetom i kruhom', items: 'Tanjur leće s povrćem, kuhano jaje, kriška kruha', kcal: 500, protein: 31, note: 'Jeftino, toplo i hranjivo.' },
  ],
  snacks: [
    { id: 's1', name: 'Jogurt, orasi i med', items: '180 g jogurta, šaka oraha (20 g), žličica meda', kcal: 270, protein: 9 },
    { id: 's2', name: 'Banana s kikiriki maslacem', items: 'Banana, žlica kikiriki maslaca', kcal: 200, protein: 5 },
    { id: 's3', name: 'Bademi i suhe marelice', items: '30 g badema, 3–4 suhe marelice', kcal: 235, protein: 7 },
    { id: 's4', name: 'Kefir i banana', items: '330 ml kefira, banana', kcal: 300, protein: 12 },
    { id: 's5', name: 'Kruh s kajmakom i rajčicom', items: 'Kriška kruha, 30 g kajmaka, rajčica', kcal: 210, protein: 5 },
    { id: 's6', name: 'Skuta s medom i voćem', items: '150 g skute, žličica meda, voće', kcal: 230, protein: 18 },
    { id: 's7', name: 'Dva kuhana jaja i kruh', items: '2 jaja, kriška kruha, prstohvat soli', kcal: 220, protein: 15 },
    { id: 's8', name: 'Mini sendvič s pršutom i sirom', items: 'Kriška kruha, 20 g pršuta, 20 g sira', kcal: 210, protein: 12 },
    { id: 's9', name: 'Energetske kuglice', items: '2 kuglice od datulja, zobenih i oraha (napravi 10 odjednom)', kcal: 220, protein: 5 },
    { id: 's10', name: 'Toplo kakao mlijeko i keksi', items: '250 ml mlijeka, žličica kakaa i meda, 3 keksa', kcal: 280, protein: 9 },
  ],
};

export const TIPS = {
  more: [
    { id: 't1', title: 'Jedi češće, ne više odjednom', text: 'Svaka 3–4 sata nešto malo. Lakše je pojesti pet manjih obroka nego tri ogromna.' },
    { id: 't2', title: 'Pij kalorije', text: 'Smoothie, mlijeko, kefir ili kakao lakše idu od još jednog tanjura, a ne opterete želudac.' },
    { id: 't3', title: 'Žlica maslinova ulja', text: 'Dodaj je u salatu, tjesteninu ili rižu. Dodaje energiju, a gotovo je i ne primijetiš.' },
    { id: 't4', title: 'Sir preko svega', text: 'Naribaj sir preko tjestenine i variva ili dodaj žlicu kajmaka. Ukusnije je i hranjivije.' },
    { id: 't5', title: 'Orašasti plodovi u džepu', text: 'Šaka badema ili oraha ima puno energije u malom volumenu. Drži vrećicu u torbi.' },
    { id: 't6', title: 'Voda poslije, ne prije jela', text: 'Velika čaša vode prije obroka napuni želudac. Pij je poslije ili između obroka.' },
    { id: 't7', title: 'Doručak bez izgovora', text: 'I mali doručak je bolji od nikakvog. Ako ujutro nisi gladna, popij smoothie.' },
    { id: 't8', title: 'Žlica više', text: 'Dodaj žlicu riže, krumpira ili tjestenine više nego inače. Malo po malo se zbroji.' },
  ],
  pre: [
    { id: 'p1', title: 'Banana i jogurt', text: '60–90 minuta prije treninga. Lagano, a daje energiju.' },
    { id: 'p2', title: 'Kruh s medom', text: '30–60 minuta prije, kad nema vremena za više.' },
    { id: 'p3', title: 'Zobena kaša', text: '1,5–2 sata prije, ako treniraš kasnije ujutro.' },
  ],
  post: [
    { id: 'r1', title: 'Jogurt s granolom', text: 'Brzo nakon treninga: proteini i ugljikohidrati u jednoj čaši.' },
    { id: 'r2', title: 'Čokoladno mlijeko', text: 'Ima i ugljikohidrate i proteine. Klasika za oporavak.' },
    { id: 'r3', title: 'Sendvič s jajem i sirom', text: 'Ako je ručak još daleko.' },
    { id: 'r4', title: 'Pravi obrok unutar 1–2 sata', text: 'Ne treba žuriti, ali ne preskači obrok nakon treninga.' },
  ],
  water: [
    { id: 'w1', title: '1,5–2 litre dnevno', text: 'Rasporedi kroz dan. Boca na stolu jako pomaže.' },
    { id: 'w2', title: 'Čaša prije treninga', text: 'Pola sata prije treninga popij čašu vode.' },
    { id: 'w3', title: 'Gutljaji između serija', text: 'Malo, ali često, dok odmaraš.' },
    { id: 'w4', title: 'Nakon šetnje i ljeti više', text: 'Urin svijetlo žute boje znak je da piješ dovoljno.' },
  ],
};

// ── Poruke ──────────────────────────────────────────────

export const MESSAGES = [
  'Snaga se gradi u malim, ponovljenim danima. Danas je jedan od njih.',
  'Ne moraš biti motivirana. Dovoljno je da kreneš.',
  'Kratki trening je i dalje trening.',
  'Tijelo pamti dosljednost, ne savršenstvo.',
  'Odmor je dio plana, a ne nagrada za njega.',
  'Danas nije natjecanje. Samo malo bolje od prošlog tjedna.',
  'Jača leđa, ravnije držanje, više energije. Sve se zbraja.',
  'Prvi set je uvijek najteži. Poslije ide samo od sebe.',
  'Hrana je gorivo. Večeras pojedi nešto fino.',
  'Nije bitno koliko je uteg težak. Bitno je da ga kontroliraš.',
  'Ponosi se i danima kad odradiš samo kratku verziju.',
  'Dobra forma vrijedi više od teže bučice.',
  'Mišići rastu dok spavaš. Rani odlazak u krevet je dio treninga.',
  'Loš dan? Kratka verzija traje 15 minuta i računa se.',
  'Ne treniraš za izgled. Treniraš za osjećaj.',
  'Jedan trening neće puno promijeniti. Dvanaest tjedana hoće.',
  'Polako je i dalje naprijed.',
  'Umorna si? Smanji kilažu, ne odustaj od dana.',
  'Zapisuj kilaže. Za mjesec dana ćeš se iznenaditi.',
  'Izdah kad dižeš, udah kad spuštaš.',
  'Snaga ti treba za život, ne samo za trening.',
  'Doručak nije opcija, nego početak treninga.',
  'Ne uspoređuj svoj prvi tjedan s nečijim pedesetim.',
  'Samopouzdanje dolazi iz obećanja koja održiš sebi.',
  'Pet minuta pokreta je više od nula.',
  'Mala pobjeda za danas: čaša vode prije treninga.',
  'Već to što si otvorila plan je korak.',
  'Kad je teško, smanji kilažu. Forma ostaje.',
  'Ramena dolje, prsa gore. Na treningu i izvan njega.',
  'Jako tijelo ti služi cijeli život.',
  'Svaki trening je ulog, a ne ispit.',
  'Tjedan ne mora biti savršen da bi bio dobar.',
  'Danas je dobar dan da podigneš nešto teško.',
  'Glazba, voda, ručnik. Spremna si.',
  'Napredak se ne vidi uvijek u ogledalu. Vidi se u bilješkama.',
  'Nisi lijena ako ti treba odmor. Pametna si.',
  'Hodanje je podcijenjena supermoć.',
  'Što više snage, to više energije za sve ostalo.',
  'Mišići vole proteine i san. Daj im oboje.',
  'Nema zabranjene hrane. Ima hrane koja te gura naprijed.',
  'Odradi danas, a sutrašnja Dora će ti biti zahvalna.',
  'Propustila si trening? Plan nije propao. Samo nastavi.',
  'Brza provjera: spusti ramena dalje od ušiju.',
  'Malo nelagode u mišićima je u redu. Oštra bol nije, tada stani.',
  'Danas probaj zadnje ponavljanje napraviti sporije.',
  'Malo što gradi samopouzdanje kao tijelo koje te sluša.',
  'Ti određuješ tempo. Plan je tu da ti pomogne.',
  'Jutro ili večer, nije bitno. Bitno je da se dogodi.',
  'Svaki put kad se vratiš, potvrđuješ tko si.',
  'Snaga nije veličina. Snaga je kontrola.',
  'Nema loših treninga, samo kraćih.',
  'Grickalica nakon treninga je obavezni dio programa.',
  'Uspoređuj se samo s Dorom od prošlog tjedna.',
  'Tvoje tijelo nije projekt za popravak. Ono je tvoj tim.',
  'Kilaža raste polako, a onda odjednom.',
  'Kad posumnjaš, sjeti se svog prvog treninga.',
  'Recept za danas: dobar san, dobar obrok, dobar set.',
  'Energija se ne pronađe. Ona se gradi.',
  'Rutina ne ovisi o raspoloženju. U tome je njena snaga.',
  'Nisi kasno krenula. Krenula si.',
  'Ne moram, nego mogu.',
  'Svaka kvačica je mali dokaz da možeš.',
  'Bez žurbe. Ovo je maraton s bučicama.',
  'Jaka guza, sretna leđa.',
  'Danas lijepo diši, polako spuštaj i uživaj u snazi.',
];

export const DONE_MESSAGES = [
  'Odrađeno! Ponosna budi na sebe.',
  'Još jedna kvačica. Bravo, Dora!',
  'To je to. Sad nešto fino pojedi.',
  'Jača si nego jučer.',
  'Super! Tijelo ti zahvaljuje.',
  'Gotovo. Dosljednost se isplati.',
];

export const ENERGY = [
  { v: 1, e: '😴', l: 'Prazno' },
  { v: 2, e: '🥱', l: 'Nisko' },
  { v: 3, e: '🙂', l: 'Okej' },
  { v: 4, e: '😊', l: 'Dobro' },
  { v: 5, e: '⚡', l: 'Puna' },
];

export const MOODS = [
  { v: 1, e: '😔', l: 'Tužno' },
  { v: 2, e: '😕', l: 'Bezveze' },
  { v: 3, e: '😐', l: 'Neutralno' },
  { v: 4, e: '🙂', l: 'Dobro' },
  { v: 5, e: '😄', l: 'Super' },
];

export const BADGES = [
  { id: 'first', icon: '🌱', name: 'Prvi korak', desc: 'Prvi odrađeni trening' },
  { id: 'strong-week', icon: '💪', name: 'Tjedan snage', desc: 'Sva tri treninga snage u jednom tjednu' },
  { id: 'full-week', icon: '🌸', name: 'Puni tjedan', desc: 'Svih 5 planiranih aktivnosti u tjednu' },
  { id: 'streak-7', icon: '🔥', name: 'Niz od 7', desc: '7 planiranih aktivnosti zaredom' },
  { id: 'ten', icon: '✨', name: 'Desetka', desc: '10 odrađenih aktivnosti' },
  { id: 'twentyfive', icon: '🏅', name: 'Četvrt stotine', desc: '25 odrađenih aktivnosti' },
  { id: 'plus25', icon: '🏋️', name: '+2,5 kg', desc: 'Na nekoj vježbi dižeš 2,5 kg više nego prvi put' },
  { id: 'logbook', icon: '📒', name: 'Bilježnica snage', desc: 'Kilaže zapisane na 5 treninga' },
  { id: 'walker', icon: '👟', name: 'Šetačica', desc: '10 odrađenih šetnji' },
  { id: 'mobile', icon: '🧘', name: 'Gipka', desc: '5 laganih istezanja u dane odmora' },
  { id: 'checkin', icon: '💬', name: 'Iskrena', desc: 'Prvi tjedni check-in' },
  { id: 'phase1', icon: '🥉', name: 'Faza 1 gotova', desc: 'Barem 12 od 20 aktivnosti u fazi Temelji' },
  { id: 'phase2', icon: '🥈', name: 'Faza 2 gotova', desc: 'Barem 12 od 20 aktivnosti u fazi Snaga' },
  { id: 'phase3', icon: '🥇', name: 'Faza 3 gotova', desc: 'Barem 12 od 20 aktivnosti u fazi Kontrola' },
];

// ── Zamjene vježbi (kad nešto boli ili ne paše) ──
export const SWAPS = {
  'goblet-squat': { to: 'glute-bridge', why: 'manje opterećuje koljena' },
  'reverse-lunge': { to: 'glute-bridge', why: 'bez pritiska na koljena i bez ravnoteže' },
  rdl: { to: 'glute-bridge', why: 'lakše za donja leđa' },
  'floor-press': { to: 'triceps-ext', why: 'manje rada za prsa i prednja ramena' },
  'one-arm-row': { to: 'bird-dog', why: 'leđa rade bez utega' },
  ohp: { to: 'lateral-raise', why: 'manji raspon, nježnije za ramena' },
  'glute-bridge': { to: 'rdl', why: 'guza radi stojeći' },
  'lateral-raise': { to: 'biceps-curl', why: 'ramena se odmaraju' },
  'biceps-curl': { to: 'one-arm-row', why: 'biceps radi uz leđa' },
  'triceps-ext': { to: 'floor-press', why: 'laktovi ne idu iznad glave' },
  plank: { to: 'dead-bug', why: 'bez oslonca na ramena' },
  'dead-bug': { to: 'bird-dog', why: 'drugi položaj za trup' },
  'bird-dog': { to: 'dead-bug', why: 'bez oslonca na koljena i dlanove' },
  'calf-raise': { to: 'glute-bridge', why: 'bez stajanja na prstima' },
};

// ── Mrvica: kratke poruke po stanju (bez krivnje, bez dijeta) ──
export const MASCOT_LINES = {
  first: ['Bok, ja sam Mrvica! Danas krećemo polako, zajedno.', 'Prvi tjedan je za upoznavanje pokreta. Bez žurbe.'],
  streak: ['{n} zaredom! Tvoja dosljednost me oduševljava.', 'Niz od {n}. Tako se gradi snaga.'],
  missed: ['Drago mi je da si tu. Krenimo od danas, bez gledanja unatrag.', 'Pauze se događaju. Danas je dobar dan za lagani povratak.'],
  pr: ['{ex}: {kg}! Novi rekord, ponosna sam na tebe.'],
  rest: ['Danas odmaraš, i to je dio treninga.', 'Mišići sad rastu. Uživaj u odmoru.'],
  walk: ['Danas lagana šetnja. Tempo za razgovor, uživaj.'],
  done: ['Odrađeno! Sad nešto fino pojedi.', 'Bravo! Danas si bila jača nego jučer.'],
  default: ['Spremna? Ja jesam!', 'Idemo polako i lijepo.'],
};

export const BUDDY_CHIPS = ['Ne ide mi danas', 'Što da jedem danas?', 'Kako napredujem?', 'Boli me nešto'];
