// Mrvica: originalna maskota, okrugli zečić-mochi s listićem na glavi.
// Jedna funkcija crta svaki izraz i pozu; prijelazi se interpoliraju oprugom, a idle petlja diše i trepće.

import { springTo, animate, reduced, tick } from './motion.js';

export const NAME = 'Mrvica';

// Izrazi: oči (w širina, t gornja krivulja, b donja), usta (lijevo, desno, gornja i donja kontrola), obrve, rumenilo.
const EXPR = {
  happy:       { ew: 4.2, et: 11, eb: 11, ml: [52, 76], mr: [68, 76], mt: 79, mb: 84, bro: 0, bt: 0, blush: 0.55 },
  excited:     { ew: 5, et: 13, eb: 13, ml: [50, 75], mr: [70, 75], mt: 75, mb: 89, bro: 0.8, bt: -3, blush: 0.75 },
  proud:       { ew: 4.6, et: 9, eb: -4, ml: [51, 76], mr: [69, 76], mt: 78, mb: 85, bro: 0.6, bt: -2, blush: 0.7 },
  sleepy:      { ew: 4.4, et: 2.2, eb: 1.2, ml: [56, 79], mr: [64, 79], mt: 78, mb: 81, bro: 0, bt: 0, blush: 0.35 },
  encouraging: { ew: 4.4, et: 11, eb: 9, ml: [51, 76], mr: [69, 76], mt: 79, mb: 86, bro: 0.6, bt: -1.5, blush: 0.6 },
  thinking:    { ew: 4, et: 10, eb: 8, ml: [55, 79], mr: [65, 78], mt: 78, mb: 80, bro: 0.8, bt: 2, blush: 0.4, look: [2.4, -2.4] },
  celebrating: { ew: 4.6, et: 10, eb: -4.5, ml: [49, 75], mr: [71, 75], mt: 75, mb: 91, bro: 0.7, bt: -3, blush: 0.85 },
  caring:      { ew: 4.2, et: 10, eb: 10, ml: [54, 79], mr: [66, 79], mt: 78.5, mb: 81.5, bro: 0.9, bt: 3, blush: 0.5 },
  shy:         { ew: 4, et: 9, eb: 7, ml: [55, 78], mr: [65, 78], mt: 78, mb: 82, bro: 0.5, bt: 2.5, blush: 0.95, look: [-1.5, 1.5] },
};

// Poze: kut ruku (0 = uz tijelo, 180 = gore), rekvizit, efekti.
const POSE = {
  idle:     { al: 12, ar: 12 },
  waving:   { al: 12, ar: 150, wave: true },
  flexing:  { al: 105, ar: 105, flex: true },
  dumbbell: { al: 14, ar: 62, prop: 'dumbbell' },
  resting:  { al: 6, ar: 6, zzz: true },
  cheering: { al: 138, ar: 138, sparkle: true },
  stretching: { al: 150, ar: 150, stretch: true },
  hug:      { al: 58, ar: 58, heart: true },
};

const NUM = ['ew', 'et', 'eb', 'mt', 'mb', 'bro', 'bt', 'blush', 'al', 'ar', 'lx', 'ly'];

function target(expr, pose) {
  const e = EXPR[expr] || EXPR.happy;
  const p = POSE[pose] || POSE.idle;
  return {
    ew: e.ew, et: e.et, eb: e.eb, mt: e.mt, mb: e.mb, bro: e.bro, bt: e.bt, blush: e.blush,
    ml0: e.ml[0], ml1: e.ml[1], mr0: e.mr[0], mr1: e.mr[1],
    al: p.al, ar: p.ar, lx: e.look?.[0] || 0, ly: e.look?.[1] || 0,
  };
}

let uid = 0;

function svgMarkup(id) {
  return `<svg class="mascot-svg" viewBox="0 0 120 120" aria-hidden="true" focusable="false">
  <defs>
    <radialGradient id="mb${id}" cx="0.38" cy="0.32" r="0.75">
      <stop offset="0" stop-color="var(--m-body-hi)"/><stop offset="0.65" stop-color="var(--m-body)"/><stop offset="1" stop-color="var(--m-body-lo)"/>
    </radialGradient>
    <radialGradient id="mg${id}" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#fff" stop-opacity="0.85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
  </defs>
  <ellipse class="m-shadow" cx="60" cy="111" rx="30" ry="4.5"/>
  <g class="m-all">
    <g class="m-squash">
      <g class="m-ear m-ear-l"><ellipse cx="44" cy="30" rx="9" ry="17" transform="rotate(-14 44 30)" fill="url(#mb${id})"/><ellipse cx="44" cy="31" rx="4.2" ry="10" transform="rotate(-14 44 31)" class="m-ear-in"/></g>
      <g class="m-ear m-ear-r"><ellipse cx="76" cy="30" rx="9" ry="17" transform="rotate(14 76 30)" fill="url(#mb${id})"/><ellipse cx="76" cy="31" rx="4.2" ry="10" transform="rotate(14 76 31)" class="m-ear-in"/></g>
      <g class="m-leaf"><path d="M60 26 C59 20 60 16 62 13" class="m-stem"/><path d="M62 14 C66 8 74 8 76 10 C73 16 66 18 62 14 Z" class="m-leaf-a"/><path d="M61 17 C57 12 51 12 49 14 C52 19 58 20 61 17 Z" class="m-leaf-b"/></g>
      <ellipse class="m-foot" cx="46" cy="104" rx="9" ry="5.5"/>
      <ellipse class="m-foot" cx="74" cy="104" rx="9" ry="5.5"/>
      <path class="m-body" d="M60 30 C88 30 100 52 100 74 C100 96 84 106 60 106 C36 106 20 96 20 74 C20 52 32 30 60 30 Z" fill="url(#mb${id})"/>
      <ellipse class="m-belly" cx="60" cy="88" rx="24" ry="15"/>
      <ellipse class="m-shine" cx="44" cy="46" rx="12" ry="7" transform="rotate(-25 44 46)" fill="url(#mg${id})"/>
      <g class="m-arm m-arm-l"><g class="m-arm-in"><rect x="-5" y="-2" width="10.5" height="23" rx="5.25" fill="url(#mb${id})"/><circle class="m-bicep" cx="0" cy="9" r="0" fill="url(#mb${id})"/></g></g>
      <g class="m-arm m-arm-r"><g class="m-arm-in"><rect x="-5" y="-2" width="10.5" height="23" rx="5.25" fill="url(#mb${id})"/><circle class="m-bicep" cx="0" cy="9" r="0" fill="url(#mb${id})"/><g class="m-prop"></g></g></g>
      <g class="m-face">
        <ellipse class="m-cheek" cx="38" cy="75" rx="7" ry="4.2"/>
        <ellipse class="m-cheek" cx="82" cy="75" rx="7" ry="4.2"/>
        <path class="m-brow m-brow-l"/><path class="m-brow m-brow-r"/>
        <g class="m-eyes"><g class="m-eye-l"><path class="m-eye"/><circle class="m-glint" r="1.5"/></g><g class="m-eye-r"><path class="m-eye"/><circle class="m-glint" r="1.5"/></g></g>
        <path class="m-mouth"/>
        <path class="m-tongue"/>
      </g>
    </g>
    <g class="m-fx"></g>
  </g>
</svg>`;
}

const FX = {
  zzz: '<g class="m-zzz"><text x="88" y="34">z</text><text x="96" y="24" font-size="10">z</text><text x="103" y="15" font-size="8">z</text></g>',
  sparkle: '<g class="m-sparkle"><path d="M16 26 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z"/><path d="M100 20 l1.6 4 4 1.6 -4 1.6 -1.6 4 -1.6 -4 -4 -1.6 4 -1.6z"/><path d="M106 60 l1.2 3 3 1.2 -3 1.2 -1.2 3 -1.2 -3 -3 -1.2 3 -1.2z"/></g>',
  heart: '<g class="m-heart"><path d="M96 30 c-3 -5 -10 -3 -9 3 c1 4 9 9 9 9 s8 -5 9 -9 c1 -6 -6 -8 -9 -3z"/></g>',
  dots: '<g class="m-dots"><circle cx="92" cy="30" r="3"/><circle cx="101" cy="22" r="2.4"/><circle cx="108" cy="14" r="1.8"/></g>',
};
const DUMBBELL = '<g class="m-db" transform="translate(0 22)"><rect x="-9" y="-1.6" width="18" height="3.2" rx="1.4"/><rect x="-12" y="-5" width="5" height="10" rx="2"/><rect x="7" y="-5" width="5" height="10" rx="2"/></g>';

export class Mascot {
  constructor(el, { expr = 'happy', pose = 'idle', size = 96, interactive = true, track = false, still = false, label } = {}) {
    this.el = el;
    this.id = ++uid;
    el.classList.add('mascot');
    el.style.setProperty('--m-size', `${size}px`);
    el.innerHTML = svgMarkup(this.id);
    el.setAttribute('role', 'img');
    el.setAttribute('aria-label', label || `${NAME}, tvoja prijateljica za trening`);
    this.q = (s) => el.querySelector(s);
    this.cur = target(expr, pose);
    this.expr = expr;
    this.pose = pose;
    this.look = [0, 0];
    this.draw(this.cur);
    this.setFx(pose, expr);
    // mirna Mrvica (npr. uz svaku poruku u chatu): bez petlji, da iPhone ne radi uzalud
    if (still) el.classList.add('m-still');
    else { this.blinkLoop(); this.idleExtras(); }
    if (interactive) {
      el.classList.add('tappable-m');
      el.tabIndex = 0;
      el.addEventListener('click', () => this.react());
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.react(); } });
    }
    if (track) this.trackPointer();
  }

  alive() { return this.el.isConnected; }

  draw(P) {
    const q = this.q;
    const eye = (cx, cy) => `M${cx - P.ew} ${cy} Q${cx} ${cy - P.et} ${cx + P.ew} ${cy} Q${cx} ${cy + P.eb} ${cx - P.ew} ${cy} Z`;
    const ex = this.look[0] + P.lx, ey = this.look[1] + P.ly;
    q('.m-eye-l .m-eye').setAttribute('d', eye(47 + ex, 64 + ey));
    q('.m-eye-r .m-eye').setAttribute('d', eye(73 + ex, 64 + ey));
    const open = Math.max(0, Math.min(1, (P.eb + 2) / 12));
    q('.m-eye-l .m-glint').setAttribute('cx', 48.6 + ex); q('.m-eye-l .m-glint').setAttribute('cy', 61 + ey);
    q('.m-eye-r .m-glint').setAttribute('cx', 74.6 + ex); q('.m-eye-r .m-glint').setAttribute('cy', 61 + ey);
    q('.m-eye-l .m-glint').style.opacity = open; q('.m-eye-r .m-glint').style.opacity = open;
    // usta: zatvoreni oblik, gornja i donja krivulja
    const mouth = `M${P.ml0} ${P.ml1} Q60 ${P.mt} ${P.mr0} ${P.mr1} Q60 ${P.mb} ${P.ml0} ${P.ml1} Z`;
    q('.m-mouth').setAttribute('d', mouth);
    const openMouth = Math.max(0, P.mb - P.mt - 6);
    q('.m-tongue').setAttribute('d', `M${60 - openMouth * 0.7} ${P.mb - 2.2} Q60 ${P.mb - 2.2 - openMouth * 0.55} ${60 + openMouth * 0.7} ${P.mb - 2.2} Q60 ${P.mb + 0.2} ${60 - openMouth * 0.7} ${P.mb - 2.2} Z`);
    q('.m-tongue').style.opacity = openMouth > 1 ? 1 : 0;
    // obrve (bt > 0 = zabrinuto, unutarnji krajevi gore)
    q('.m-brow-l').setAttribute('d', `M41 ${52 - P.bt * 0.2} Q46 ${49 - Math.abs(P.bt) * 0.2} 51 ${52 - P.bt}`);
    q('.m-brow-r').setAttribute('d', `M69 ${52 - P.bt} Q74 ${49 - Math.abs(P.bt) * 0.2} 79 ${52 - P.bt * 0.2}`);
    q('.m-brow-l').style.opacity = P.bro; q('.m-brow-r').style.opacity = P.bro;
    this.el.querySelectorAll('.m-cheek').forEach((c) => { c.style.opacity = P.blush; });
    // ruke: zakretanje oko ramena
    q('.m-arm-l').setAttribute('transform', `translate(28 68) rotate(${P.al})`);
    q('.m-arm-r').setAttribute('transform', `translate(92 68) rotate(${-P.ar})`);
  }

  // glatki prijelaz izraza i poze (opruga), nikad naglo
  set(expr = this.expr, pose = this.pose) {
    if (expr === this.expr && pose === this.pose) return this;
    const from = { ...this.cur };
    const to = target(expr, pose);
    const keys = Object.keys(to);
    this.expr = expr; this.pose = pose;
    this.stop?.();
    const big = pose !== this.lastPose && ['cheering', 'stretching', 'flexing'].includes(pose);
    this.lastPose = pose;
    if (big) this.anticipate();
    this.stop = springTo(0, 1, (k) => {
      if (!this.alive()) return;
      const P = {};
      for (const key of keys) P[key] = from[key] + (to[key] - from[key]) * k;
      this.cur = P;
      this.draw(P);
    }, { stiffness: 260, damping: 20 });
    this.setFx(pose, expr);
    return this;
  }

  setFx(pose, expr) {
    const p = POSE[pose] || {};
    let fx = '';
    if (p.zzz || expr === 'sleepy') fx += FX.zzz;
    if (p.sparkle || expr === 'proud' || expr === 'celebrating') fx += FX.sparkle;
    if (p.heart || expr === 'caring') fx += FX.heart;
    if (expr === 'thinking') fx += FX.dots;
    const fxEl = this.q('.m-fx');
    if (fxEl.dataset.fx !== fx) {
      fxEl.dataset.fx = fx;
      fxEl.innerHTML = fx;
      animate(fxEl, [{ opacity: 0, transform: 'scale(0.6)' }, { opacity: 1, transform: 'none' }], { spring: 'bouncy', fill: 'none' });
    }
    this.q('.m-prop').innerHTML = p.prop === 'dumbbell' ? DUMBBELL : '';
    this.el.querySelectorAll('.m-bicep').forEach((b) => b.setAttribute('r', p.flex ? 4.5 : 0));
    this.el.classList.toggle('m-waving', !!p.wave);
    this.el.classList.toggle('m-stretch', !!p.stretch);
    this.el.classList.toggle('m-resting', !!p.zzz || expr === 'sleepy');
    this.el.classList.toggle('m-caring', expr === 'caring');
    this.el.classList.toggle('m-thinking', expr === 'thinking');
  }

  // prirodno, nasumično treptanje
  blinkLoop() {
    if (reduced()) return;
    const next = () => {
      if (!this.alive()) return;
      if (!['sleepy'].includes(this.expr)) {
        const eyes = this.q('.m-eyes');
        eyes.animate([{ transform: 'scaleY(1)' }, { transform: 'scaleY(0.1)' }, { transform: 'scaleY(1)' }], { duration: 150, easing: 'ease-in-out' });
        if (Math.random() < 0.2) setTimeout(() => eyes.isConnected && eyes.animate([{ transform: 'scaleY(1)' }, { transform: 'scaleY(0.1)' }, { transform: 'scaleY(1)' }], { duration: 140 }), 220);
      }
      this.blinkT = setTimeout(next, 2200 + Math.random() * 3800);
    };
    this.blinkT = setTimeout(next, 900 + Math.random() * 2000);
  }

  // povremeno mrdanje ušima i naginjanje glave
  idleExtras() {
    if (reduced()) return;
    const next = () => {
      if (!this.alive()) return;
      const r = Math.random();
      if (r < 0.45) {
        const ear = this.q(Math.random() < 0.5 ? '.m-ear-l' : '.m-ear-r');
        const dir = ear.classList.contains('m-ear-l') ? -1 : 1;
        ear.animate([{ transform: 'rotate(0)' }, { transform: `rotate(${dir * 12}deg)` }, { transform: `rotate(${dir * -4}deg)` }, { transform: 'rotate(0)' }], { duration: 650, easing: 'ease-in-out' });
      } else if (r < 0.75) {
        const face = this.q('.m-all');
        const a = (Math.random() < 0.5 ? -1 : 1) * 5;
        face.animate([{ transform: 'rotate(0)' }, { transform: `rotate(${a}deg)`, offset: 0.35 }, { transform: `rotate(${a}deg)`, offset: 0.7 }, { transform: 'rotate(0)' }], { duration: 1800, easing: 'ease-in-out' });
      } else {
        this.q('.m-leaf').animate([{ transform: 'rotate(0)' }, { transform: 'rotate(10deg)' }, { transform: 'rotate(-6deg)' }, { transform: 'rotate(0)' }], { duration: 900, easing: 'ease-in-out' });
      }
      this.idleT = setTimeout(next, 3500 + Math.random() * 4500);
    };
    this.idleT = setTimeout(next, 2500 + Math.random() * 2000);
  }

  // oči prate prst ili kursor
  trackPointer() {
    if (reduced()) return;
    const onMove = (e) => {
      if (!this.alive()) { window.removeEventListener('pointermove', onMove); return; }
      const r = this.el.getBoundingClientRect();
      if (!r.width) return;
      const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height * 0.55);
      const d = Math.hypot(dx, dy) || 1;
      const m = Math.min(2.6, d / 60);
      this.look = [(dx / d) * m, (dy / d) * m * 0.8];
      if (!this.lookRaf) this.lookRaf = requestAnimationFrame(() => { this.lookRaf = 0; this.draw(this.cur); });
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerdown', onMove, { passive: true });
  }

  anticipate() {
    animate(this.q('.m-squash'), [{ transform: 'scale(1,1)' }, { transform: 'translateY(4px) scale(1.08,0.9)' }, { transform: 'scale(1,1)' }], { duration: 380, spring: 'default', fill: 'none' });
  }

  // skok sa squash-and-stretch: priprema, istezanje u zraku, spljoštenje pri slijetanju, prebačaj i smirivanje
  hop(height = 16) {
    if (reduced()) return Promise.resolve();
    const s = this.q('.m-squash');
    const k = [
      { transform: 'translateY(0) scale(1,1)', offset: 0 },
      { transform: 'translateY(3px) scale(1.12,0.86)', offset: 0.18 },
      { transform: `translateY(-${height}px) scale(0.92,1.1)`, offset: 0.45 },
      { transform: `translateY(-${height * 0.9}px) scale(1,1)`, offset: 0.58 },
      { transform: 'translateY(2px) scale(1.14,0.86)', offset: 0.8 },
      { transform: 'translateY(-1px) scale(0.98,1.03)', offset: 0.9 },
      { transform: 'translateY(0) scale(1,1)', offset: 1 },
    ];
    const sh = this.q('.m-shadow');
    sh.animate([{ transform: 'scale(1)' }, { transform: 'scale(0.7)', offset: 0.5 }, { transform: 'scale(1.05)', offset: 0.8 }, { transform: 'scale(1)' }], { duration: 640 });
    return s.animate(k, { duration: 640, easing: 'linear' }).finished.catch(() => {});
  }

  async dance() {
    if (reduced()) { this.set('celebrating', 'cheering'); return; }
    this.set('celebrating', 'cheering');
    const a = this.q('.m-all');
    await this.hop(18);
    await a.animate([{ transform: 'rotate(0)' }, { transform: 'rotate(-10deg)' }, { transform: 'rotate(10deg)' }, { transform: 'rotate(-8deg)' }, { transform: 'rotate(0)' }], { duration: 900, easing: 'ease-in-out' }).finished.catch(() => {});
    await this.hop(12);
  }

  lean() {
    if (reduced()) return;
    this.q('.m-all').animate([{ transform: 'none' }, { transform: 'translateX(-3px) rotate(-7deg) scale(1.03)', offset: 0.4 }, { transform: 'translateX(-2px) rotate(-5deg) scale(1.02)' }], { duration: 900, easing: 'ease-out', fill: 'forwards' });
  }

  unlean() { this.q('.m-all').getAnimations?.().forEach((a) => a.cancel()); }

  spin() {
    if (reduced()) return;
    animate(this.q('.m-squash'), [{ transform: 'scaleX(1)' }, { transform: 'scaleX(-1)', offset: 0.5 }, { transform: 'scaleX(1)' }], { duration: 700, spring: 'default', fill: 'none' });
  }

  giggle() {
    if (reduced()) return;
    this.q('.m-squash').animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-2px) rotate(-3deg)' }, { transform: 'translateX(2px) rotate(3deg)' }, { transform: 'translateX(-2px) rotate(-2deg)' }, { transform: 'translateX(0)' }], { duration: 500 });
  }

  wave() {
    const prev = [this.expr, this.pose];
    this.set('happy', 'waving');
    setTimeout(() => this.alive() && this.set(...prev), 1800);
  }

  // tap: nasumična slatka reakcija, ali nikad vesela kad je stanje brižno
  react() {
    tick();
    if (this.expr === 'caring' || this.expr === 'sleepy') { this.giggle(); return; }
    const prev = [this.expr, this.pose];
    const r = Math.floor(Math.random() * 4);
    if (r === 0) { this.set('excited', prev[1]); this.hop(); }
    if (r === 1) { this.set('happy', prev[1]); this.spin(); }
    if (r === 2) { this.wave(); return; }
    if (r === 3) { this.set('shy', prev[1]); this.giggle(); }
    clearTimeout(this.backT);
    this.backT = setTimeout(() => this.alive() && this.set(...prev), 1500);
  }

  destroy() { clearTimeout(this.blinkT); clearTimeout(this.idleT); this.stop?.(); }
}

// mala statična verzija (avatar u chatu): bez praćenja i bez tapkanja
export function mascotAvatar(el, expr = 'happy') {
  return new Mascot(el, { expr, size: 34, interactive: false, track: false, label: NAME });
}

export const EXPRESSIONS = Object.keys(EXPR);
export const POSES = Object.keys(POSE);
