// Glavni modul: 4 taba, prijelazi, trake, uvod s Mrvicom, postavke i zajedničke radnje.

import * as Today from './views/today.js';
import * as Plan from './views/plan.js';
import * as Nutrition from './views/nutrition.js';
import * as Buddy from './views/buddy.js';
import { startWorkout, workoutOpen } from './views/workout.js';
import { openProgress, openCheckin } from './views/progress.js';
import { store, toggleSaved, markDone, unmarkDone, removeMemory, editMemory, addMemory, setSwap } from './store.js';
import { sessionFor, weekOf, phaseOfWeek, evaluateBadges, TOTAL_WEEKS } from './engine.js';
import { icon } from './ui/icons.js';
import { openSheet, confirmSheet, sheetOpen } from './ui/sheet.js';
import { exerciseSheet, sessionSheet, swapSheet } from './ui/components.js';
import { toast, confetti } from './ui/feedback.js';
import { presentBadges } from './ui/celebrate.js';
import { initGlass, glassChanged } from './glass.js';
import { Mascot, NAME } from './mascot.js';
import { configured, telegramUser, getMemory, addMemoryApi, deleteMemoryApi, getStatus } from './api.js';
import { syncStats } from './sync.js';
import { installPress, viewTransition, stagger, reduced, easing } from './motion.js';
import { SAFETY, DONE_MESSAGES, EX } from './data.js';
import { $, $$, today, keyOf, fromKey, mondayOf, addDays, fmtDate, haptic, esc, pick } from './util.js';

const TABS = [
  { id: 'danas', name: 'Danas', icon: 'today', view: Today },
  { id: 'plan', name: 'Plan', icon: 'plan', view: Plan },
  { id: 'prehrana', name: 'Hrana', icon: 'food', view: Nutrition },
  { id: 'buddy', name: 'Buddy', icon: 'chat', view: Buddy },
];
// stari linkovi i dalje rade: Spremljeno je sad unutar Plana
const LEGACY = { vjezbe: 'plan', napredak: 'danas', spremljeno: 'plan' };

const main = $('#view');
const tabbar = $('#tabbar');
const capsule = $('#capsule');
const scrollPos = {};
let currentTab = null;

// ── Trake ──

function buildTabbar() {
  tabbar.innerHTML = `<span class="tab-pill" aria-hidden="true"><span class="tab-pill-in"></span></span>` + TABS.map((t) => `<a href="#${t.id}" class="tab" data-tab="${t.id}" aria-label="${t.name}">
    ${icon(t.icon)}<span>${t.name}</span></a>`).join('');
}

// klizna kapsula aktivnog taba: opruga + lagano "želatinasto" rastezanje dok putuje
let pillIdx = null;
function movePill(idx) {
  const pill = tabbar.querySelector('.tab-pill');
  const from = pillIdx;
  pillIdx = idx;
  tabbar.style.setProperty('--tab-i', idx);
  if (!pill || from == null || from === idx || reduced() || !pill.animate) return;
  const d = Math.min(3, Math.abs(idx - from));
  const inner = pill.firstElementChild || pill;
  pill.getAnimations().forEach((a) => a.cancel());
  inner.getAnimations().forEach((a) => a.cancel());
  // položaj: iOS opruga ; oblik: rastegne se dok putuje pa se vrati
  pill.animate([{ transform: `translateX(${from * 100}%)` }, { transform: `translateX(${idx * 100}%)` }], { duration: 700, easing: easing('default') });
  inner.animate([
    { transform: 'scale(1, 1)' },
    { transform: `scale(${1 + 0.14 * d}, ${1 - 0.06 * d})`, offset: 0.35 },
    { transform: 'scale(1, 1)' },
  ], { duration: 520, easing: 'ease-in-out' });
  const ic = tabbar.querySelectorAll('.tab')[idx]?.querySelector('.ic');
  ic?.animate([{ transform: 'scale(1)' }, { transform: 'scale(0.82)', offset: 0.25 }, { transform: 'scale(1)' }], { duration: 900, easing: easing('bouncy') });
}

// gornja kapsula je maknuta radi jednostavnosti; funkcija ostaje da ostatak koda radi isto
function setCapsule(text) {
  const span = capsule?.querySelector('.cap-text');
  if (span && span.textContent !== text) span.textContent = text;
}

function capsuleDefault() {
  const w = weekOf(today());
  if (w < 1) return 'Plan uskoro počinje';
  if (w > TOTAL_WEEKS) return 'Plan završen 🎉';
  return `Tjedan ${w} · ${phaseOfWeek(w).name}`;
}

// Veliki naslov se skuplja pri skrolanju (kao na iOS-u), a mali naslov se pojavi u kapsuli.
let scrolled = false, ticking = false;
main.addEventListener('scroll', () => {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(() => {
    ticking = false;
    const y = main.scrollTop;
    const lh = main.querySelector('.large-head');
    if (lh && !reduced()) {
      const p = Math.max(0, Math.min(1, y / 70));
      lh.style.transform = `translateY(${p * 6}px) scale(${1 - p * 0.08})`;
      lh.style.opacity = String(1 - p * 0.9);
    }
    const s = y > 56;
    if (s !== scrolled) {
      scrolled = s;
      setCapsule(s ? TABS.find((t) => t.id === currentTab).name : capsuleDefault());
    }
  });
}, { passive: true });

// ── Navigacija (hash, stanje po tabu, bez ponovnog učitavanja) ──

function renderView() {
  TABS.find((t) => t.id === currentTab).view.render(main);
}

function go(id, { replace = false } = {}) {
  if (id === 'spremljeno') Plan.setMode('spremljeno');
  if (id === 'vjezbe') Plan.setMode('vjezbe');
  id = LEGACY[id] || id;
  const tab = TABS.find((t) => t.id === id) || TABS[0];
  if (currentTab) scrollPos[currentTab] = main.scrollTop;
  const changed = currentTab !== tab.id;
  const first = currentTab == null;
  currentTab = tab.id;
  document.title = tab.id === 'danas' ? 'Dorin trening' : `${tab.name} · Dorin trening`;
  $$('.tab', tabbar).forEach((a, i) => {
    const on = a.dataset.tab === tab.id;
    a.classList.toggle('on', on);
    if (on) { a.setAttribute('aria-current', 'page'); movePill(i); } else a.removeAttribute('aria-current');
  });
  document.body.classList.toggle('tab-buddy', tab.id === 'buddy');
  const update = () => {
    renderView();
    if (changed) {
      main.scrollTop = tab.id === 'buddy' ? main.scrollHeight : scrollPos[tab.id] || 0;
      scrolled = main.scrollTop > 56;
      setCapsule(scrolled ? tab.name : capsuleDefault());
    }
  };
  if (changed && !first) {
    viewTransition(update, main);
    requestAnimationFrame(() => stagger(main.querySelectorAll(':scope > .glass-card, :scope > section, :scope > .stack > *, :scope > .ex-grid > *'), { step: 30, max: 8 }));
  } else update();
  Buddy.updateUnread();
  setTimeout(glassChanged, 60);
  if (replace) history.replaceState(null, '', `#${tab.id}`);
}

window.addEventListener('hashchange', () => go(location.hash.slice(1)));
tabbar.addEventListener('click', (e) => {
  const a = e.target.closest('.tab');
  if (!a) return;
  e.preventDefault();
  haptic();
  if (a.dataset.tab === currentTab) {
    main.scrollTo({ top: a.dataset.tab === 'buddy' ? main.scrollHeight : 0, behavior: reduced() ? 'auto' : 'smooth' });
    return;
  }
  history.pushState(null, '', `#${a.dataset.tab}`);
  go(a.dataset.tab);
});

// osvježi ekran kad se podaci promijene (Buddy se osvježava sam zbog streaminga)
let doneSig = JSON.stringify(store.get().done);
store.subscribe((st) => {
  // nakon odrađenog treninga (ili check-ina) tiho pošalji statistiku na backend
  const ds = JSON.stringify(st.done) + st.checkins.length;
  if (ds !== doneSig) { doneSig = ds; syncStats({ delay: 1500 }); }
  if (!currentTab) return;
  const tab = TABS.find((t) => t.id === currentTab);
  if (tab.view.live) return;
  const y = main.scrollTop;
  renderView();
  main.scrollTop = y;
});

// ── Zajedničke radnje (delegirano) ──

function celebrate(btn, kind) {
  haptic('success');
  confetti(btn);
  toast(esc(pick(DONE_MESSAGES, Date.now() % 101)), { icon: kind === 'walk' ? '👟' : kind === 'mobility' ? '🧘' : '💪' });
  main._mascot?.dance?.();
  presentBadges(evaluateBadges());
}

function markFor(s, btn) {
  const kind = s.type === 'rest' ? 'mobility' : s.type;
  markDone(s.key, kind);
  celebrate(btn, kind);
}

const begin = (s, short = false) => startWorkout(s, { short });
const sheetFor = (s) => sessionSheet(s, { onStart: (x) => begin(x), onShort: (x) => begin(x, true), onDone: markFor });

document.addEventListener('click', async (e) => {
  const save = e.target.closest('[data-save]');
  if (save) {
    e.preventDefault();
    e.stopPropagation();
    const key = save.dataset.save;
    const on = toggleSaved(key);
    haptic();
    $$(`[data-save="${CSS.escape(key)}"]`).forEach((b) => {
      b.classList.toggle('on', on);
      b.setAttribute('aria-pressed', on);
      b.innerHTML = icon(on ? 'bookmarkFill' : 'bookmark');
      b.setAttribute('aria-label', b.getAttribute('aria-label').replace(/^(Spremi|Makni iz spremljenog)/, on ? 'Makni iz spremljenog' : 'Spremi'));
      if (on && !reduced()) { b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop'); }
    });
    toast(on ? 'Spremljeno' : 'Maknuto iz spremljenog', { icon: on ? '🔖' : '', ms: 1500 });
    return;
  }
  const askEl = e.target.closest('[data-ask]');
  if (askEl) { haptic(); const top = document.querySelector('.sheet-layer'); if (top) document.querySelectorAll('.sheet-x').forEach((x) => x.click()); Buddy.ask(askEl.dataset.ask); return; }
  const swapEl = e.target.closest('[data-swap-ex]');
  if (swapEl) { haptic(); swapSheet(swapEl.dataset.swapEx); return; }
  const ex = e.target.closest('[data-ex]');
  if (ex && !e.target.closest('.workout')) { haptic(); exerciseSheet(ex.dataset.ex); return; }

  const day = e.target.closest('[data-day]');
  if (day) { haptic(); sheetFor(sessionFor(fromKey(day.dataset.day))); return; }

  const act = e.target.closest('[data-act]');
  if (act && main.contains(act)) {
    const s = sessionFor(today());
    const a = act.dataset.act;
    if (a === 'start') { e.stopPropagation(); haptic(); begin(s); return; }
    if (a === 'undo') {
      e.stopPropagation();
      const ok = await confirmSheet({ title: 'Poništiti oznaku?', text: 'Današnja aktivnost više neće biti označena kao odrađena. Zapisane kilaže ostaju.', confirm: 'Poništi', destructive: true });
      if (ok) { unmarkDone(s.key); haptic(); }
      return;
    }
    if (a === 'details') { haptic(); sheetFor(s); }
    if (a === 'progress') { haptic(); openProgress(); }
    if (a === 'checkin') { haptic(); openCheckin(); }
  }
});

// ── Postavke (uključujući "Što Buddy zna o meni") ──

// pamćenje: dijeljeno s Telegramom preko /memory; bez backenda lokalni popis
async function loadMemory() {
  if (!configured()) return { facts: store.get().memory, source: 'local' };
  try {
    const facts = await getMemory();
    store.set({ memory: facts.map((f) => ({ id: f.id, text: f.text, ts: Date.now(), noId: f.noId })) });
    return { facts: store.get().memory, source: 'server' };
  } catch {
    return { facts: store.get().memory, source: 'offline' };
  }
}

function settings() {
  haptic();
  const body = document.createElement('div');
  const sh = openSheet({ title: 'Postavke', body, full: true });
  let mem = { facts: store.get().memory, source: configured() ? 'loading' : 'local' };
  let tgStatus = null;
  const draw = () => {
    const st = store.get();
    const persistent = store.persistent();
    const swaps = Object.entries(st.swaps || {});
    const ro = mem.source === 'offline' || mem.source === 'loading';
    const tg = telegramUser();
    body.innerHTML = `
      ${persistent ? '' : `<p class="callout warn">${icon('info')}<span>Preglednik trenutno ne dopušta spremanje. Napredak će se izgubiti kad zatvoriš stranicu. Isključi privatni način rada.</span></p>`}
      <h3 class="group-title">${icon('brain')} Što Buddy zna o meni</h3>
      <p class="muted small">${mem.source === 'server' ? 'Ovo Mrvica pamti i na webu i na Telegramu (najviše 20). Promjena ovdje vrijedi svugdje.'
        : mem.source === 'loading' ? 'Učitavam…'
          : mem.source === 'offline' ? 'Buddy se malo odmara, probaj za par minuta 💛 Dok se ne javi, popis se samo prikazuje.'
            : 'Mrvica pamti važne stvari iz razgovora (najviše 20). Možeš ih urediti ili obrisati.'}</p>
      <div class="list-group mem-list">
        ${mem.facts.length ? mem.facts.map((m) => `<div class="list-row mem-row"><input id="mem-${esc(m.id)}" class="mem-in" value="${esc(m.text)}" data-mem="${esc(m.id)}" aria-label="Činjenica" ${ro ? 'readonly' : ''}>${ro ? '' : `<button class="icon-btn" data-delmem="${esc(m.id)}" aria-label="Obriši: ${esc(m.text)}">${icon('close')}</button>`}</div>`).join('') : '<div class="list-row"><span class="lr-sub">Još ništa. Kad Mrvici kažeš nešto važno, npr. da te boli koljeno, zapamtit će to.</span></div>'}
        ${ro ? '' : `<div class="list-row mem-row"><input id="mem-new" class="mem-in" placeholder="Dodaj, npr. ne voli jaja" data-memnew aria-label="Nova činjenica"><button class="icon-btn" data-addmem aria-label="Dodaj">${icon('plus')}</button></div>`}
      </div>
      ${configured() && tg ? `<article class="glass-card tg-card">
        <div class="card-row"><h3 class="card-title">${icon('plane')} Buddy na Telegramu</h3>${tgStatus ? `<span class="pill ${tgStatus.connected ? 'pill-sage' : 'pill-butter'}">${tgStatus.connected ? 'Povezano' : 'Nije povezano'}</span>` : ''}</div>
        <p class="muted small">Buddy ti može pisati prvi, čak i kad aplikacija nije otvorena.</p>
        <ol class="tg-steps"><li>Tapni „Otvori Telegram”</li><li>Pritisni <b>Start</b></li><li>Gotovo!</li></ol>
        <a class="btn btn-primary tg-btn" href="https://t.me/${encodeURIComponent(tg)}" target="_blank" rel="noopener">${icon('plane')} Otvori Telegram</a>
        <p class="muted small tg-note">Najviše 1–2 poruke dnevno i nikad noću. Za pauzu pošalji <b>/stop</b> u Telegramu.</p>
      </article>` : ''}
      ${swaps.length ? `<h3 class="group-title">Zamijenjene vježbe</h3><div class="list-group">${swaps.map(([from, to]) => `<div class="list-row"><span class="lr-main"><span class="lr-label">${esc(EX[from].name)}</span><span class="lr-sub">→ ${esc(EX[to].name)}</span></span><button class="btn-text small" data-unswap="${from}">Vrati</button></div>`).join('')}</div>` : ''}
      <h3 class="group-title">Početak plana</h3>
      <div class="list-group">
        <label class="list-row"><span class="lr-label">Tjedan 1 počinje</span>
          <input type="date" id="start-date" class="date-in" value="${keyOf(mondayOf(fromKey(st.startDate || keyOf(today()))))}" data-start aria-label="Datum početka plana"></label>
      </div>
      <p class="footnote">Plan uvijek počinje u ponedjeljak odabranog tjedna.</p>
      <h3 class="group-title">Buddy</h3>
      <p class="muted small">${configured() ? 'Mrvica vidi tvoje treninge, check-ine i ono što pamti, i ništa drugo. Brojke se šalju tiho nakon svakog treninga.' : 'Osnovni način: Mrvica odgovara bez interneta.'}</p>
      <h3 class="group-title">Na početni zaslon</h3>
      <p class="muted small">Android (Chrome): izbornik ⋮, pa „Dodaj na početni zaslon”. iPhone (Safari): Dijeli, pa „Dodaj na početni zaslon”.</p>
      <h3 class="group-title">Sigurnost</h3>
      <p class="muted small">${esc(SAFETY)}</p>
      <h3 class="group-title">Podaci</h3>
      <p class="muted small">Treninzi i kilaže spremaju se na ovom uređaju${configured() ? ', a razgovor i ono što Mrvica pamti čuvaju se kod Buddyja da budu isti i na Telegramu' : ''}.</p>
      <div class="btn-stack"><button class="btn btn-destructive-plain" data-reset>Obriši sav napredak na ovom uređaju</button></div>`;

    const reload = async () => { mem = await loadMemory(); draw(); };
    body.querySelectorAll('[data-mem]').forEach((inp) => inp.addEventListener('change', async () => {
      const id = inp.dataset.mem;
      const v = inp.value.trim();
      if (mem.source === 'server') {
        // nema PUT-a u ugovoru: uređivanje = brisanje + novi zapis
        try { await deleteMemoryApi(id); if (v) await addMemoryApi(v); } catch { toast('Buddy se malo odmara, probaj za par minuta 💛'); }
        reload();
      } else { if (v) editMemory(id, v); else removeMemory(id); mem = { facts: store.get().memory, source: mem.source }; draw(); }
    }));
    body.querySelectorAll('[data-delmem]').forEach((b) => b.addEventListener('click', async () => {
      haptic();
      if (mem.source === 'server') {
        try { await deleteMemoryApi(b.dataset.delmem); toast('Obrisano i na Telegramu', { icon: '🗑️' }); } catch { toast('Buddy se malo odmara, probaj za par minuta 💛'); }
        reload();
      } else { removeMemory(b.dataset.delmem); mem = { facts: store.get().memory, source: mem.source }; draw(); }
    }));
    const add = async () => {
      const inp = body.querySelector('[data-memnew]');
      const v = inp.value.trim();
      if (!v) return;
      haptic();
      if (mem.source === 'server') { try { await addMemoryApi(v); } catch { toast('Buddy se malo odmara, probaj za par minuta 💛'); } reload(); }
      else if (addMemory(v)) { mem = { facts: store.get().memory, source: mem.source }; draw(); }
    };
    body.querySelector('[data-addmem]')?.addEventListener('click', add);
    body.querySelector('[data-memnew]')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
    body.querySelectorAll('[data-unswap]').forEach((b) => b.addEventListener('click', () => { setSwap(b.dataset.unswap, null); draw(); }));
    body.querySelector('[data-start]').addEventListener('change', (e) => {
      if (!e.target.value) return;
      store.set({ startDate: keyOf(mondayOf(fromKey(e.target.value))) });
      setCapsule(capsuleDefault());
      toast(`Plan počinje ${fmtDate(mondayOf(fromKey(e.target.value)), false)}`, { icon: '📅' });
      syncStats({ delay: 500, force: true });
    });
    body.querySelector('[data-reset]').addEventListener('click', async () => {
      const ok = await confirmSheet({ title: 'Obrisati sav napredak?', text: 'Brišu se treninzi, kilaže, check-ini, spremljeno i razgovor na ovom uređaju. To se ne može vratiti.', confirm: 'Obriši', destructive: true });
      if (ok) { store.reset(); sh.close(); toast('Napredak obrisan. Novi početak!', { icon: '🌱' }); }
    });
  };
  draw();
  if (configured()) {
    loadMemory().then((m) => { mem = m; draw(); });
    getStatus().then((s) => { if (s) { tgStatus = s; draw(); } });
  }
}
$('#settings-btn').addEventListener('click', settings);

// ── Uvod: Mrvica se predstavlja ──

function onboarding() {
  const ov = document.createElement('div');
  ov.className = 'onboard';
  ov.setAttribute('role', 'dialog');
  ov.setAttribute('aria-modal', 'true');
  ov.setAttribute('aria-labelledby', 'ob-title');
  const mon = mondayOf(today());
  const nextMon = addDays(mon, 7);
  const isMonday = keyOf(mon) === keyOf(today());
  ov.innerHTML = `
    <div class="ob-inner">
      <div class="ob-m"></div>
      <h1 class="ob-title" id="ob-title">Bok Dora <span aria-hidden="true">👋</span></h1>
      <p class="ob-lead">Ja sam ${NAME}. Zajedno idemo kroz 12 tjedana snage kod kuće: tri treninga s bučicama i dvije lagane šetnje tjedno. Polako i bez pritiska.</p>
      <div class="segmented ob-seg" role="radiogroup" aria-label="Kada počinješ" style="--n:2;--i:0">
        <span class="seg-thumb" aria-hidden="true"></span>
        <button role="radio" aria-checked="true" class="on" data-when="now">${isMonday ? 'Krećem danas' : 'Ovaj tjedan'}</button>
        <button role="radio" aria-checked="false" data-when="next">Od ${fmtDate(nextMon, false)}</button>
      </div>
      <button class="btn btn-primary big" data-go>Krenimo</button>
      <p class="ob-safe">${icon('info')} Ako osjetiš oštru bol ili vrtoglavicu, stani. Budući da je tvoj BMI na nižoj granici, vrijedi se javiti liječniku ili nutricionistu.</p>
    </div>`;
  document.body.append(ov);
  const m = new Mascot(ov.querySelector('.ob-m'), { expr: 'happy', pose: 'waving', size: 140 });
  setTimeout(() => m.hop(16), 700);
  requestAnimationFrame(() => ov.classList.add('in'));
  let when = 'now';
  const seg = ov.querySelector('.ob-seg');
  ov.querySelectorAll('[data-when]').forEach((b, i) => b.addEventListener('click', () => {
    when = b.dataset.when;
    seg.style.setProperty('--i', i);
    ov.querySelectorAll('[data-when]').forEach((x) => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-checked', on); });
    haptic();
  }));
  ov.querySelector('[data-go]').focus();
  ov.querySelector('[data-go]').addEventListener('click', () => {
    haptic('success');
    m.set('excited', 'cheering');
    m.hop(20);
    store.set({ onboarded: true, startDate: keyOf(when === 'now' ? mon : nextMon) });
    setCapsule(capsuleDefault());
    setTimeout(() => {
      ov.classList.remove('in');
      ov.classList.add('out');
      setTimeout(() => ov.remove(), reduced() ? 0 : 500);
    }, reduced() ? 0 : 650);
  });
}

// segmentirane kontrole: klizni "thumb"
document.addEventListener('click', (e) => {
  const b = e.target.closest('.segmented [data-val]');
  if (!b) return;
  const seg = b.parentElement;
  const idx = [...seg.querySelectorAll('[data-val]')].indexOf(b);
  seg.style.setProperty('--i', idx);
}, true);

// ── Pokretanje ──

buildTabbar();
installPress();
Buddy.initBar();
go(location.hash.slice(1) || 'danas', { replace: true });
setCapsule(capsuleDefault());
if (!store.get().onboarded) onboarding();

initGlass().then((mode) => { document.documentElement.dataset.glass = mode; });

// otvaranje i povratak u aplikaciju: tiha sinkronizacija i provjera novih poruka s Telegrama
syncStats({ delay: 3000 });
setTimeout(() => Buddy.refresh(), 2500);
let lastDay = keyOf(today());
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') { syncStats(); Buddy.refresh(); }
  if (document.visibilityState === 'visible' && keyOf(today()) !== lastDay) {
    lastDay = keyOf(today());
    setCapsule(capsuleDefault());
    if (!sheetOpen() && !workoutOpen()) renderView();
  }
});

if ('serviceWorker' in navigator && location.protocol === 'https:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}
