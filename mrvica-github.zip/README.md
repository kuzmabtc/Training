# Dorin trening

Aplikacija za trening kod kuće (PWA). Čisti HTML, CSS i JavaScript, bez builda.

## Objava na GitHub Pages

1. Na GitHubu napravi novi repozitorij (npr. `dora-trening`).
2. **Add file → Upload files** i ubaci SVE datoteke iz ovog zipa (ne mapu, nego ono što je u njoj; `index.html` mora biti na vrhu).
3. **Settings → Pages → Source: Deploy from a branch → Branch: main / (root) → Save.**
4. Za minutu-dvije stranica je na `https://KORISNIK.github.io/dora-trening/`.

## Sigurnost

- U ovom kodu **nema** AI ni Telegram ključeva. Oni žive samo na Val Townu.
- `js/config.js` sadrži samo adresu Buddy backenda, `APP_SECRET` i ime bota. To se ionako vidi u pregledniku, pa je u redu da je javno.
- Pravu zaštitu radi backend: `ALLOWED_ORIGIN` = `https://KORISNIK.github.io`, provjera Origin zaglavlja i ograničenje broja poruka.
