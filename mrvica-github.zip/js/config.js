// Postavke za Buddy backend (Val Town). U ovoj datoteci NEMA AI ključa: ključevi žive samo na backendu.
// Zalijepi vrijednosti umjesto PASTE_..._HERE.

export const BUDDY_API_URL = 'https://buddy-dora.val.run';
export const APP_SECRET = 'mrvica-dora-zeko-2026'; // isti APP_SECRET mora biti u Val Town okruženju
export const TELEGRAM_BOT_USERNAME = 'Mrvicaabot'; // bez @, npr. DorinBuddyBot
