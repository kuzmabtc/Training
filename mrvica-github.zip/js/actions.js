// Izvršavanje Buddy akcija. Svaka akcija je na bijeloj listi i pokreće se tek kad Dora tapne gumb.

import { ACTIONS, validateAction } from './ai.js';
import { sessionFor } from './engine.js';
import { store, toggleSaved, isSaved, addNote, markDone } from './store.js';
import { today, keyOf } from './util.js';
import { toast } from './ui/feedback.js';
import { sessionSheet, swapSheet, noteSheet } from './ui/components.js';
import { openProgress } from './views/progress.js';
import { startWorkout } from './views/workout.js';

export const actionLabel = (a) => ACTIONS[a.id];

export function runAction(raw, { messageText } = {}) {
  const a = validateAction(raw);
  if (!a) return;
  const s = sessionFor(today());
  switch (a.id) {
    case 'save':
      if (a.key) { if (!isSaved(a.key)) toggleSaved(a.key); toast('Spremljeno', { icon: '🔖' }); }
      else if (messageText) { addNote(messageText, keyOf(today())); toast('Poruka spremljena u Spremljeno', { icon: '🔖' }); }
      break;
    case 'open_today':
      sessionSheet(s, {
        onStart: (x) => startWorkout(x),
        onShort: (x) => startWorkout(x, { short: true }),
        onDone: (x) => markDone(x.key, x.type === 'rest' ? 'mobility' : x.type),
      });
      break;
    case 'start_short':
      if (s.type === 'strength') startWorkout(s, { short: true });
      else { toast('Danas nije trening snage. Otvaram današnji plan.', { icon: '📅' }); runAction({ id: 'open_today' }); }
      break;
    case 'swap': swapSheet(a.ex); break;
    case 'add_note': noteSheet(); break;
    case 'show_progress': openProgress(); break;
    default: break;
  }
}

export { store };
