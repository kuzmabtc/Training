// iOS-stil sheet: hvataljka, povlačenje prema dolje za zatvaranje, gumb za zatvaranje, Escape.

import { icon } from './icons.js';
import { reducedMotion, haptic } from '../util.js';
import { springTo, rubberband, animate } from '../motion.js';

const stack = [];

export function openSheet({ title = '', body, full = false, onClose, className = '', label } = {}) {
  const layer = document.createElement('div');
  layer.className = 'sheet-layer';
  layer.innerHTML = `
    <div class="sheet-dim" data-close></div>
    <section class="sheet material ${full ? 'sheet-full' : ''} ${className}" role="dialog" aria-modal="true" aria-label="${label || title || 'Detalji'}">
      <div class="sheet-grab" aria-hidden="true"><span></span></div>
      <header class="sheet-head">
        <h2 class="sheet-title">${title}</h2>
        <button class="icon-btn sheet-x" data-close aria-label="Zatvori">${icon('close')}</button>
      </header>
      <div class="sheet-body"></div>
    </section>`;
  const sheet = layer.querySelector('.sheet');
  const bodyEl = layer.querySelector('.sheet-body');
  if (typeof body === 'string') bodyEl.innerHTML = body;
  else if (body) bodyEl.append(body);
  document.body.append(layer);
  document.body.classList.add('has-sheet');
  const prevFocus = document.activeElement;

  requestAnimationFrame(() => {
    layer.classList.add('open');
    sheet.querySelector('.sheet-x')?.focus({ preventScroll: true });
  });

  // povlačenje za zatvaranje: gumica prema gore, opruga natrag, brzi potez zatvara
  let startY = null, dy = 0, fromBody = false, lastY = 0, lastT = 0, vel = 0, stopSpring = null;
  function onDown(e) {
    const inHead = e.target.closest('.sheet-grab, .sheet-head');
    if (!inHead && e.target.closest('input, textarea, button, select, a, [data-nodrag]')) return;
    fromBody = !inHead && bodyEl.scrollTop <= 0;
    if (!inHead && !fromBody) return;
    stopSpring?.();
    startY = e.clientY; dy = 0; lastY = e.clientY; lastT = performance.now(); vel = 0;
  }
  function onMove(e) {
    if (startY == null) return;
    const raw = e.clientY - startY;
    if (fromBody && raw < 8) { if (raw < 0) startY = null; return; }
    const now = performance.now();
    vel = (e.clientY - lastY) / Math.max(1, now - lastT);
    lastY = e.clientY; lastT = now;
    dy = raw < 0 ? rubberband(raw, 260) : raw;
    sheet.style.transition = 'none';
    sheet.style.transform = `translateY(${dy}px)`;
  }
  function onUp() {
    if (startY == null) return;
    startY = null;
    if (dy > 120 || (vel > 0.7 && dy > 20)) { haptic(); close(vel); return; }
    const from = dy;
    stopSpring = springTo(from, 0, (v) => { sheet.style.transform = `translateY(${v}px)`; }, { stiffness: 380, damping: 30, velocity: vel * 1000, onDone: () => { sheet.style.transform = ''; sheet.style.transition = ''; } });
    dy = 0;
  }
  sheet.addEventListener('pointerdown', onDown);
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
  window.addEventListener('pointercancel', onUp);

  let closed = false;
  function close(v = 0) {
    if (closed) return;
    closed = true;
    stopSpring?.();
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('pointercancel', onUp);
    if (sheet.style.transform && !reducedMotion()) {
      sheet.style.transition = `transform ${Math.max(180, 320 - v * 80)}ms cubic-bezier(0.2, 0.9, 0.3, 1)`;
      requestAnimationFrame(() => { sheet.style.transform = 'translateY(105%)'; });
    }
    layer.classList.remove('open');
    layer.classList.add('closing');
    const done = () => {
      layer.remove();
      const i = stack.indexOf(api);
      if (i >= 0) stack.splice(i, 1);
      if (!stack.length) document.body.classList.remove('has-sheet');
      prevFocus?.focus?.({ preventScroll: true });
      onClose?.();
    };
    if (reducedMotion()) done(); else setTimeout(done, 320);
  }

  layer.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) close(); });
  // ulazak sheeta opružno, sadržaj lagano kasni (stagger)
  requestAnimationFrame(() => animate(bodyEl, [{ opacity: 0.4, transform: 'translateY(14px)' }, { opacity: 1, transform: 'none' }], { spring: 'gentle', delay: 60, fill: 'none' }));

  const api = {
    el: sheet, body: bodyEl, close,
    setTitle: (t) => { sheet.querySelector('.sheet-title').textContent = t; },
  };
  stack.push(api);
  return api;
}

export function closeTopSheet() {
  const top = stack[stack.length - 1];
  if (top) { top.close(); return true; }
  return false;
}

export const sheetOpen = () => stack.length > 0;

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeTopSheet();
});

export function confirmSheet({ title, text, confirm = 'Potvrdi', destructive = false }) {
  return new Promise((resolve) => {
    let answered = false;
    const s = openSheet({
      title,
      body: `<p class="body-text">${text}</p>
        <div class="btn-stack">
          <button class="btn ${destructive ? 'btn-destructive' : 'btn-primary'}" data-yes>${confirm}</button>
          <button class="btn btn-plain" data-close>Odustani</button>
        </div>`,
      onClose: () => { if (!answered) resolve(false); },
    });
    s.body.querySelector('[data-yes]').addEventListener('click', () => { answered = true; resolve(true); s.close(); });
  });
}
