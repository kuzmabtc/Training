// Mrvica predstavlja nove značke (jednu po jednu), uz konfete.

import { Mascot } from '../mascot.js';
import { confetti } from './feedback.js';
import { animate, tick } from '../motion.js';
import { esc } from '../util.js';

let queue = [];
let showing = false;

export function presentBadges(list) {
  if (!list?.length) return;
  queue.push(...list);
  if (!showing) next();
}

function next() {
  const b = queue.shift();
  if (!b) { showing = false; return; }
  showing = true;
  const ov = document.createElement('div');
  ov.className = 'badge-present';
  ov.setAttribute('role', 'alertdialog');
  ov.setAttribute('aria-label', `Nova značka: ${b.name}`);
  ov.innerHTML = `<div class="bp-card glass-card">
      <div class="bp-mascot"></div>
      <div class="bp-badge" aria-hidden="true">${b.icon}</div>
      <p class="eyebrow">Nova značka</p>
      <h2 class="bp-title">${esc(b.name)}</h2>
      <p class="muted">${esc(b.desc)}</p>
      <button class="btn btn-primary" data-ok>Super!</button>
    </div>`;
  document.body.append(ov);
  const m = new Mascot(ov.querySelector('.bp-mascot'), { expr: 'celebrating', pose: 'cheering', size: 104, track: false });
  requestAnimationFrame(() => ov.classList.add('in'));
  animate(ov.querySelector('.bp-card'), [{ opacity: 0, transform: 'translateY(40px) scale(0.9)' }, { opacity: 1, transform: 'none' }], { spring: 'bouncy' });
  animate(ov.querySelector('.bp-badge'), [{ transform: 'scale(0) rotate(-30deg)' }, { transform: 'scale(1) rotate(0)' }], { spring: 'bouncy', delay: 180 });
  setTimeout(() => { m.hop(14); confetti(ov.querySelector('.bp-badge')); tick('success'); }, 250);
  const done = () => {
    ov.classList.remove('in');
    m.destroy();
    setTimeout(() => { ov.remove(); next(); }, 260);
  };
  ov.querySelector('[data-ok]').addEventListener('click', done);
  ov.addEventListener('click', (e) => { if (e.target === ov) done(); });
  ov.querySelector('[data-ok]').focus();
}
