// Ručno crtani SVG grafovi i prsteni.

import { esc } from '../util.js';

export function ring(value, max, { size = 84, stroke = 10, cls = 'rose', label = '' } = {}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = max ? Math.min(1, value / max) : 0;
  return `<svg class="ring ring-${cls}" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" role="img" aria-label="${esc(label || `${value} od ${max}`)}">
    <circle class="ring-track" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}"/>
    <circle class="ring-val" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}"
      stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - pct)}" style="--c:${c};${pct ? '' : 'opacity:0'}" transform="rotate(-90 ${size / 2} ${size / 2})"/>
  </svg>`;
}

// Stupčasti graf: [{ label, value, hi }]
export function bars(data, { max, height = 120, unit = '', label = 'Graf' } = {}) {
  const W = 320, H = height, pad = 18, bw = Math.min(26, (W - 8) / data.length - 8);
  const m = max || Math.max(1, ...data.map((d) => d.value));
  const step = (W - 8) / data.length;
  const items = data.map((d, i) => {
    const h = Math.max(d.value ? 4 : 2, (d.value / m) * (H - pad - 18));
    const x = 4 + i * step + (step - bw) / 2;
    const y = H - pad - h;
    return `<rect class="bar ${d.hi ? 'hi' : ''} ${d.value ? '' : 'zero'}" x="${x}" y="${y}" width="${bw}" height="${h}" rx="${Math.min(7, bw / 2)}"><title>${esc(d.label)}: ${d.value}${unit}</title></rect>
      ${d.value ? `<text class="bar-v" x="${x + bw / 2}" y="${y - 5}" text-anchor="middle">${d.value}</text>` : ''}
      <text class="axis" x="${x + bw / 2}" y="${H - 3}" text-anchor="middle">${esc(d.label)}</text>`;
  }).join('');
  const sr = data.map((d) => `${d.label}: ${d.value}${unit}`).join(', ');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(label)}. ${esc(sr)}">
    <line class="grid" x1="0" x2="${W}" y1="${H - pad}" y2="${H - pad}"/>${items}</svg>`;
}

// Linijski graf: [{ label, value }]
export function lineChart(data, { height = 130, min, max, unit = '', label = 'Graf', decimals = 0 } = {}) {
  const W = 320, H = height, padX = 14, padTop = 20, padBottom = 20;
  if (!data.length) return '';
  const vals = data.map((d) => d.value);
  const lo = min ?? Math.min(...vals);
  const hi = max ?? Math.max(...vals);
  const span = hi - lo || 1;
  const x = (i) => (data.length === 1 ? W / 2 : padX + (i * (W - padX * 2)) / (data.length - 1));
  const y = (v) => padTop + (1 - (v - lo) / span) * (H - padTop - padBottom);
  const pts = data.map((d, i) => [x(i), y(d.value)]);
  const path = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  const area = `${path} L${pts[pts.length - 1][0].toFixed(1)} ${H - padBottom} L${pts[0][0].toFixed(1)} ${H - padBottom} Z`;
  const fmt = (v) => String(Number(v.toFixed(decimals))).replace('.', ',');
  const showEvery = Math.ceil(data.length / 6);
  const dots = pts.map((p, i) => `<circle class="dot" cx="${p[0]}" cy="${p[1]}" r="3.5"><title>${esc(data[i].label)}: ${fmt(data[i].value)}${unit}</title></circle>
    ${i === pts.length - 1 || data.length <= 6 ? `<text class="bar-v" x="${p[0]}" y="${p[1] - 9}" text-anchor="middle">${fmt(data[i].value)}</text>` : ''}
    ${i % showEvery === 0 || i === pts.length - 1 ? `<text class="axis" x="${p[0]}" y="${H - 4}" text-anchor="middle">${esc(data[i].label)}</text>` : ''}`).join('');
  const sr = data.map((d) => `${d.label}: ${fmt(d.value)}${unit}`).join(', ');
  return `<svg class="chart line" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(label)}. ${esc(sr)}">
    <line class="grid" x1="0" x2="${W}" y1="${H - padBottom}" y2="${H - padBottom}"/>
    <path class="area" d="${area}"/><path class="stroke" d="${path}"/>${dots}</svg>`;
}
