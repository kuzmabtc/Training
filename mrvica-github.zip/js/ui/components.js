// Zajedničke komponente: spremanje, kartice, detalji vježbe i sesije, zamjena vježbe, bilješka.

import { icon } from './icons.js';
import { openSheet } from './sheet.js';
import { toast } from './feedback.js';
import { Mascot } from '../mascot.js';
import { EX, WARMUP, COOLDOWN, SAFETY, SWAPS } from '../data.js';
import { mountExercise, exerciseFrames } from '../illustrations.js';
import { isSaved, store, setSwap, addNote } from '../store.js';
import { esc, fmtDate, fmtKg, fmtMin, fmtTime, keyOf, today, DAYS, haptic } from '../util.js';
import { bestLifts, sessionFor } from '../engine.js';

export function saveBtn(key, label) {
  const on = isSaved(key);
  return `<button class="icon-btn save-btn ${on ? 'on' : ''}" data-save="${esc(key)}" aria-pressed="${on}" aria-label="${on ? 'Makni iz spremljenog' : 'Spremi'}: ${esc(label)}">${icon(on ? 'bookmarkFill' : 'bookmark')}</button>`;
}

export function segmented(name, options, value, label) {
  return `<div class="segmented" role="radiogroup" aria-label="${esc(label)}" data-seg="${name}" style="--n:${options.length};--i:${Math.max(0, options.findIndex((o) => o.id === value))}">
    <span class="seg-thumb" aria-hidden="true"></span>
    ${options.map((o) => `<button role="radio" aria-checked="${o.id === value}" class="${o.id === value ? 'on' : ''}" data-val="${o.id}">${esc(o.name)}</button>`).join('')}
  </div>`;
}

export function chips(name, options, value, label) {
  return `<div class="chips" role="radiogroup" aria-label="${esc(label)}" data-seg="${name}">
    ${options.map((o) => `<button role="radio" aria-checked="${o.id === value}" class="chip ${o.id === value ? 'on' : ''}" data-val="${o.id}">${esc(o.name)}</button>`).join('')}
  </div>`;
}

// AI dodirna točka: mali chip koji otvara Buddyja s već napisanim pitanjem
export const askChip = (text, label = text) => `<button class="chip ask-chip" data-ask="${esc(text)}">${icon('spark')}<span>${esc(label)}</span></button>`;

export function foodCard(f) {
  return `<article class="glass-card food-card">
    <div class="card-row">
      <h3 class="card-title">${esc(f.name)}</h3>
      ${saveBtn(`food:${f.id}`, f.name)}
    </div>
    <p class="muted">${esc(f.items)}</p>
    ${f.note ? `<p class="note">${esc(f.note)}</p>` : ''}
    <div class="macro"><span class="pill pill-butter">≈ ${f.kcal} kcal</span><span class="pill pill-sage">≈ ${f.protein} g proteina</span></div>
  </article>`;
}

export function tipCard(t) {
  return `<article class="glass-card tip-card">
    <div class="card-row">
      <h3 class="card-title">${esc(t.title)}</h3>
      ${saveBtn(`tip:${t.id}`, t.title)}
    </div>
    <p class="muted">${esc(t.text)}</p>
  </article>`;
}

export function exerciseSheet(id) {
  const ex = EX[id];
  if (!ex) return;
  const lift = bestLifts().find((b) => b.id === id);
  const logs = store.get().logs[id] || [];
  const last = logs[logs.length - 1];
  const swapTo = SWAPS[id];
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="ill-wrap" data-ill></div>
    <div class="card-row ex-meta">
      <div><p class="eyebrow">${esc(ex.muscles)}</p><p class="muted small">${esc(ex.equip)}</p></div>
      ${saveBtn(`ex:${id}`, ex.name)}
    </div>
    <div class="chip-row">
      ${askChip(`Objasni mi kako se radi ${ex.name.toLowerCase()} i na što da pazim.`, 'Objasni mi')}
      ${swapTo ? `<button class="chip" data-swap-ex="${id}">${icon('undo')}<span>Zamijeni vježbu</span></button>` : ''}
    </div>
    <section class="tip-box tip-do" aria-labelledby="tb-do-${id}">
      <h3 class="tip-head" id="tb-do-${id}"><span class="tip-badge" aria-hidden="true">${icon('check')}</span>Na što paziti</h3>
      <ul class="cues">${ex.cues.map((c) => `<li>${icon('check')}<span>${esc(c)}</span></li>`).join('')}</ul>
    </section>
    <section class="tip-box tip-dont" aria-labelledby="tb-dont-${id}">
      <h3 class="tip-head" id="tb-dont-${id}"><span class="tip-badge" aria-hidden="true">${icon('close')}</span>Česte greške</h3>
      <ul class="cues mistakes">${ex.mistakes.map((c) => `<li>${icon('close')}<span>${esc(c)}</span></li>`).join('')}</ul>
    </section>
    <section class="list-group">
      <div class="list-row"><span class="lr-label">Lakše</span><span class="lr-value">${esc(ex.easier)}</span></div>
      <div class="list-row"><span class="lr-label">Teže</span><span class="lr-value">${esc(ex.harder)}</span></div>
    </section>
    ${lift ? `<section class="glass-card soft-rose">
      <p class="eyebrow">Tvoja snaga</p>
      <p class="big-stat">${fmtKg(lift.best)}</p>
      <p class="muted small">${lift.gain > 0 ? `+${fmtKg(lift.gain)} od prvog treninga` : 'Najveća kilaža do sad'}</p>
      ${last?.note ? `<p class="note">Zadnja bilješka: ${esc(last.note)}</p>` : ''}
    </section>` : ''}`;
  const sh = openSheet({ title: ex.name, body });
  const anim = mountExercise(body.querySelector('[data-ill]'), id, { labels: exerciseFrames(id), title: ex.name });
  const prevClose = sh.close;
  sh.close = () => { anim.destroy(); prevClose(); };
  return sh;
}

function itemRow(it) {
  return `<button class="list-row tappable" data-ex="${it.ex}">
    <span class="lr-main"><span class="lr-label">${esc(it.name)}</span>
      <span class="lr-sub">${it.sets} × ${esc(it.reps)}${it.tempo ? ` · ${esc(it.tempo)}` : ''} · odmor ${it.rest} s${it.swappedFrom ? ` · umjesto: ${esc(EX[it.swappedFrom].name)}` : ''}</span></span>
    ${icon('chevron', 'chev')}
  </button>`;
}

function segRows(segs) {
  return segs.map((s) => `<div class="list-row"><span class="lr-main"><span class="lr-label">${esc(s.name)}</span>${s.sub ? `<span class="lr-sub">${esc(s.sub)}</span>` : ''}</span><span class="lr-value tabular">${fmtTime(s.secs)}</span></div>`).join('');
}

export function sessionDetails(s) {
  if (s.type === 'strength') {
    return `
      ${s.deload ? `<p class="callout">${icon('leaf')}<span>Lakši tjedan: ista kilaža, serija manje. Tijelo sustiže trud.</span></p>` : ''}
      <h3 class="group-title">Zagrijavanje · ${fmtMin(WARMUP.reduce((a, x) => a + x.secs, 0))}</h3>
      <div class="list-group">${segRows(WARMUP)}</div>
      <h3 class="group-title">Vježbe</h3>
      <div class="list-group">${s.items.map(itemRow).join('')}</div>
      <h3 class="group-title">Istezanje · ${fmtMin(COOLDOWN.reduce((a, x) => a + x.secs, 0))}</h3>
      <div class="list-group">${segRows(COOLDOWN)}</div>`;
  }
  if (s.type === 'walk') {
    return `<p class="body-text muted">Tempo uz koji možeš razgovarati u cijelim rečenicama. Šetnja je za srce i energiju, zato neka ostane ugodna.</p>
      <div class="list-group">${segRows(s.segments)}</div>`;
  }
  return `<p class="body-text muted">Danas odmaraš, i to je dio treninga. Ako ti se da, ovo lagano istezanje traje 10 minuta.</p>
    <div class="list-group">${segRows(s.segments)}</div>`;
}

export function sessionSheet(s, { onStart, onShort, onDone } = {}) {
  const done = store.get().done[s.key];
  const todayKey = keyOf(today());
  const future = s.key > todayKey;
  const body = document.createElement('div');
  const startLabel = s.type === 'rest' ? 'Kreni s istezanjem' : 'Kreni';
  body.innerHTML = `
    <p class="eyebrow">${fmtDate(s.date)} · Tjedan ${Math.max(1, Math.min(12, s.week))}</p>
    <p class="muted">${esc(s.subtitle)} · oko ${s.minutes} min</p>
    ${done ? `<p class="done-badge">${icon('check')} Odrađeno</p>` : ''}
    ${future ? `<p class="callout">${icon('plan')}<span>Na rasporedu je ${DAYS[s.date.getDay()]}. Do tad možeš pogledati vježbe.</span></p>` : ''}
    ${sessionDetails(s)}
    ${!done && !future ? `<div class="btn-stack sticky-actions">
      <button class="btn btn-primary" data-start>${icon('play')} ${startLabel}</button>
      <div class="btn-row">
        ${s.type === 'strength' ? `<button class="btn btn-tinted grow" data-short>${icon('timer')} 15 min</button>` : ''}
        <button class="btn btn-tinted grow" data-mark>${icon('check')} ${s.key < todayKey ? 'Već sam odradila' : 'Označi gotovo'}</button>
      </div>
    </div>` : ''}`;
  const sh = openSheet({ title: s.title, body });
  body.querySelector('[data-start]')?.addEventListener('click', () => { sh.close(); onStart?.(s); });
  body.querySelector('[data-short]')?.addEventListener('click', () => { sh.close(); onShort?.(s); });
  body.querySelector('[data-mark]')?.addEventListener('click', (e) => { onDone?.(s, e.currentTarget); sh.close(); });
  return sh;
}

// Zamjena vježbe: bez AI-ja, uvijek radi. Vrijedi za sve buduće treninge dok je ne vratiš.
export function swapSheet(preferEx) {
  const s = sessionFor(today());
  const todays = s.items?.map((i) => i.swappedFrom || i.ex) || [];
  const list = [...new Set([...(preferEx ? [preferEx] : []), ...todays, ...Object.keys(SWAPS)])];
  const swaps = store.get().swaps;
  const body = document.createElement('div');
  body.innerHTML = `
    <p class="muted">Izaberi vježbu koja ti ne paše. Zamjena vrijedi za sve treninge dok je ne vratiš.</p>
    <div class="list-group">
      ${list.slice(0, 14).map((id) => {
        const on = swaps[id];
        const to = SWAPS[id];
        return `<button class="list-row tappable ${id === preferEx ? 'pref' : ''}" data-pick="${id}">
          <span class="lr-main"><span class="lr-label">${esc(EX[id].name)}${todays.includes(id) ? ' · danas' : ''}</span>
          <span class="lr-sub">${on ? `Zamijenjeno s: ${esc(EX[on].name)}. Tapni za vraćanje.` : `→ ${esc(EX[to.to].name)}, ${esc(to.why)}`}</span></span>
          ${on ? `<span class="pill pill-sage">zamijenjeno</span>` : icon('chevron', 'chev')}
        </button>`;
      }).join('')}
    </div>`;
  const sh = openSheet({ title: 'Zamijeni vježbu', body });
  body.addEventListener('click', (e) => {
    const b = e.target.closest('[data-pick]');
    if (!b) return;
    const id = b.dataset.pick;
    haptic();
    if (store.get().swaps[id]) { setSwap(id, null); toast(`${EX[id].name} je vraćen u plan`, { icon: '↩️' }); }
    else { setSwap(id, SWAPS[id].to); toast(`${EX[id].name} → ${EX[SWAPS[id].to].name}`, { icon: '🔄' }); }
    sh.close();
  });
  return sh;
}

export function noteSheet(prefill = '') {
  const body = document.createElement('div');
  body.innerHTML = `
    <p class="muted">Kako se osjećaš, što je bilo teško, što želiš zapamtiti. Buddy ovo vidi i može ti pomoći.</p>
    <label class="field"><span class="sr-only">Bilješka</span><textarea id="note-text" rows="4" data-text placeholder="Npr. danas su mi noge bile teške">${esc(prefill)}</textarea></label>
    <div class="btn-stack"><button class="btn btn-primary" data-save-note>Spremi bilješku</button></div>`;
  const sh = openSheet({ title: 'Bilješka', body });
  const ta = body.querySelector('[data-text]');
  setTimeout(() => ta.focus(), 350);
  body.querySelector('[data-save-note]').addEventListener('click', () => {
    const v = ta.value.trim();
    if (!v) { ta.focus(); return; }
    addNote(v, keyOf(today()));
    haptic('success');
    toast('Bilješka spremljena', { icon: '📝' });
    sh.close();
  });
  return sh;
}

export function safetyCard() {
  return `<article class="glass-card safety">
    <h3 class="card-title">${icon('heart')} Polako i sigurno</h3>
    <p class="muted">${esc(SAFETY)}</p>
  </article>`;
}

// Prazno stanje s Mrvicom umjesto praznog ekrana
export function emptyState(title, text, expr = 'shy', pose = 'waving') {
  const el = document.createElement('div');
  el.className = 'empty';
  el.innerHTML = `<div class="empty-m"></div><h3>${esc(title)}</h3><p class="muted">${esc(text)}</p>`;
  requestAnimationFrame(() => { const m = el.querySelector('.empty-m'); if (m) new Mascot(m, { expr, pose, size: 110 }); });
  return el;
}
