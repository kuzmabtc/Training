// Logika plana: koji je tjedan, što je danas, serije i ponavljanja, nizovi i značke.

import { EX, SWAPS, PHASES, DAY_TEMPLATES, WEEK_SCHEDULE, DELOAD_WEEKS, WARMUP, COOLDOWN, MOBILITY, WALKS, BADGES } from './data.js';
import { store } from './store.js';
import { keyOf, fromKey, today, addDays, dayIdx, mondayOf, diffDays } from './util.js';

export const TOTAL_WEEKS = 12;

export function startMonday() {
  const s = store.get().startDate;
  return s ? mondayOf(fromKey(s)) : mondayOf(today());
}

export function weekOf(date) {
  return Math.floor(diffDays(startMonday(), date) / 7) + 1;
}

export const phaseOfWeek = (w) => PHASES.find((p) => w >= p.from && w <= p.to) || (w < 1 ? PHASES[0] : PHASES[2]);

export function rx(role, phase, week) {
  const deload = DELOAD_WEEKS.includes(week);
  let r;
  if (role === 'main') {
    if (phase === 1) r = { sets: week <= 2 ? 2 : 3, reps: '10–12', rest: 75 };
    else if (phase === 2) r = { sets: 3, reps: '8–12', rest: 90 };
    else r = { sets: week >= 11 ? 4 : 3, reps: '8–10', rest: 90, tempo: '3 s dolje' };
  } else if (role === 'acc') {
    if (phase === 1) r = { sets: week <= 2 ? 2 : 3, reps: '12–15', rest: 60 };
    else if (phase === 2) r = { sets: 3, reps: '10–15', rest: 60 };
    else r = { sets: 3, reps: '10–12', rest: 60, tempo: '2 s gore, 2 s dolje' };
  } else if (role === 'calf') {
    r = { sets: phase === 1 && week <= 2 ? 2 : 3, reps: '15–20', rest: 45 };
  } else if (role === 'time') {
    const t = { 1: '20–30 s', 2: '30–40 s', 3: '40–45 s' }[phase];
    r = { sets: phase === 1 && week <= 2 ? 2 : 3, reps: t, rest: 45, timed: true };
  } else {
    const t = { 1: '6–8 po strani', 2: '8–10 po strani', 3: '10–12 po strani, sporo' }[phase];
    r = { sets: phase === 1 && week <= 2 ? 2 : 3, reps: t, rest: 45 };
  }
  if (deload) r = { ...r, sets: Math.max(2, r.sets - 1), deload: true };
  return r;
}

export function topReps(reps) {
  const m = String(reps).match(/(\d+)\D+(\d+)/);
  return m ? +m[2] : parseInt(reps, 10) || 10;
}

export function strengthItems(dayKey, week, short = false) {
  const tpl = DAY_TEMPLATES[dayKey];
  const phase = phaseOfWeek(week).n;
  const swaps = store.get().swaps || {};
  let items = tpl.items.map((it0) => {
    const swappedFrom = swaps[it0.ex] ? it0.ex : null;
    const it = swappedFrom ? { ...it0, ex: swaps[it0.ex], p2: null, p3: null } : it0;
    const ex = EX[it.ex];
    const variant = (phase === 3 && it.p3) || (phase >= 2 && it.p2) || null;
    return { ...it, name: variant || ex.name, variant: !!variant, swappedFrom, why: swappedFrom ? SWAPS[swappedFrom]?.why : null, ...rx(it.role, phase, week) };
  });
  if (short) {
    const main = items.filter((i) => i.role === 'main').slice(0, 3);
    const core = items.find((i) => i.role === 'side' || i.role === 'time');
    items = [...main, core].filter(Boolean).map((i) => ({ ...i, sets: 2 }));
  }
  return items;
}

export function walkSegments(kind, phase) {
  if (kind === 'steady') return WALKS.steady.byPhase[phase].map((s) => ({ ...s, sub: `${String(s.speed).replace('.', ',')} km/h` }));
  const p = WALKS.intervals.byPhase[phase];
  const segs = [{ name: 'Zagrijavanje', secs: p.warm, speed: 4.5 }];
  for (let i = 0; i < p.rounds; i++) {
    segs.push({ name: `Brže ${i + 1}/${p.rounds}`, secs: 120, speed: p.fast });
    segs.push({ name: `Lagano ${i + 1}/${p.rounds}`, secs: 120, speed: p.easy });
  }
  segs.push({ name: 'Hlađenje', secs: p.cool, speed: 4.3 });
  return segs.map((s) => ({ ...s, sub: `${String(s.speed).replace('.', ',')} km/h` }));
}

const sum = (segs) => segs.reduce((a, s) => a + s.secs, 0);

export function sessionFor(date) {
  const week = weekOf(date);
  const phaseObj = phaseOfWeek(week);
  const phase = phaseObj.n;
  const slot = WEEK_SCHEDULE[dayIdx(date)];
  const base = { date, key: keyOf(date), week, phase, phaseObj, type: slot.type, before: week < 1, after: week > TOTAL_WEEKS };
  if (slot.type === 'strength') {
    const tpl = DAY_TEMPLATES[slot.day];
    const items = strengthItems(slot.day, week);
    const setsTotal = items.reduce((a, i) => a + i.sets, 0);
    const minutes = Math.round((sum(WARMUP) + sum(COOLDOWN)) / 60 + items.reduce((a, i) => a + i.sets * (0.75 + i.rest / 60), 0));
    return { ...base, day: slot.day, title: tpl.name, subtitle: tpl.focus, items, setsTotal, minutes, deload: DELOAD_WEEKS.includes(week) };
  }
  if (slot.type === 'walk') {
    const segs = walkSegments(slot.walk, phase);
    return { ...base, walk: slot.walk, title: WALKS[slot.walk].name, subtitle: 'Traka ili vani, tempo za razgovor', segments: segs, minutes: Math.round(sum(segs) / 60) };
  }
  return { ...base, title: 'Odmor', subtitle: 'Mišići sada rastu', segments: MOBILITY, minutes: Math.round(sum(MOBILITY) / 60) };
}

export const isPlanned = (s) => s.type === 'strength' || s.type === 'walk';

// ── Statistika ──

export function weekRange(date) {
  const mon = mondayOf(date);
  return Array.from({ length: 7 }, (_, i) => addDays(mon, i));
}

export function weekProgress(date = today()) {
  const done = store.get().done;
  const days = weekRange(date).map((d) => ({ d, s: sessionFor(d), done: !!done[keyOf(d)] }));
  const planned = days.filter((x) => isPlanned(x.s));
  return { days, planned: planned.length, completed: planned.filter((x) => x.done).length };
}

function plannedDaysUntil(end) {
  const out = [];
  const start = startMonday();
  for (let d = new Date(start); d <= end; d = addDays(d, 1)) {
    const s = sessionFor(d);
    if (s.week >= 1 && isPlanned(s)) out.push(d);
  }
  return out;
}

export function streaks() {
  const done = store.get().done;
  const t = today();
  const days = plannedDaysUntil(t);
  let current = 0;
  for (let i = days.length - 1; i >= 0; i--) {
    const k = keyOf(days[i]);
    if (done[k]) current++;
    else if (k === keyOf(t)) continue; // danas još ima vremena
    else break;
  }
  let best = 0, run = 0;
  for (const d of days) {
    if (done[keyOf(d)]) { run++; best = Math.max(best, run); } else if (keyOf(d) !== keyOf(t)) run = 0;
  }
  // i odrađeni treninzi izvan plana (npr. pomaknuti dan) se ne kažnjavaju
  return { current, best: Math.max(best, current) };
}

export function totals() {
  const done = Object.values(store.get().done);
  return {
    all: done.filter((x) => x.kind !== 'mobility').length,
    strength: done.filter((x) => x.kind === 'strength').length,
    walk: done.filter((x) => x.kind === 'walk').length,
    mobility: done.filter((x) => x.kind === 'mobility').length,
  };
}

export function volumeBetween(fromD, toD) {
  const a = keyOf(fromD), b = keyOf(toD);
  let sets = 0, kg = 0;
  for (const list of Object.values(store.get().logs)) {
    for (const l of list) if (l.d >= a && l.d <= b) for (const s of l.sets) { sets++; kg += (s.w || 0) * (s.r || 0); }
  }
  return { sets, kg: Math.round(kg) };
}

export function compareWeeks() {
  const t = today();
  const mon = mondayOf(t);
  const lastMon = addDays(mon, -7);
  const daysIn = dayIdx(t);
  const done = store.get().done;
  const count = (from, n) => {
    let c = 0;
    for (let i = 0; i <= n; i++) { const d = addDays(from, i); if (done[keyOf(d)] && isPlanned(sessionFor(d))) c++; }
    return c;
  };
  return {
    thisWeek: count(mon, daysIn),
    lastWeek: count(lastMon, daysIn),
    lastWeekFull: count(lastMon, 6),
    volThis: volumeBetween(mon, t),
    volLast: volumeBetween(lastMon, addDays(lastMon, daysIn)),
  };
}

export function bestLifts() {
  const out = [];
  for (const [id, list] of Object.entries(store.get().logs)) {
    const weights = list.map((l) => ({ d: l.d, w: Math.max(0, ...l.sets.map((s) => s.w || 0)) })).filter((x) => x.w > 0);
    if (!weights.length) continue;
    const first = weights[0].w;
    const best = Math.max(...weights.map((x) => x.w));
    out.push({ id, name: EX[id]?.name || id, first, best, gain: best - first, history: weights });
  }
  return out.sort((a, b) => b.gain - a.gain);
}

export function evaluateBadges() {
  const st = store.get();
  const earned = { ...st.badges };
  const t = totals();
  const k = keyOf(today());
  const got = [];
  const give = (id) => { if (!earned[id]) { earned[id] = k; got.push(BADGES.find((b) => b.id === id)); } };

  if (t.all >= 1) give('first');
  if (t.all >= 10) give('ten');
  if (t.all >= 25) give('twentyfive');
  if (t.walk >= 10) give('walker');
  if (t.mobility >= 5) give('mobile');
  if (st.checkins.length >= 1) give('checkin');
  if (streaks().current >= 7) give('streak-7');
  if (bestLifts().some((b) => b.gain >= 2.5)) give('plus25');
  const logDays = new Set(Object.values(st.logs).flat().map((l) => l.d));
  if (logDays.size >= 5) give('logbook');

  // tjedni i fazni uspjesi
  const start = startMonday();
  const weeks = {};
  for (const [dk, v] of Object.entries(st.done)) {
    const d = fromKey(dk);
    const w = Math.floor(diffDays(start, d) / 7) + 1;
    if (w < 1) continue;
    const s = sessionFor(d);
    weeks[w] = weeks[w] || { strength: 0, planned: 0 };
    if (v.kind === 'strength') weeks[w].strength++;
    if (isPlanned(s)) weeks[w].planned++;
  }
  if (Object.values(weeks).some((w) => w.strength >= 3)) give('strong-week');
  if (Object.values(weeks).some((w) => w.planned >= 5)) give('full-week');
  for (const p of [1, 2, 3]) {
    let c = 0;
    for (let w = (p - 1) * 4 + 1; w <= p * 4; w++) c += weeks[w]?.planned || 0;
    if (c >= 12) give(`phase${p}`);
  }

  if (got.length) store.set({ badges: earned });
  return got;
}

export const sessionColor = (type) => ({ strength: 'rose', walk: 'lilac', rest: 'sage' }[type]);
export const sessionIcon = (type) => ({ strength: 'dumbbell', walk: 'walk', rest: 'leaf' }[type]);
