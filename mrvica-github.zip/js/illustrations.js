// Ilustracije vježbi: jedan anatomski proporcionalan lik (glava, rep kose, trup, nadlaktice, podlaktice,
// šake, bedra, potkoljenice, stopala) iz kutova zglobova. Kutovi: 0° = dolje, 90° = naprijed, 180° = gore, -90° = natrag.
// Animacija petlja početak → kraj → početak; pod smanjenim pokretom dvije statične sličice.

import { reduced } from './motion.js';

const L = { torso: 27, neck: 4.5, head: 6.6, ua: 14.5, fa: 13, th: 20.5, sh: 19.5, foot: 8 };
const FLOOR = 100;
const W = 120;
// polovične debljine segmenata (početak, kraj)
const TH = { torso: [7.2, 6.4], ua: [3.5, 2.8], fa: [2.7, 2.1], th: [5.4, 3.9], sh: [3.6, 2.5] };

const rad = (d) => (d * Math.PI) / 180;
const step = (p, a, len) => [p[0] + Math.sin(rad(a)) * len, p[1] + Math.cos(rad(a)) * len];
const f = (n) => Math.round(n * 10) / 10;

function solve(pose) {
  const P = {};
  const front = !!pose.front;
  P.hip = [0, 0];
  P.sh = step(P.hip, pose.torso, L.torso);
  P.neck = step(P.sh, pose.torso, L.neck * 0.5);
  P.head = step(P.neck, pose.head ?? pose.torso, L.neck + L.head * 0.9);
  const sw = front ? 9.5 : 0, hw = front ? 5 : 0;
  P.shN = [P.sh[0] + sw, P.sh[1]];
  P.shF = [P.sh[0] - sw, P.sh[1]];
  P.hipN = [P.hip[0] + hw, P.hip[1]];
  P.hipF = [P.hip[0] - hw, P.hip[1]];
  P.elN = step(P.shN, pose.uaN, L.ua);
  P.wrN = step(P.elN, pose.faN ?? pose.uaN, L.fa);
  P.elF = step(P.shF, pose.uaF ?? pose.uaN, L.ua);
  P.wrF = step(P.elF, pose.faF ?? pose.faN ?? pose.uaF ?? pose.uaN, L.fa);
  P.knN = step(P.hipN, pose.thN, L.th);
  P.anN = step(P.knN, pose.shN ?? pose.thN, L.sh);
  P.toN = step(P.anN, pose.ftN ?? 90, L.foot);
  P.knF = step(P.hipF, pose.thF ?? pose.thN, L.th);
  P.anF = step(P.knF, pose.shF ?? pose.shN ?? pose.thF ?? pose.thN, L.sh);
  P.toF = step(P.anF, pose.ftF ?? pose.ftN ?? 90, L.foot);
  return P;
}

// Postavlja početnu pozu na pod i u sredinu; vraća pomak koji se onda drži fiksnim preko sidra.
function placement(P) {
  const pts = Object.values(P);
  const maxY = Math.max(...pts.map((p) => p[1]), P.head[1] + L.head);
  const minX = Math.min(...pts.map((p) => p[0]), P.head[0] - L.head);
  const maxX = Math.max(...pts.map((p) => p[0]), P.head[0] + L.head);
  return [W / 2 - (minX + maxX) / 2, FLOOR - 3.5 - maxY];
}

function shift(P, dx, dy) {
  const o = {};
  for (const [k, p] of Object.entries(P)) o[k] = [p[0] + dx, p[1] + dy];
  return o;
}

// zaobljeni, suženi segment (kapsula)
function limb(a, b, w1, w2, cls) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const len = Math.hypot(dx, dy) || 0.001;
  const nx = -dy / len, ny = dx / len;
  return `<path class="${cls}" d="M${f(a[0] + nx * w1)} ${f(a[1] + ny * w1)} L${f(b[0] + nx * w2)} ${f(b[1] + ny * w2)} A${w2} ${w2} 0 0 0 ${f(b[0] - nx * w2)} ${f(b[1] - ny * w2)} L${f(a[0] - nx * w1)} ${f(a[1] - ny * w1)} A${w1} ${w1} 0 0 0 ${f(a[0] + nx * w1)} ${f(a[1] + ny * w1)} Z"/>`;
}

function foot(an, to, cls) {
  const dx = to[0] - an[0], dy = to[1] - an[1];
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len, ny = dx / len;
  // peta je malo iza gležnja, prsti zaobljeni
  const heel = [an[0] - (dx / len) * 1.6, an[1] - (dy / len) * 1.6];
  return `<path class="${cls}" d="M${f(heel[0] - nx * 2.4)} ${f(heel[1] - ny * 2.4)} Q${f(heel[0] + nx * 3)} ${f(heel[1] + ny * 3)} ${f(an[0] + nx * 2.6)} ${f(an[1] + ny * 2.6)} L${f(to[0] + nx * 1.6)} ${f(to[1] + ny * 1.6)} A1.9 1.9 0 0 0 ${f(to[0] - nx * 2.1)} ${f(to[1] - ny * 2.1)} Z"/>`;
}

function dumbbell(p, vertical = false, angle = 0) {
  const [x, y] = p;
  const rot = vertical ? 90 + angle : angle;
  return `<g class="gear" transform="translate(${f(x)} ${f(y)}) rotate(${f(rot)})"><rect x="-6.5" y="-1.4" width="13" height="2.8" rx="1.2"/><rect x="-9.5" y="-4.2" width="4.6" height="8.4" rx="1.8"/><rect x="4.9" y="-4.2" width="4.6" height="8.4" rx="1.8"/></g>`;
}

function chair(x, topY) {
  return `<g class="prop"><rect x="${f(x - 10)}" y="${f(topY)}" width="20" height="3.6" rx="1.6"/><rect x="${f(x + 7)}" y="${f(topY - 22)}" width="3" height="24" rx="1.4"/><line x1="${f(x - 8)}" y1="${f(topY + 3)}" x2="${f(x - 8)}" y2="${FLOOR}"/><line x1="${f(x + 8)}" y1="${f(topY + 3)}" x2="${f(x + 8)}" y2="${FLOOR}"/></g>`;
}

function arrow(from, to, bend = 0) {
  const mx = (from[0] + to[0]) / 2, my = (from[1] + to[1]) / 2;
  const nx = -(to[1] - from[1]), ny = to[0] - from[0];
  const len = Math.hypot(nx, ny) || 1;
  const c = [mx + (nx / len) * bend, my + (ny / len) * bend];
  const ang = Math.atan2(to[1] - c[1], to[0] - c[0]);
  const h = 4;
  const a1 = [to[0] - h * Math.cos(ang - 0.5), to[1] - h * Math.sin(ang - 0.5)];
  const a2 = [to[0] - h * Math.cos(ang + 0.5), to[1] - h * Math.sin(ang + 0.5)];
  return `<g class="arrow"><path d="M${f(from[0])} ${f(from[1])} Q${f(c[0])} ${f(c[1])} ${f(to[0])} ${f(to[1])}"/><path d="M${f(a1[0])} ${f(a1[1])} L${f(to[0])} ${f(to[1])} L${f(a2[0])} ${f(a2[1])}"/></g>`;
}

const SEG = {
  torso: (P) => [P.hip, P.sh, ...TH.torso],
  uaN: (P) => [P.shN, P.elN, ...TH.ua], faN: (P) => [P.elN, P.wrN, ...TH.fa],
  uaF: (P) => [P.shF, P.elF, ...TH.ua], faF: (P) => [P.elF, P.wrF, ...TH.fa],
  thN: (P) => [P.hipN, P.knN, ...TH.th], shN: (P) => [P.knN, P.anN, ...TH.sh],
  thF: (P) => [P.hipF, P.knF, ...TH.th], shF: (P) => [P.knF, P.anF, ...TH.sh],
};

function drawFigure(P, pose, glow = [], glowAmt = 0.6, uid = 0) {
  let s = '';
  // sjaj na mišićima koji rade
  if (glow.length) {
    s += `<g class="glow" filter="url(#ig${uid})" style="opacity:${f(glowAmt)}">`;
    for (const g of glow) { const [a, b, w1, w2] = SEG[g](P); s += limb(a, b, w1 + 1.6, w2 + 1.6, 'gl'); }
    s += '</g>';
  }
  // daleki udovi
  const legF = pose.front ? 'body' : 'far';
  s += limb(...SEG.thF(P), legF) + limb(...SEG.shF(P), legF) + foot(P.anF, P.toF, legF);
  if (!pose.front) s += limb(...SEG.uaF(P), 'far') + limb(...SEG.faF(P), 'far') + `<circle class="far" cx="${f(P.wrF[0])}" cy="${f(P.wrF[1])}" r="2.5"/>`;
  if (pose.db?.includes('F')) s += dumbbell(P.wrF, pose.dbVertical);
  // trup
  if (pose.front) {
    const n = P.sh, h = P.hip;
    s += `<path class="body" d="M${f(n[0] - 10)} ${f(n[1] + 1)} Q${f(n[0])} ${f(n[1] - 3)} ${f(n[0] + 10)} ${f(n[1] + 1)} L${f(h[0] + 7.5)} ${f(h[1] - 6)} Q${f(h[0] + 8.5)} ${f(h[1] + 2)} ${f(h[0] + 5)} ${f(h[1] + 3)} L${f(h[0] - 5)} ${f(h[1] + 3)} Q${f(h[0] - 8.5)} ${f(h[1] + 2)} ${f(h[0] - 7.5)} ${f(h[1] - 6)} Z"/>`;
    s += limb(...SEG.uaF(P), 'body') + limb(...SEG.faF(P), 'body') + `<circle class="body" cx="${f(P.wrF[0])}" cy="${f(P.wrF[1])}" r="2.5"/>`;
  } else {
    s += limb(...SEG.torso(P), 'body');
  }
  // vrat, glava, kosa
  s += limb(P.sh, P.head, 2.6, 2.6, 'body');
  const d = [P.head[0] - P.neck[0], P.head[1] - P.neck[1]];
  const dl = Math.hypot(...d) || 1;
  const dir = [d[0] / dl, d[1] / dl];
  if (!pose.front) {
    const back = [dir[1], -dir[0]];
    const tail = [P.head[0] + back[0] * 6.5 - dir[0] * 0.5, P.head[1] + back[1] * 6.5 - dir[1] * 0.5];
    const tail2 = [tail[0] + back[0] * 3.5 - dir[0] * 4.5, tail[1] + back[1] * 3.5 - dir[1] * 4.5];
    s += limb(tail, tail2, 2.6, 1.6, 'hair');
  } else {
    s += `<circle class="hair" cx="${f(P.head[0])}" cy="${f(P.head[1] - 6.4)}" r="3.4"/>`;
  }
  s += `<circle class="head" cx="${f(P.head[0])}" cy="${f(P.head[1])}" r="${L.head}"/>`;
  if (!pose.front) {
    // kosa preko tjemena (pokazuje smjer gledanja)
    const back = [dir[1], -dir[0]];
    const a = [P.head[0] + back[0] * 6.4 + dir[0] * 1, P.head[1] + back[1] * 6.4 + dir[1] * 1];
    const b = [P.head[0] + dir[0] * 6.6 - back[0] * 1.5, P.head[1] + dir[1] * 6.6 - back[1] * 1.5];
    s += `<path class="hair" d="M${f(a[0])} ${f(a[1])} A${L.head} ${L.head} 0 0 1 ${f(b[0])} ${f(b[1])} Q${f(P.head[0] + back[0] * 1.5)} ${f(P.head[1] + back[1] * 1.5)} ${f(a[0])} ${f(a[1])} Z"/>`;
  }
  // bliži udovi
  s += limb(...SEG.thN(P), 'body') + limb(...SEG.shN(P), 'body') + foot(P.anN, P.toN, 'body');
  s += limb(...SEG.uaN(P), 'body') + limb(...SEG.faN(P), 'body') + `<circle class="body" cx="${f(P.wrN[0])}" cy="${f(P.wrN[1])}" r="2.5"/>`;
  if (pose.db?.includes('N')) s += dumbbell(P.wrN, pose.dbVertical);
  if (pose.dbChest) s += dumbbell([(P.wrN[0] + P.wrF[0]) / 2 + 1.5, (P.wrN[1] + P.wrF[1]) / 2 - 3], true);
  if (pose.dbOver) {
    const ang = (Math.atan2(P.wrN[1] - P.elN[1], P.wrN[0] - P.elN[0]) * 180) / Math.PI;
    s += dumbbell([(P.wrN[0] + P.wrF[0]) / 2, (P.wrN[1] + P.wrF[1]) / 2], false, ang + 90);
  }
  return s;
}

// ── Poze (početak, kraj), sidro koje ostaje na mjestu, mišići koji rade ──

const stand = { torso: 180, thN: 1, shN: 0, thF: -1, shF: 0 };

const EXS = {
  'goblet-squat': {
    anchor: 'anN', glow: ['thN', 'thF'],
    poses: [
      { ...stand, uaN: 10, faN: 162, uaF: 6, faF: 158, dbChest: true },
      { torso: 156, thN: 82, shN: -24, thF: 79, shF: -22, uaN: 28, faN: 178, uaF: 24, faF: 174, dbChest: true },
    ],
    arrows: [{ at: 'hip', off: [-13, -16], d: [0, 15] }],
  },
  rdl: {
    anchor: 'anN', glow: ['thN', 'thF'],
    poses: [
      { ...stand, uaN: 4, faN: 2, uaF: 0, faF: -2, db: 'NF' },
      { torso: 108, thN: 16, shN: -4, thF: 13, shF: -5, uaN: 2, faN: 0, uaF: -2, faF: -2, db: 'NF' },
    ],
    arrows: [{ at: 'hip', off: [-8, -6], d: [-13, 0] }],
  },
  'floor-press': {
    anchor: 'hip', glow: ['uaN', 'uaF', 'torso'], mat: true,
    poses: [
      { torso: -90, head: -88, thN: 132, shN: 28, thF: 128, shF: 26, uaN: 94, faN: 180, uaF: 90, faF: 178, db: 'NF' },
      { torso: -90, head: -88, thN: 132, shN: 28, thF: 128, shF: 26, uaN: 178, faN: 180, uaF: 175, faF: 176, db: 'NF' },
    ],
    arrows: [{ at: 'wrN', off: [9, 4], d: [0, -16] }],
  },
  'one-arm-row': {
    anchor: 'anF', glow: ['uaN', 'torso'], chair: 'wrF',
    poses: [
      { torso: 100, head: 108, thN: -16, shN: -18, thF: 36, shF: -4, ftN: 90, uaN: 0, faN: 0, uaF: 46, faF: 26, db: 'N' },
      { torso: 100, head: 108, thN: -16, shN: -18, thF: 36, shF: -4, ftN: 90, uaN: -128, faN: -4, uaF: 46, faF: 26, db: 'N' },
    ],
    arrows: [{ at: 'wrN', off: [7, 2], d: [0, -14] }],
  },
  ohp: {
    anchor: 'anN', glow: ['uaN', 'uaF'],
    poses: [
      { ...stand, uaN: 34, faN: 174, uaF: 30, faF: 170, db: 'NF' },
      { ...stand, uaN: 174, faN: 178, uaF: 170, faF: 176, db: 'NF' },
    ],
    arrows: [{ at: 'wrN', off: [10, 0], d: [0, -16] }],
  },
  'glute-bridge': {
    anchor: 'anN', glow: ['thN', 'thF', 'torso'], mat: true,
    poses: [
      { torso: -90, head: -88, thN: 128, shN: 32, thF: 124, shF: 30, uaN: 92, faN: 92, uaF: 92, faF: 92 },
      { torso: -62, head: -86, thN: 102, shN: 10, thF: 98, shF: 8, uaN: 104, faN: 94, uaF: 104, faF: 94 },
    ],
    arrows: [{ at: 'hip', off: [0, 11], d: [0, -13] }],
  },
  'reverse-lunge': {
    anchor: 'anN', glow: ['thN', 'thF'],
    poses: [
      { ...stand, uaN: 3, faN: 1, uaF: -1, faF: -3, db: 'NF' },
      { torso: 178, thN: 82, shN: 2, thF: -26, shF: -78, ftF: 18, uaN: 2, faN: 0, uaF: -2, faF: -2, db: 'NF' },
    ],
    arrows: [{ at: 'anF', off: [-12, -4], d: [-14, 0], bend: -3 }],
  },
  'lateral-raise': {
    anchor: 'anN', glow: ['uaN', 'uaF'], front: true,
    poses: [
      { ...stand, front: true, thN: 5, shN: 1, thF: -5, shF: -1, ftN: 70, ftF: -70, uaN: 10, faN: 8, uaF: -10, faF: -8, db: 'NF', dbVertical: true },
      { ...stand, front: true, thN: 5, shN: 1, thF: -5, shF: -1, ftN: 70, ftF: -70, uaN: 84, faN: 90, uaF: -84, faF: -90, db: 'NF', dbVertical: true },
    ],
    arrows: [{ at: 'elN', off: [6, 10], d: [6, -12], bend: 3 }, { at: 'elF', off: [-6, 10], d: [-6, -12], bend: -3 }],
  },
  'biceps-curl': {
    anchor: 'anN', glow: ['uaN', 'uaF'],
    poses: [
      { ...stand, uaN: 3, faN: 4, uaF: -1, faF: 0, db: 'NF' },
      { ...stand, uaN: 6, faN: 148, uaF: 2, faF: 144, db: 'NF' },
    ],
    arrows: [{ at: 'elN', off: [15, 6], d: [-2, -15], bend: -5 }],
  },
  'triceps-ext': {
    anchor: 'anN', glow: ['uaN', 'uaF'],
    poses: [
      { ...stand, uaN: 166, faN: -14, uaF: 162, faF: -18, dbOver: true },
      { ...stand, uaN: 168, faN: 176, uaF: 164, faF: 172, dbOver: true },
    ],
    arrows: [{ at: 'elN', off: [16, 2], d: [0, -14] }],
  },
  plank: {
    anchor: 'elN', glow: ['torso'], mat: true, frames: ['Na koljenima', 'Puna daska'],
    poses: [
      { torso: 98, head: 100, thN: -44, shN: -90, thF: -44, shF: -90, ftN: -170, uaN: 0, faN: 90, uaF: 0, faF: 90 },
      { torso: 94, head: 96, thN: -86, shN: -86, thF: -86, shF: -86, ftN: 6, uaN: 0, faN: 90, uaF: 0, faF: 90 },
    ],
    arrows: [{ at: 'knN', off: [0, 9], d: [0, -10] }],
  },
  'dead-bug': {
    anchor: 'hip', glow: ['torso'], mat: true,
    poses: [
      { torso: -90, head: -88, thN: 180, shN: 90, thF: 178, shF: 88, ftN: 180, uaN: 180, faN: 180, uaF: 176, faF: 176 },
      { torso: -90, head: -88, thN: 180, shN: 90, thF: 98, shF: 96, ftN: 180, ftF: 172, uaN: -100, faN: -100, uaF: 176, faF: 176 },
    ],
    arrows: [{ at: 'wrN', off: [-2, -4], d: [-14, 8], bend: 5 }, { at: 'anF', off: [-4, -6], d: [14, 6], bend: -5 }],
  },
  'bird-dog': {
    anchor: 'knN', glow: ['torso', 'thF'], mat: true,
    poses: [
      { torso: 102, head: 106, thN: 0, shN: -90, thF: 2, shF: -90, ftN: -178, ftF: -178, uaN: 0, faN: 0, uaF: 2, faF: 2 },
      { torso: 102, head: 106, thN: 0, shN: -90, thF: -96, shF: -96, ftN: -178, ftF: -172, uaN: 96, faN: 96, uaF: 2, faF: 2 },
    ],
    arrows: [{ at: 'shN', off: [12, -8], d: [12, 0] }, { at: 'hip', off: [-14, -8], d: [-12, 0] }],
  },
  'calf-raise': {
    anchor: 'toN', glow: ['shN', 'shF'],
    poses: [
      { ...stand, uaN: 3, faN: 1, uaF: -1, faF: -3, db: 'NF' },
      { ...stand, ftN: 36, ftF: 36, uaN: 3, faN: 1, uaF: -1, faF: -3, db: 'NF' },
    ],
    arrows: [{ at: 'anN', off: [-10, -4], d: [0, -13] }],
  },
};

const NUMERIC = ['torso', 'head', 'thN', 'shN', 'thF', 'shF', 'ftN', 'ftF', 'uaN', 'faN', 'uaF', 'faF'];
function lerpPose(a, b, t) {
  const o = { ...a };
  for (const k of NUMERIC) {
    const va = a[k] ?? (k === 'head' ? a.torso : k.startsWith('ft') ? 90 : undefined);
    const vb = b[k] ?? (k === 'head' ? b.torso : k.startsWith('ft') ? 90 : undefined);
    if (va != null && vb != null) o[k] = va + (vb - va) * t;
  }
  return o;
}

let uidN = 0;

function scene(id, t, uid, origin) {
  const ex = EXS[id];
  const pose = lerpPose(ex.poses[0], ex.poses[1], t);
  const raw = solve(pose);
  // sidro ostaje gdje je bilo u početnoj pozi (stopala ne klize)
  const base = solve(ex.poses[0]);
  const [dx0, dy0] = origin || placement(base);
  const A0 = [base[ex.anchor][0] + dx0, base[ex.anchor][1] + dy0];
  const P = shift(raw, A0[0] - raw[ex.anchor][0], A0[1] - raw[ex.anchor][1]);
  let s = '';
  if (ex.mat) s += `<rect class="mat" x="6" y="${FLOOR - 3}" width="${W - 12}" height="3" rx="1.5"/>`;
  if (ex.chair) { const c = shift(base, dx0, dy0)[ex.chair]; s += chair(c[0] + 2, c[1] + 2.4); }
  s += drawFigure(P, pose, ex.glow, 0.25 + t * 0.6, uid);
  return { svg: s, P0: shift(base, dx0, dy0) };
}

function arrowsFor(id, P0) {
  return (EXS[id].arrows || []).map((a) => {
    const b = P0[a.at];
    const from = [b[0] + (a.off?.[0] || 0), b[1] + (a.off?.[1] || 0)];
    return arrow(from, [from[0] + a.d[0], from[1] + a.d[1]], a.bend || 0);
  }).join('');
}

const defs = (uid) => `<defs><filter id="ig${uid}" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2.4"/></filter></defs>`;

// Statična verzija: dvije sličice (smanjeni pokret, popisi)
export function exerciseSVG(id, opts = {}) {
  const ex = EXS[id];
  if (!ex) return '';
  const uid = ++uidN;
  const labels = opts.labels || ex.frames || ['Početak', 'Kraj'];
  const a = scene(id, 0, uid);
  const b = scene(id, 1, uid);
  return `<svg class="ill" viewBox="0 -14 260 136" role="img" aria-label="${opts.title ? opts.title + ': ' : ''}${labels[0]}, pa ${labels[1].toLowerCase()}" xmlns="http://www.w3.org/2000/svg">${defs(uid)}
  <line class="floor" x1="4" y1="${FLOOR}" x2="124" y2="${FLOOR}"/><line class="floor" x1="136" y1="${FLOOR}" x2="256" y2="${FLOOR}"/>
  <g>${a.svg}</g><path class="next" d="M126 54 l4 4 -4 4"/>
  <g transform="translate(136 0)">${b.svg}${arrowsFor(id, a.P0)}</g>
  <text class="lbl" x="64" y="116" text-anchor="middle">${labels[0]}</text><text class="lbl" x="196" y="116" text-anchor="middle">${labels[1]}</text></svg>`;
}

export function exerciseThumb(id) {
  if (!EXS[id]) return '';
  const uid = ++uidN;
  return `<svg class="ill thumb" viewBox="4 4 112 100" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">${defs(uid)}<line class="floor" x1="4" y1="${FLOOR}" x2="116" y2="${FLOOR}"/>${scene(id, 1, uid).svg}</svg>`;
}

// Animirana verzija: jedan lik koji glatko prelazi iz početka u kraj i natrag.
const CYCLE = 3600; // ms: zadrži 0.5 s, 1.3 s gore, 0.5 s, 1.3 s dolje
function phase(ms) {
  const t = (ms % CYCLE) / CYCLE;
  const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
  if (t < 0.14) return 0;
  if (t < 0.5) return ease((t - 0.14) / 0.36);
  if (t < 0.64) return 1;
  return 1 - ease((t - 0.64) / 0.36);
}

export function mountExercise(el, id, opts = {}) {
  const ex = EXS[id];
  if (!ex) return { destroy() {} };
  if (reduced()) { el.innerHTML = exerciseSVG(id, opts); return { destroy() {} }; }
  const uid = ++uidN;
  const labels = opts.labels || ex.frames || ['Početak', 'Kraj'];
  const origin = placement(solve(ex.poses[0]));
  const first = scene(id, 0, uid, origin);
  el.innerHTML = `<svg class="ill anim" viewBox="0 -14 120 128" role="img" aria-label="${opts.title ? opts.title + ': ' : ''}animacija, ${labels[0].toLowerCase()} pa ${labels[1].toLowerCase()}" xmlns="http://www.w3.org/2000/svg">${defs(uid)}
    <line class="floor" x1="4" y1="${FLOOR}" x2="116" y2="${FLOOR}"/><g class="fig">${first.svg}</g><g class="arrows">${arrowsFor(id, first.P0)}</g>
    <text class="lbl" x="60" y="111" text-anchor="middle"></text></svg>`;
  const fig = el.querySelector('.fig');
  const lbl = el.querySelector('.lbl');
  const arrows = el.querySelector('.arrows');
  let raf, visible = true, t0 = performance.now(), lastLbl = '';
  const io = 'IntersectionObserver' in window ? new IntersectionObserver((es) => { visible = es[0].isIntersecting; if (visible) loop(); }) : null;
  io?.observe(el);
  let lastDraw = 0;
  function loop() {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(function frame(now) {
      if (!el.isConnected) { io?.disconnect(); return; }
      if (!visible || document.hidden) return;
      if (now - lastDraw > 30) {
        lastDraw = now;
        const p = phase(now - t0);
        fig.innerHTML = scene(id, p, uid, origin).svg;
        arrows.style.opacity = String(Math.max(0, 1 - p * 2.2));
        const l = p < 0.5 ? labels[0] : labels[1];
        if (l !== lastLbl) { lbl.textContent = l; lastLbl = l; }
      }
      raf = requestAnimationFrame(frame);
    });
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) loop(); });
  loop();
  return { destroy() { cancelAnimationFrame(raf); io?.disconnect(); } };
}

export const ILLUSTRATED = Object.keys(EXS);
export const exerciseFrames = (id) => EXS[id]?.frames;
