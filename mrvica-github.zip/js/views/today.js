// Danas: Mrvica s porukom, jedna velika kartica "Današnji trening" s jednim gumbom, mali sažetak napretka.

import { MESSAGES, MASCOT_LINES } from '../data.js';
import { store } from '../store.js';
import { sessionFor, weekProgress, streaks, bestLifts, TOTAL_WEEKS, startMonday, sessionColor, sessionIcon, totals } from '../engine.js';
import { Mascot } from '../mascot.js';
import { icon } from '../ui/icons.js';
import { ring } from '../ui/charts.js';
import { askChip } from '../ui/components.js';
import { checkinDue } from './progress.js';
import { countUp } from '../motion.js';
import { today, addDays, fromKey, fmtDate, diffDays, esc, pick, DAYS_SHORT, keyOf, plural, fmtKg } from '../util.js';

export const title = 'Danas';

function mascotState(s, done) {
  const t = today();
  const st = store.get();
  const n = diffDays(new Date(2026, 0, 1), t);
  const sk = streaks();
  const keys = Object.keys(st.done).sort();
  const last = keys[keys.length - 1];
  const since = last ? diffDays(fromKey(last), t) : null;
  const pr = bestLifts().find((l) => l.gain > 0 && diffDays(fromKey(l.history[l.history.length - 1].d), t) <= 1 && l.history[l.history.length - 1].w === l.best);
  const fill = (str, o) => str.replace(/\{(\w+)\}/g, (_, k) => o[k]);
  if (done) return { expr: 'proud', pose: 'flexing', text: pick(MASCOT_LINES.done, n) };
  if (pr) return { expr: 'proud', pose: 'flexing', text: fill(MASCOT_LINES.pr[0], { ex: pr.name, kg: fmtKg(pr.best) }) };
  if (!totals().all) return { expr: 'happy', pose: 'waving', text: pick(MASCOT_LINES.first, n) };
  if (since != null && since >= 4) return { expr: 'shy', pose: 'waving', text: pick(MASCOT_LINES.missed, n) };
  if (s.type === 'rest') return { expr: 'sleepy', pose: 'resting', text: pick(MASCOT_LINES.rest, n) };
  if (sk.current >= 3) return { expr: 'excited', pose: 'cheering', text: fill(pick(MASCOT_LINES.streak, n), { n: sk.current }) };
  if (s.type === 'walk') return { expr: 'happy', pose: 'idle', text: MASCOT_LINES.walk[0] };
  return { expr: 'encouraging', pose: 'dumbbell', text: pick(MESSAGES, n * 7 + 3) };
}

export function render(el) {
  const t = today();
  const s = sessionFor(t);
  const done = store.get().done[s.key];
  const wp = weekProgress(t);
  const st = streaks();
  const color = sessionColor(s.type);
  const week = Math.max(1, Math.min(TOTAL_WEEKS, s.week));
  const m = mascotState(s, done);

  let notice = '';
  if (s.before) notice = `<p class="callout">${icon('spark')}<span>Plan počinje ${fmtDate(startMonday(), false)}. Do tad se možeš upoznati s vježbama.</span></p>`;
  if (s.after) notice = `<p class="callout">${icon('spark')}<span>Odradila si svih 12 tjedana! Ponovi fazu Kontrola s malo težim bučicama ili promijeni početak u postavkama.</span></p>`;

  const metaLine = s.type === 'strength' ? `${s.items.length} vježbi · oko ${s.minutes} min` : `oko ${s.minutes} min${s.type === 'rest' ? ' · neobavezno' : ''}`;
  const dots = wp.days.map((d, i) => `<span class="wd ${d.done ? 'done' : ''} ${d.s.type === 'rest' ? 'rest' : ''} wd-${sessionColor(d.s.type)} ${keyOf(d.d) === keyOf(t) ? 'today' : ''}"><b>${DAYS_SHORT[i]}</b></span>`).join('');

  el.innerHTML = `
    <header class="large-head">
      <p class="eyebrow">${fmtDate(t)}</p>
      <h1 class="large-title">Bok, Dora</h1>
    </header>
    ${notice}
    <section class="mascot-say" aria-label="Mrvica kaže">
      <div class="ms-m"></div>
      <p class="say glass-card">${esc(m.text)}</p>
    </section>

    <article class="glass-card hero hero-${color} ${done ? 'is-done' : ''} tappable" data-act="details" aria-labelledby="today-title">
      <p class="eyebrow">Današnji trening · tjedan ${week}${s.deload ? ' · lakši' : ''}</p>
      <div class="hero-top">
        <span class="hero-ic" aria-hidden="true">${icon(sessionIcon(s.type))}</span>
        <div class="hero-meta">
          <h2 class="hero-title" id="today-title">${esc(s.title)}</h2>
          <p class="muted">${metaLine}</p>
        </div>
        ${icon('chevron', 'chev')}
      </div>
      ${done
        ? `<div class="done-state"><span class="done-badge">${icon('check')} Odrađeno</span><button class="btn-text small" data-act="undo">${icon('undo')} Poništi</button></div>`
        : `<button class="btn btn-primary big go" data-act="start">${icon('play')} ${s.type === 'rest' ? 'Kreni s istezanjem' : 'Kreni'}</button>`}
    </article>

    <button class="glass-card progress-strip tappable" data-act="progress" aria-label="Napredak: ovaj tjedan ${wp.completed} od ${wp.planned}, niz ${st.current}">
      <span class="ring-box sm">${ring(wp.completed, wp.planned, { size: 52, stroke: 7, label: '' })}<span class="ring-num tabular" aria-hidden="true">${wp.completed}/${wp.planned}</span></span>
      <span class="ps-dots" aria-hidden="true">${dots}</span>
      <span class="ps-streak" aria-hidden="true">${icon('flame')}<b class="tabular" data-count="${st.current}">${st.current}</b></span>
      ${icon('chevron', 'chev')}
    </button>

    <div class="chip-row center-row">
      ${done ? askChip('Upravo sam odradila trening. Što da jedem sad?', 'Što da jedem sad?') : askChip('Ne ide mi danas.', 'Ne ide mi danas')}
      ${checkinDue() && totals().all ? `<button class="chip" data-act="checkin">${icon('heart')}<span>Tjedni check-in</span></button>` : ''}
    </div>`;

  const mm = new Mascot(el.querySelector('.ms-m'), { expr: m.expr, pose: m.pose, size: 78 });
  el._mascot = mm;
  el.querySelectorAll('[data-count]').forEach((n) => countUp(n, +n.dataset.count));
}

export const dayLabel = (d) => DAYS_SHORT[(d.getDay() + 6) % 7];
export { addDays };
