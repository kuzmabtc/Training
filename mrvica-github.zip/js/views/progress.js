// Napredak (sheet s Danas): check-in, grafovi, snaga po vježbama, značke.

import { BADGES, ENERGY, MOODS } from '../data.js';
import { store, addCheckin } from '../store.js';
import { totals, streaks, bestLifts, startMonday, weekOf, sessionFor, isPlanned, evaluateBadges, TOTAL_WEEKS } from '../engine.js';
import { icon } from '../ui/icons.js';
import { bars, lineChart } from '../ui/charts.js';
import { openSheet } from '../ui/sheet.js';
import { toast, confetti } from '../ui/feedback.js';
import { presentBadges } from '../ui/celebrate.js';
import { countUp, stagger } from '../motion.js';
import { addDays, today, keyOf, fromKey, esc, fmtShort, fmtKg, fmtDate, haptic, plural } from '../util.js';

let liftSel = null;

function weeklyCounts() {
  const done = store.get().done;
  const mon = startMonday();
  const cur = Math.max(1, Math.min(TOTAL_WEEKS, weekOf(today())));
  const from = Math.max(1, cur - 7);
  const to = Math.min(TOTAL_WEEKS, Math.max(cur, from + 3));
  const out = [];
  for (let w = from; w <= to; w++) {
    let c = 0;
    for (let i = 0; i < 7; i++) {
      const d = addDays(mon, (w - 1) * 7 + i);
      if (done[keyOf(d)] && isPlanned(sessionFor(d))) c++;
    }
    out.push({ label: `T${w}`, value: c, hi: w === cur });
  }
  return out;
}

export function checkinDue() {
  const last = store.get().checkins.slice(-1)[0];
  return !last || Math.round((today() - fromKey(last.d)) / 86400000) >= 7;
}

function body() {
  const st = store.get();
  const t = totals();
  const s = streaks();
  const lifts = bestLifts();
  if (!liftSel || !lifts.find((l) => l.id === liftSel)) liftSel = lifts[0]?.id || null;
  const lift = lifts.find((l) => l.id === liftSel);
  const checkins = st.checkins;
  const lastCheck = checkins[checkins.length - 1];
  const daysSince = lastCheck ? Math.round((today() - fromKey(lastCheck.d)) / 86400000) : null;
  const energyData = checkins.slice(-10).map((c) => ({ label: fmtShort(fromKey(c.d)), value: c.energy }));
  const weightData = checkins.filter((c) => c.weight).slice(-10).map((c) => ({ label: fmtShort(fromKey(c.d)), value: c.weight }));
  const got = BADGES.filter((b) => st.badges[b.id]).length;

  return `
    <div class="grid-3 stagger">
      <div class="tile glass-card"><span class="stat-v tabular" data-count="${t.all}">${t.all}</span><span class="stat-l">${plural(t.all, 'aktivnost', 'aktivnosti', 'aktivnosti')}</span></div>
      <div class="tile glass-card"><span class="stat-v tabular" data-count="${t.strength}">${t.strength}</span><span class="stat-l">snage</span></div>
      <div class="tile glass-card"><span class="stat-v tabular" data-count="${s.best}">${s.best}</span><span class="stat-l">najduži niz</span></div>
    </div>

    <article class="glass-card checkin">
      <h3 class="card-title">${icon('heart')} Tjedni check-in</h3>
      <p class="muted small">${lastCheck ? (daysSince < 7 ? `Zadnji: ${fmtDate(fromKey(lastCheck.d), false)}. Sljedeći za ${7 - daysSince} ${plural(7 - daysSince, 'dan', 'dana', 'dana')}.` : 'Vrijeme je za novi check-in.') : 'Kako se osjećaš ovaj tjedan? Treba ti 20 sekundi.'}</p>
      <button class="btn ${!lastCheck || daysSince >= 7 ? 'btn-primary' : 'btn-tinted'}" data-checkin>${lastCheck && daysSince < 7 ? 'Ažuriraj check-in' : 'Napravi check-in'}</button>
    </article>

    <h3 class="group-title">Aktivnosti po tjednima</h3>
    <article class="glass-card chart-card">${bars(weeklyCounts(), { max: 5, label: 'Odrađene planirane aktivnosti po tjednu, od 5' })}
      <p class="muted small">Cilj je 5 tjedno: 3 treninga snage i 2 šetnje.</p></article>

    <h3 class="group-title">Snaga</h3>
    <article class="glass-card chart-card">
      ${lifts.length ? `
        <label class="select-wrap"><span class="sr-only">Vježba</span>
          <select id="lift-sel" data-lift>${lifts.map((l) => `<option value="${l.id}" ${l.id === liftSel ? 'selected' : ''}>${esc(l.name)}</option>`).join('')}</select>
          ${icon('chevron', 'chev down')}
        </label>
        ${lift.history.length > 1 ? lineChart(lift.history.slice(-12).map((h) => ({ label: fmtShort(fromKey(h.d)), value: h.w })), { unit: ' kg', decimals: 1, label: `Najveća kilaža po treningu, ${lift.name}` }) : '<p class="muted small">Još jedan trening s ovom vježbom i ovdje se crta graf.</p>'}
        <p class="note">${lift.gain > 0 ? `${icon('spark')} +${fmtKg(lift.gain)} od prvog treninga (${fmtKg(lift.first)} → ${fmtKg(lift.best)})` : `Početak: ${fmtKg(lift.first)}. Kad u svim serijama dođeš do vrha raspona, uzmi težu bučicu.`}</p>
      ` : '<p class="muted">Kad u treningu zapišeš kilaže, ovdje ćeš vidjeti kako ti snaga raste.</p>'}
    </article>

    ${energyData.length >= 2 ? `<h3 class="group-title">Energija</h3><article class="glass-card chart-card">${lineChart(energyData, { min: 1, max: 5, label: 'Energija od 1 do 5 po check-inu' })}</article>` : ''}

    <article class="glass-card">
      <div class="card-row">
        <div><h3 class="card-title">${icon('scale')} Bilješke o težini</h3><p class="muted small">Neobavezno i samo za tebe.</p></div>
        <label class="switch"><input id="show-weight" type="checkbox" data-showweight ${st.showWeight ? 'checked' : ''}><span class="sr-only">Prikaži bilješke o težini</span><i aria-hidden="true"></i></label>
      </div>
      ${st.showWeight ? (weightData.length >= 2 ? lineChart(weightData, { unit: ' kg', decimals: 1, label: 'Težina iz check-ina' }) : '<p class="muted small">Težinu možeš upisati u check-in. Nakon dva unosa ovdje se pojavi graf.</p>') : ''}
    </article>

    <h3 class="group-title">Značke · ${got}/${BADGES.length}</h3>
    <div class="badges stagger">
      ${BADGES.map((b) => {
        const has = st.badges[b.id];
        return `<div class="badge ${has ? 'got' : ''}" role="img" aria-label="${esc(b.name)}: ${esc(b.desc)}${has ? '. Osvojeno.' : '. Još nije osvojeno.'}">
          <span class="badge-ic" aria-hidden="true">${b.icon}</span><span class="badge-name">${esc(b.name)}</span><span class="badge-desc">${esc(b.desc)}</span></div>`;
      }).join('')}
    </div>`;
}

export function openProgress() {
  const wrap = document.createElement('div');
  const sh = openSheet({ title: 'Napredak', body: wrap, full: true });
  const draw = () => {
    wrap.innerHTML = body();
    wrap.querySelectorAll('[data-count]').forEach((el) => countUp(el, +el.dataset.count));
    wrap.querySelectorAll('.stagger').forEach((g) => stagger(g.children, { step: 30 }));
    wrap.querySelector('[data-checkin]').addEventListener('click', () => openCheckin(draw));
    wrap.querySelector('[data-lift]')?.addEventListener('change', (e) => { liftSel = e.target.value; draw(); });
    wrap.querySelector('[data-showweight]').addEventListener('change', (e) => { store.set({ showWeight: e.target.checked }); haptic(); draw(); });
  };
  draw();
  return sh;
}

export function openCheckin(after) {
  const k = keyOf(today());
  const prev = store.get().checkins.find((c) => c.d === k) || {};
  let energy = prev.energy || 0, mood = prev.mood || 0;
  const el = document.createElement('div');
  const scale = (name, items, val) => `<div class="emoji-scale" role="radiogroup" aria-label="${name === 'energy' ? 'Energija' : 'Raspoloženje'}" data-scale="${name}">
    ${items.map((i) => `<button role="radio" aria-checked="${i.v === val}" class="${i.v === val ? 'on' : ''}" data-v="${i.v}"><span aria-hidden="true">${i.e}</span><small>${i.l}</small></button>`).join('')}</div>`;
  el.innerHTML = `
    <p class="muted">Iskreno i bez ocjenjivanja.</p>
    <h3 class="group-title">Energija ovaj tjedan</h3>${scale('energy', ENERGY, energy)}
    <h3 class="group-title">Raspoloženje</h3>${scale('mood', MOODS, mood)}
    <h3 class="group-title">Težina <span class="muted">(neobavezno)</span></h3>
    <label class="field inline"><input id="ci-weight" type="number" inputmode="decimal" step="0.1" min="30" max="120" placeholder="npr. 45,0" value="${prev.weight || ''}" data-weight aria-label="Težina u kilogramima"><span>kg</span></label>
    <div class="btn-stack"><button class="btn btn-primary" data-save-ci disabled>Spremi check-in</button></div>`;
  const sh = openSheet({ title: 'Tjedni check-in', body: el });
  const saveB = el.querySelector('[data-save-ci]');
  const sync = () => { saveB.disabled = !(energy && mood); };
  el.querySelectorAll('[data-scale]').forEach((g) => g.addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]');
    if (!b) return;
    const v = +b.dataset.v;
    if (g.dataset.scale === 'energy') energy = v; else mood = v;
    g.querySelectorAll('button').forEach((x) => { const on = +x.dataset.v === v; x.classList.toggle('on', on); x.setAttribute('aria-checked', on); });
    haptic();
    sync();
  }));
  sync();
  saveB.addEventListener('click', () => {
    const raw = el.querySelector('[data-weight]').value.replace(',', '.');
    const weight = raw ? Math.round(parseFloat(raw) * 10) / 10 : null;
    addCheckin({ d: k, energy, mood, weight: weight && weight > 25 && weight < 200 ? weight : null });
    haptic('success');
    confetti(saveB);
    sh.close();
    toast('Check-in spremljen. Hvala što brineš o sebi.', { icon: '💬' });
    presentBadges(evaluateBadges());
    after?.();
  });
}
