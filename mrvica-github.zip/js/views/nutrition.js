// Prehrana: nježna načela, domaća jela i savjeti. Bez brojanja i zabrana.

import { NUTRITION_PRINCIPLES, FOOD, TIPS } from '../data.js';
import { segmented, foodCard, tipCard, askChip } from '../ui/components.js';
import { esc } from '../util.js';

export const title = 'Prehrana';
let tab = 'breakfast';

const TABS = [
  { id: 'breakfast', name: 'Doručak' },
  { id: 'meals', name: 'Obroci' },
  { id: 'snacks', name: 'Grickalice' },
  { id: 'tips', name: 'Savjeti' },
];

export function render(el) {
  let content = '';
  if (tab === 'breakfast') content = `<p class="section-lead">Doručak koji drži do ručka.</p>${FOOD.breakfast.map(foodCard).join('')}`;
  if (tab === 'meals') content = `<p class="section-lead">Ručak ili večera, domaće i jednostavno.</p>${FOOD.meals.map(foodCard).join('')}`;
  if (tab === 'snacks') content = `<p class="section-lead">Lako dodaj 200–300 kcal između obroka.</p>${FOOD.snacks.map(foodCard).join('')}`;
  if (tab === 'tips') {
    content = `
      <h2 class="section-title">Kako pojesti više, a ne osjećati se prepuno</h2>${TIPS.more.map(tipCard).join('')}
      <h2 class="section-title">Prije treninga</h2>${TIPS.pre.map(tipCard).join('')}
      <h2 class="section-title">Nakon treninga</h2>${TIPS.post.map(tipCard).join('')}
      <h2 class="section-title">Voda</h2>${TIPS.water.map(tipCard).join('')}`;
  }

  el.innerHTML = `
    <header class="large-head">
      <p class="eyebrow">Hrana je gorivo za jačanje</p>
      <h1 class="large-title">Prehrana</h1>
    </header>
    <div class="chip-row">${askChip('Što da jedem danas? Predloži mi obroke za cijeli dan.', 'Što da jedem danas?')}</div>
    <article class="glass-card principles">
      ${NUTRITION_PRINCIPLES.map((p) => `<div class="pr-row"><span class="pr-ic" aria-hidden="true">${p.icon}</span><div><h3 class="card-title">${esc(p.title)}</h3><p class="muted small">${esc(p.text)}</p></div></div>`).join('')}
    </article>
    ${segmented('ntab', TABS, tab, 'Kategorija prehrane')}
    <div class="stack">${content}</div>
    <p class="footnote">Kalorije i proteini su okvirni, samo za orijentaciju. Za plan po mjeri najbolje je pitati nutricionista.</p>`;

  el.querySelector('[data-seg="ntab"]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-val]');
    if (!b) return;
    tab = b.dataset.val;
    render(el);
  });
}
