// Način treninga: korak po korak kroz zagrijavanje, vježbe s odmorom, istezanje i završetak.

import { EX, WARMUP, COOLDOWN, DONE_MESSAGES } from '../data.js';
import { mountExercise, exerciseFrames } from '../illustrations.js';
import { Mascot } from '../mascot.js';
import { presentBadges } from '../ui/celebrate.js';
import { openSheet } from '../ui/sheet.js';
import { setSwap, addChat, addMemory } from '../store.js';
import { SWAPS } from '../data.js';
import { ask } from './buddy.js';
import { icon } from '../ui/icons.js';
import { ring } from '../ui/charts.js';
import { confetti, toast } from '../ui/feedback.js';
import { confirmSheet, sheetOpen, closeTopSheet } from '../ui/sheet.js';
import { exerciseSheet } from '../ui/components.js';
import { tick } from '../motion.js';
import { addLog, lastLog, markDone } from '../store.js';
import { strengthItems, topReps, evaluateBadges } from '../engine.js';
import { esc, fmtTime, fmtKg, haptic, pick, reducedMotion } from '../util.js';

let current = null;

export function startWorkout(session, { short = false, onFinish } = {}) {
  if (current) return;
  const steps = [];
  if (session.type === 'strength') {
    const items = short ? strengthItems(session.day, session.week, true) : session.items;
    if (!short) steps.push({ kind: 'timed', title: 'Zagrijavanje', segs: WARMUP, skippable: true });
    items.forEach((it, i) => steps.push({ kind: 'exercise', it, idx: i, count: items.length }));
    if (!short) steps.push({ kind: 'timed', title: 'Istezanje', segs: COOLDOWN, skippable: true });
  } else {
    steps.push({ kind: 'timed', title: session.type === 'walk' ? session.title : 'Lagano istezanje', segs: session.segments, walk: session.type === 'walk' });
  }
  steps.push({ kind: 'finish' });

  const el = document.createElement('div');
  el.className = 'workout';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-modal', 'true');
  el.setAttribute('aria-label', short ? `${session.title}, kratka verzija` : session.title);
  document.body.append(el);
  document.body.classList.add('has-workout');
  requestAnimationFrame(() => el.classList.add('open'));

  const S = {
    session, short, steps, i: 0, el,
    logs: {},          // exId → { sets: [], note }
    startedAt: Date.now(),
    timer: null, rest: null,
  };
  current = S;

  const wakeLock = { lock: null };
  try { navigator.wakeLock?.request('screen').then((l) => { wakeLock.lock = l; }).catch(() => {}); } catch { /* nije podržano */ }

  function close(done) {
    clearInterval(S.timer);
    clearInterval(S.rest?.int);
    S.anim?.destroy();
    try { wakeLock.lock?.release(); } catch { /* */ }
    commitLogs();
    el.classList.remove('open');
    setTimeout(() => { el.remove(); document.body.classList.remove('has-workout'); }, reducedMotion() ? 0 : 320);
    current = null;
    window.removeEventListener('keydown', onKey);
    if (done) onFinish?.();
  }

  function commitLogs() {
    for (const [id, l] of Object.entries(S.logs)) {
      if (l.sets.length || l.note || l.skipped) addLog(id, { d: session.key, sets: l.sets, note: l.note || '', ...(l.rpe ? { rpe: l.rpe } : {}), ...(l.skipped && !l.sets.length ? { skipped: true } : {}) });
    }
    S.logs = {};
  }

  async function askQuit() {
    const anyDone = Object.values(S.logs).some((l) => l.sets.length);
    const ok = await confirmSheet({
      title: 'Prekinuti trening?',
      text: anyDone ? 'Odrađene serije ostaju spremljene. Trening možeš označiti kao gotov i kasnije, s početnog zaslona.' : 'Ništa se neće izgubiti. Možeš početi ponovo kad god želiš.',
      confirm: 'Prekini',
    });
    if (ok) close(false);
  }

  function onKey(e) {
    if (e.key === 'Escape' && !sheetOpen()) askQuit();
  }
  window.addEventListener('keydown', onKey);
  el.addEventListener('click', (e) => { if (e.target.closest('[data-quit]')) askQuit(); });

  function header(progressLabel, pct) {
    return `<header class="wo-head">
      <button class="btn-text" data-quit>Prekini</button>
      <div class="wo-progress" aria-label="${esc(progressLabel)}"><span style="width:${Math.round(pct * 100)}%"></span></div>
      <span class="wo-count">${esc(progressLabel)}</span>
    </header>`;
  }

  function overallPct() { return S.i / (steps.length - 1); }

  function go(delta) {
    clearInterval(S.timer);
    S.i = Math.max(0, Math.min(steps.length - 1, S.i + delta));
    render();
  }

  function render() {
    const st = steps[S.i];
    if (st.kind === 'timed') renderTimed(st);
    else if (st.kind === 'exercise') renderExercise(st);
    else renderFinish();
    el.querySelector('.wo-body')?.scrollTo?.(0, 0);
  }

  // ── Vremenski blok (zagrijavanje, istezanje, šetnja) ──
  function renderTimed(st) {
    let seg = 0;
    let left = st.segs[0].secs;
    let endAt = Date.now() + left * 1000;
    let paused = false;
    const total = st.segs.reduce((a, s) => a + s.secs, 0);

    el.innerHTML = `${header(st.title, overallPct())}
      <div class="wo-body timed">
        <div class="timed-m" aria-hidden="true"></div>
        <p class="eyebrow center">${esc(st.title)}</p>
        <div class="timer-ring" aria-live="polite">
          <div class="tr-svg"></div>
          <div class="tr-text"><span class="tr-time tabular"></span><span class="tr-sub"></span></div>
        </div>
        <h2 class="wo-title center seg-name"></h2>
        <p class="muted center seg-next"></p>
        <ol class="seg-list"></ol>
      </div>
      <footer class="wo-foot">
        <div class="btn-row">
          <button class="btn btn-tinted round" data-prev aria-label="Prethodni dio">${icon('back')}</button>
          <button class="btn btn-primary grow" data-pause>${icon('timer')} Pauza</button>
          <button class="btn btn-tinted round" data-skip aria-label="Sljedeći dio">${icon('skip')}</button>
        </div>
        ${st.skippable ? `<button class="btn btn-plain" data-skipall>Preskoči ${st.title.toLowerCase()}</button>` : `<button class="btn btn-plain" data-skipall>Završi ranije</button>`}
      </footer>`;

    new Mascot(el.querySelector('.timed-m'), { expr: 'happy', pose: st.walk ? 'idle' : 'stretching', size: 56, track: false });
    const list = el.querySelector('.seg-list');
    list.innerHTML = st.segs.map((s, i) => `<li data-i="${i}"><span>${esc(s.name)}${s.sub ? ` <em>${esc(s.sub)}</em>` : ''}</span><span class="tabular">${fmtTime(s.secs)}</span></li>`).join('');

    const draw = () => {
      const s = st.segs[seg];
      el.querySelector('.tr-svg').innerHTML = ring(s.secs - left, s.secs, { size: 220, stroke: 14, cls: st.walk ? 'lilac' : 'sage', label: `Preostalo ${fmtTime(left)}` });
      el.querySelector('.tr-time').textContent = fmtTime(left);
      el.querySelector('.tr-sub').textContent = s.sub || `${seg + 1} / ${st.segs.length}`;
      el.querySelector('.seg-name').textContent = s.name;
      const nx = st.segs[seg + 1];
      el.querySelector('.seg-next').textContent = nx ? `Sljedeće: ${nx.name}${nx.sub ? ` · ${nx.sub}` : ''}` : `Ukupno ${Math.round(total / 60)} min`;
      list.querySelectorAll('li').forEach((li, i) => { li.classList.toggle('now', i === seg); li.classList.toggle('past', i < seg); });
    };
    const setSeg = (n) => {
      if (n >= st.segs.length) { haptic('success'); go(1); return; }
      seg = Math.max(0, n);
      left = st.segs[seg].secs;
      endAt = Date.now() + left * 1000;
      draw();
    };
    S.timer = setInterval(() => {
      if (paused) return;
      left = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      if (left <= 0) { haptic('heavy'); setSeg(seg + 1); return; }
      draw();
    }, 250);
    draw();

    el.querySelector('[data-pause]').addEventListener('click', (e) => {
      paused = !paused;
      if (!paused) endAt = Date.now() + left * 1000;
      e.currentTarget.innerHTML = paused ? `${icon('play')} Nastavi` : `${icon('timer')} Pauza`;
      haptic();
    });
    el.querySelector('[data-skip]').addEventListener('click', () => { haptic(); setSeg(seg + 1); });
    el.querySelector('[data-prev]').addEventListener('click', () => { haptic(); if (seg === 0 && S.i > 0) go(-1); else setSeg(seg - 1); });
    el.querySelector('[data-skipall]').addEventListener('click', () => go(1));
  }

  // ── Vježba ──
  function renderExercise(st) {
    const { it } = st;
    const ex = EX[it.ex];
    const log = (S.logs[it.ex] = S.logs[it.ex] || { sets: [], note: '' });
    const prev = lastLog(it.ex, session.key);
    const prevW = prev ? Math.max(0, ...prev.sets.map((s) => s.w || 0)) : 0;
    const top = topReps(it.reps);
    const hitTop = prev && prev.sets.length >= it.sets && prev.sets.every((s) => (s.r || 0) >= top);
    const timed = !!it.timed;
    const lastSet = log.sets[log.sets.length - 1];
    let w = lastSet?.w ?? (hitTop ? prevW + 1 : prevW);
    let r = lastSet?.r ?? (timed ? parseInt(it.reps, 10) || 30 : top - 2);
    const setNo = Math.min(log.sets.length + 1, it.sets);
    const allDone = log.sets.length >= it.sets;
    const noWeight = ['plank', 'dead-bug', 'bird-dog'].includes(it.ex);

    el.innerHTML = `${header(`Vježba ${st.idx + 1} od ${st.count}`, overallPct())}
      <div class="wo-body">
        <div class="ill-wrap wo-ill"><div data-ill></div><div class="wo-m" aria-hidden="true"></div></div>
        <div class="card-row">
          <div>
            <h2 class="wo-title">${esc(it.name)}</h2>
            <p class="muted">${it.sets} × ${esc(it.reps)}${it.tempo ? ` · ${esc(it.tempo)}` : ''} · odmor ${it.rest} s</p>
          </div>
          <button class="icon-btn tinted" data-info aria-label="Kako se izvodi: ${esc(ex.name)}">${icon('info')}</button>
        </div>
        ${it.swappedFrom ? `<p class="note">${icon('undo')} Umjesto: ${esc(EX[it.swappedFrom].name)} (${esc(it.why)})</p>` : ''}
        <ul class="cues compact tip-box tip-do">${ex.cues.slice(0, 2).map((c) => `<li>${icon('check')}<span>${esc(c)}</span></li>`).join('')}</ul>
        <div class="set-dots" role="list" aria-label="Serije">
          ${Array.from({ length: it.sets }, (_, i) => {
            const s = log.sets[i];
            return `<span role="listitem" class="sd ${s ? 'done' : i === log.sets.length ? 'now' : ''}">${s ? (noWeight ? `${s.r}` : `${String(s.w).replace('.', ',')}×${s.r}`) : `${i + 1}.`}</span>`;
          }).join('')}
        </div>
        ${prev ? `<p class="prev">Prošli put: ${prev.sets.map((s) => (noWeight ? `${s.r}` : `${String(s.w).replace('.', ',')} kg × ${s.r}`)).join(', ')}${hitTop && !noWeight ? `<br><strong>Sve serije do ${top}! Danas probaj malo težu bučicu.</strong>` : ''}</p>` : `<p class="prev">Prvi put radiš ovu vježbu. Izaberi kilažu s kojom su zadnja 2 ponavljanja teška, a forma ostaje lijepa.</p>`}
        ${allDone ? `<div class="rpe"><span class="st-label">Kako je bilo?</span><div class="chips-inline">${[['6', 'Lako'], ['8', 'Taman'], ['9.5', 'Teško']].map(([v, l]) => `<button class="chip ${String(log.rpe) === v ? 'on' : ''}" data-rpe="${v}">${l}</button>`).join('')}</div></div>` : ''}
        ${allDone ? '' : `<div class="steppers">
          ${noWeight ? '' : `<div class="stepper" data-field="w">
            <span class="st-label">Kilaža</span>
            <div class="st-ctl"><button class="st-btn" data-d="-0.5" aria-label="Smanji kilažu">${icon('minus')}</button>
            <output class="st-val tabular" aria-live="polite">${fmtKg(w)}</output>
            <button class="st-btn" data-d="0.5" aria-label="Povećaj kilažu">${icon('plus')}</button></div>
          </div>`}
          <div class="stepper" data-field="r">
            <span class="st-label">${timed ? 'Sekunde' : /strani/.test(it.reps) ? 'Ponavljanja po strani' : 'Ponavljanja'}</span>
            <div class="st-ctl"><button class="st-btn" data-d="${timed ? -5 : -1}" aria-label="Manje">${icon('minus')}</button>
            <output class="st-val tabular" aria-live="polite">${r}</output>
            <button class="st-btn" data-d="${timed ? 5 : 1}" aria-label="Više">${icon('plus')}</button></div>
          </div>
        </div>`}
        <label class="field">
          <span class="st-label">Bilješka</span>
          <textarea rows="2" data-note placeholder="${esc(prev?.note ? `Prošli put: ${prev.note}` : 'Npr. bučice od 4 kg, zadnja serija teška')}">${esc(log.note || '')}</textarea>
        </label>
      </div>
      <footer class="wo-foot">
        ${allDone
          ? `<button class="btn btn-primary" data-next>${st.idx + 1 < st.count ? 'Sljedeća vježba' : 'Dalje'} ${icon('chevron')}</button>`
          : `<button class="btn btn-primary big" data-set>${icon('check')} Završi ${setNo}. seriju</button>`}
        <div class="btn-row">
          <button class="btn btn-plain" data-prev>${icon('back')} Natrag</button>
          <button class="btn btn-plain" data-pain>${icon('heart')} Boli me</button>
          <button class="btn btn-plain" data-skipex>Preskoči</button>
        </div>
      </footer>`;
    const anim = mountExercise(el.querySelector('[data-ill]'), it.ex, { labels: exerciseFrames(it.ex), title: ex.name });
    S.anim?.destroy(); S.anim = anim;
    S.mascot = new Mascot(el.querySelector('.wo-m'), { expr: allDone ? 'proud' : 'encouraging', pose: allDone ? 'flexing' : 'dumbbell', size: 54, track: false });
    el.querySelectorAll('[data-rpe]').forEach((b) => b.addEventListener('click', () => { log.rpe = parseFloat(b.dataset.rpe); el.querySelectorAll('[data-rpe]').forEach((x) => x.classList.toggle('on', x === b)); haptic(); }));
    el.querySelector('[data-pain]').addEventListener('click', () => painSheet(st));

    const noteEl = el.querySelector('[data-note]');
    noteEl.addEventListener('input', () => { log.note = noteEl.value.slice(0, 200); });

    el.querySelectorAll('.stepper').forEach((sp) => {
      const field = sp.dataset.field;
      const out = sp.querySelector('output');
      sp.querySelectorAll('.st-btn').forEach((b) => b.addEventListener('click', () => {
        const d = parseFloat(b.dataset.d);
        if (field === 'w') { w = Math.max(0, Math.round((w + d) * 10) / 10); out.textContent = fmtKg(w); }
        else { r = Math.max(0, r + d); out.textContent = r; }
        haptic();
      }));
    });
    el.querySelector('[data-info]').addEventListener('click', () => exerciseSheet(it.ex));
    el.querySelector('[data-prev]').addEventListener('click', () => go(-1));
    el.querySelector('[data-skipex]').addEventListener('click', () => { if (!log.sets.length) log.skipped = true; go(1); });
    el.querySelector('[data-next]')?.addEventListener('click', () => go(1));
    el.querySelector('[data-set]')?.addEventListener('click', (e) => {
      log.sets.push({ w: noWeight ? 0 : w, r });
      haptic('success');
      const finishedEx = log.sets.length >= it.sets;
      const isLastEx = st.idx + 1 >= st.count;
      if (finishedEx && isLastEx) { go(1); return; }
      if (!finishedEx) renderExercise(st);
      S.mascot?.set('excited', 'cheering'); S.mascot?.hop(14); tick('success');
      startRest(it.rest, finishedEx ? (steps[S.i + 1]?.it ? `Sljedeće: ${steps[S.i + 1].it.name}` : '') : `Sljedeća: ${log.sets.length + 1}. serija`, () => {
        if (finishedEx) go(1);
      });
    });
  }

  // ── Kad nešto boli: nježno, bez uputa, s brzim izborom ──
  function painSheet(st) {
    const id = st.it.ex;
    const to = SWAPS[id];
    S.mascot?.set('caring', 'hug'); S.mascot?.lean();
    const body = document.createElement('div');
    body.innerHTML = `<div class="care-m"></div>
      <p class="body-text">Hvala što slušaš svoje tijelo. Ne guraj kroz bol. Ako je bol oštra, osjetiš vrtoglavicu ili mučninu, stani za danas. Ako ne prolazi, javi se liječniku.</p>
      <div class="btn-stack">
        ${to ? `<button class="btn btn-primary" data-swap>${icon('undo')} Zamijeni s: ${esc(EX[to.to].name)}</button><p class="muted small center">${esc(to.why)}. Vrijedi i za sljedeće treninge, a možeš je vratiti.</p>` : ''}
        <button class="btn btn-tinted" data-skip>Preskoči ovu vježbu danas</button>
        <button class="btn btn-tinted" data-stop>Završi trening za danas</button>
        <button class="btn btn-plain" data-buddy>${icon('spark')} Popričaj s Mrvicom</button>
      </div>`;
    const sh = openSheet({ title: 'Nešto ne paše?', body, onClose: () => { S.mascot?.unlean?.(); } });
    new Mascot(body.querySelector('.care-m'), { expr: 'caring', pose: 'hug', size: 84, track: false });
    body.querySelector('[data-swap]')?.addEventListener('click', () => {
      setSwap(id, to.to);
      addMemory(`Pri vježbi ${EX[id].name.toLowerCase()} osjeća nelagodu`);
      steps[S.i] = { ...st, it: { ...st.it, ex: to.to, name: EX[to.to].name, swappedFrom: id, why: to.why } };
      sh.close();
      toast(`${EX[id].name} → ${EX[to.to].name}`, { icon: '🔄' });
      render();
    });
    body.querySelector('[data-skip]').addEventListener('click', () => { const lg = S.logs[id] = S.logs[id] || { sets: [], note: '' }; if (!lg.sets.length) lg.skipped = true; sh.close(); go(1); });
    body.querySelector('[data-stop]').addEventListener('click', () => { sh.close(); close(false); });
    body.querySelector('[data-buddy]').addEventListener('click', () => { sh.close(); close(false); ask(`Tijekom vježbe ${EX[id].name.toLowerCase()} se ne osjećam dobro.`); });
  }

  // ── Odmor između serija ──
  function startRest(secs, nextLabel, onDone) {
    clearInterval(S.rest?.int);
    let total = secs;
    let endAt = Date.now() + secs * 1000;
    const ov = document.createElement('div');
    ov.className = 'rest-ov material';
    ov.setAttribute('role', 'alertdialog');
    ov.setAttribute('aria-label', 'Odmor');
    ov.innerHTML = `<div class="rest-m" aria-hidden="true"></div><p class="eyebrow center">Odmor</p>
      <div class="timer-ring"><div class="tr-svg"></div><div class="tr-text"><span class="tr-time tabular"></span><span class="tr-sub">diši duboko</span></div></div>
      <p class="muted center">${esc(nextLabel)}</p>
      <div class="btn-row">
        <button class="btn btn-tinted" data-add>+15 s</button>
        <button class="btn btn-primary grow" data-end>Preskoči odmor</button>
      </div>`;
    el.append(ov);
    new Mascot(ov.querySelector('.rest-m'), { expr: 'sleepy', pose: 'resting', size: 60, track: false });
    requestAnimationFrame(() => ov.classList.add('in'));
    const finish = () => {
      clearInterval(S.rest?.int);
      ov.classList.remove('in');
      setTimeout(() => ov.remove(), reducedMotion() ? 0 : 250);
      S.rest = null;
      onDone();
    };
    const draw = () => {
      const left = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      ov.querySelector('.tr-svg').innerHTML = ring(total - left, total, { size: 200, stroke: 14, cls: 'lilac', label: `Odmor, preostalo ${fmtTime(left)}` });
      ov.querySelector('.tr-time').textContent = fmtTime(left);
      if (left <= 0) { haptic('heavy'); finish(); }
    };
    S.rest = { int: setInterval(draw, 250) };
    draw();
    ov.querySelector('[data-add]').addEventListener('click', () => { endAt += 15000; total += 15; haptic(); draw(); });
    ov.querySelector('[data-end]').addEventListener('click', () => { haptic(); finish(); });
  }

  // ── Završetak ──
  function renderFinish() {
    const mins = Math.max(1, Math.round((Date.now() - S.startedAt) / 60000));
    const sets = Object.values(S.logs).reduce((a, l) => a + l.sets.length, 0);
    const kg = Math.round(Object.values(S.logs).reduce((a, l) => a + l.sets.reduce((b, s) => b + s.w * s.r, 0), 0));
    el.innerHTML = `${header('Gotovo', 1)}
      <div class="wo-body finish">
        <div class="finish-m"></div>
        <h2 class="wo-title center">Bravo, Dora!</h2>
        <p class="muted center">${esc(pick(DONE_MESSAGES, Date.now() % 997))}</p>
        <div class="stat-row">
          <div class="stat"><span class="stat-v tabular">${mins}</span><span class="stat-l">min</span></div>
          ${session.type === 'strength' ? `<div class="stat"><span class="stat-v tabular">${sets}</span><span class="stat-l">serija</span></div>
          <div class="stat"><span class="stat-v tabular">${kg}</span><span class="stat-l">kg ukupno</span></div>` : `<div class="stat"><span class="stat-v tabular">${Math.round(session.segments.reduce((a, s) => a + s.secs, 0) / 60)}</span><span class="stat-l">min u planu</span></div>`}
        </div>
      </div>
      <footer class="wo-foot">
        <button class="btn btn-primary big" data-done>${icon('check')} Označi kao gotovo</button>
        <button class="btn btn-plain" data-back>${icon('back')} Natrag</button>
      </footer>`;
    S.anim?.destroy();
    const fm = new Mascot(el.querySelector('.finish-m'), { expr: 'celebrating', pose: 'cheering', size: 132 });
    setTimeout(() => { fm.dance(); confetti(el.querySelector('.finish-m')); }, 250);
    el.querySelector('[data-back]').addEventListener('click', () => go(-1));
    el.querySelector('[data-done]').addEventListener('click', (e) => {
      commitLogs();
      markDone(session.key, session.type === 'rest' ? 'mobility' : session.type, { short });
      haptic('success');
      confetti(e.currentTarget);
      fm.hop(20);
      const badges = evaluateBadges();
      // Buddy pita kako je prošlo (stiže kao poruka, odgovor jednim tapom)
      addChat({ role: 'buddy', kind: 'ask', mood: 'proud', text: session.type === 'strength' ? 'Bravo za današnji trening! Kako je prošlo?' : 'Super, odrađeno! Kako se osjećaš?', quick: ['Lako', 'Taman', 'Teško'] });
      document.querySelector('[data-tab="buddy"]')?.classList.add('unread');
      setTimeout(() => {
        close(true);
        presentBadges(badges);
      }, reducedMotion() ? 200 : 900);
    });
  }

  render();
}

export const workoutOpen = () => !!current;
export { closeTopSheet };
