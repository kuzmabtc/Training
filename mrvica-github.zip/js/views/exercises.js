// Vježbe: popis svih 14 vježbi s ilustracijama i filtrima.

import { EXERCISES, CATEGORIES } from '../data.js';
import { exerciseThumb } from '../illustrations.js';
import { icon } from '../ui/icons.js';
import { chips, saveBtn } from '../ui/components.js';
import { bestLifts } from '../engine.js';
import { esc, fmtKg } from '../util.js';

export const title = 'Vježbe';
let cat = 'sve';

export function renderList(el) {
  const lifts = Object.fromEntries(bestLifts().map((b) => [b.id, b]));
  const list = EXERCISES.filter((e) => cat === 'sve' || e.cat === cat);
  el.innerHTML = `
    ${chips('cat', CATEGORIES, cat, 'Filtriraj po dijelu tijela')}
    <div class="ex-grid">
      ${list.map((e) => `<article class="glass-card ex-card">
        <button class="ex-open" data-ex="${e.id}" aria-label="${esc(e.name)}: upute">
          <span class="ex-thumb">${exerciseThumb(e.id)}</span>
          <span class="ex-name">${esc(e.name)}</span>
          <span class="ex-mus">${esc(e.muscles)}</span>
          ${lifts[e.id] ? `<span class="pill pill-rose">${fmtKg(lifts[e.id].best)}</span>` : ''}
        </button>
        <div class="ex-save">${saveBtn(`ex:${e.id}`, e.name)}</div>
      </article>`).join('')}
    </div>
    <p class="footnote">${icon('info')} Tapni vježbu za animaciju, upute i lakšu ili težu varijantu.</p>`;

  el.querySelector('[data-seg="cat"]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-val]');
    if (!b) return;
    cat = b.dataset.val;
    renderList(el);
  });
}
