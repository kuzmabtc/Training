// Plan: 12 tjedana u 3 faze, svaki dan otvara detalje.

import { PHASES, RULES } from '../data.js';
import { store } from '../store.js';
import { sessionFor, startMonday, weekOf, TOTAL_WEEKS, sessionColor } from '../engine.js';
import { icon } from '../ui/icons.js';
import { segmented, chips, saveBtn, safetyCard } from '../ui/components.js';
import { addDays, today, keyOf, esc, fmtShort, DAYS_SHORT, DAYS_MON } from '../util.js';
import { DELOAD_WEEKS } from '../data.js';
import { renderList as renderExercises } from './exercises.js';
import { stagger } from '../motion.js';

export const title = 'Plan';

let phaseSel = null;
let mode = 'raspored';
let openWeek = null;

export function render(el) {
  if (mode === 'vjezbe') {
    el.innerHTML = `<header class="large-head"><p class="eyebrow">14 vježbi · bučice i podloga</p><h1 class="large-title">Plan</h1></header>
      ${segmented('mode', [{ id: 'raspored', name: 'Raspored' }, { id: 'vjezbe', name: 'Vježbe' }], mode, 'Prikaz')}<div class="sub"></div>`;
    renderExercises(el.querySelector('.sub'));
    bindMode(el);
    return;
  }
  const t = today();
  const curWeek = weekOf(t);
  const curPhase = PHASES.find((p) => curWeek >= p.from && curWeek <= p.to)?.n || (curWeek > TOTAL_WEEKS ? 3 : 1);
  if (phaseSel == null) phaseSel = curPhase;
  if (openWeek == null) openWeek = Math.max(1, Math.min(TOTAL_WEEKS, curWeek));
  const phase = PHASES[phaseSel - 1];
  const done = store.get().done;
  const mon = startMonday();

  const weeks = [];
  for (let w = phase.from; w <= phase.to; w++) {
    const wMon = addDays(mon, (w - 1) * 7);
    const days = Array.from({ length: 7 }, (_, i) => sessionFor(addDays(wMon, i)));
    const planned = days.filter((d) => d.type !== 'rest');
    const completed = planned.filter((d) => done[d.key]).length;
    const isCur = w === curWeek;
    const isOpen = w === openWeek;
    weeks.push(`
      <article class="glass-card week ${isCur ? 'current' : ''} ${isOpen ? 'open' : ''}">
        <button class="week-head" data-week="${w}" aria-expanded="${isOpen}">
          <span class="lr-main">
            <span class="eyebrow">${fmtShort(wMon)} – ${fmtShort(addDays(wMon, 6))}${isCur ? ' · ovaj tjedan' : ''}</span>
            <span class="week-title">Tjedan ${w}${DELOAD_WEEKS.includes(w) ? ' <span class="pill pill-sage">lakši</span>' : ''}</span>
          </span>
          <span class="week-count tabular">${completed}/${planned.length}</span>
          ${icon('chevron', 'chev rot')}
        </button>
        <div class="week-strip" aria-hidden="${isOpen}">
          ${days.map((d, i) => `<span class="wd ${done[d.key] ? 'done' : ''} ${d.type === 'rest' ? 'rest' : ''} wd-${sessionColor(d.type)} ${keyOf(d.date) === keyOf(t) ? 'today' : ''}"><b>${DAYS_SHORT[i]}</b></span>`).join('')}
        </div>
        ${isOpen ? `<div class="list-group inset">
          ${days.map((d, i) => `<button class="list-row tappable" data-day="${d.key}">
            <span class="day-dot dd-${sessionColor(d.type)} ${done[d.key] ? 'done' : ''}" aria-hidden="true">${done[d.key] ? icon('check') : ''}</span>
            <span class="lr-main"><span class="lr-label">${DAYS_MON[i]}${keyOf(d.date) === keyOf(t) ? ' · danas' : ''}</span>
              <span class="lr-sub">${esc(d.title)}${d.type !== 'rest' ? ` · ${d.minutes} min` : ' · neobavezno istezanje'}</span></span>
            ${done[d.key] ? '<span class="sr-only">odrađeno</span>' : ''}
            ${icon('chevron', 'chev')}
          </button>`).join('')}
        </div>` : ''}
      </article>`);
  }

  el.innerHTML = `
    <header class="large-head">
      <p class="eyebrow">12 tjedana · 3 faze</p>
      <h1 class="large-title">Plan</h1>
    </header>
    ${segmented('mode', [{ id: 'raspored', name: 'Raspored' }, { id: 'vjezbe', name: 'Vježbe' }], mode, 'Prikaz')}
    ${chips('phase', PHASES.map((p) => ({ id: p.n, name: `${p.n}. ${p.name}` })), phaseSel, 'Faza plana')}
    <article class="glass-card phase-card phase-${phaseSel}">
      <p class="eyebrow">Tjedni ${phase.from}–${phase.to} · ${esc(phase.short)}</p>
      <p class="body-text">${esc(phase.text)}</p>
      <div class="legend">
        <span><i class="lg lg-rose"></i>Snaga pon, sri, pet</span>
        <span><i class="lg lg-lilac"></i>Šetnja uto, sub</span>
        <span><i class="lg lg-sage"></i>Odmor čet, ned</span>
      </div>
    </article>
    ${weeks.join('')}
    <h2 class="section-title">Pravila igre</h2>
    ${RULES.map((r) => `<article class="glass-card tip-card">
      <div class="card-row"><h3 class="card-title">${esc(r.title)}</h3>${saveBtn(`tip:${r.id}`, r.title)}</div>
      <p class="muted">${esc(r.text)}</p>
    </article>`).join('')}
    ${safetyCard()}`;

  bindMode(el);
  el.querySelector('[data-seg="phase"]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-val]');
    if (!b) return;
    phaseSel = +b.dataset.val;
    const ph = PHASES[phaseSel - 1];
    openWeek = curWeek >= ph.from && curWeek <= ph.to ? curWeek : ph.from;
    render(el);
  });
  el.querySelectorAll('[data-week]').forEach((b) => b.addEventListener('click', () => {
    const w = +b.dataset.week;
    openWeek = openWeek === w ? 0 : w;
    render(el);
  }));
}

function bindMode(el) {
  el.querySelector('[data-seg="mode"]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-val]');
    if (!b || b.dataset.val === mode) return;
    mode = b.dataset.val;
    render(el);
    stagger(el.querySelectorAll('.week, .ex-card'), { step: 25 });
  });
}
