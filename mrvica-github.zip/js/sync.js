// Tiha sinkronizacija statistike na backend (POST /sync). Nikad ne blokira sučelje, greške se ignoriraju.

import { configured, syncSnapshot } from './api.js';
import { snapshot } from './ai.js';

let timer = null, inFlight = false, lastSent = 0, lastJson = '';

export function syncStats({ delay = 2500, force = false } = {}) {
  if (!configured()) return;
  clearTimeout(timer);
  timer = setTimeout(async () => {
    if (inFlight || !navigator.onLine) return;
    let snap;
    try { snap = snapshot(); } catch { return; }
    const { generirano, ...rest } = snap;
    const json = JSON.stringify(rest);
    if (!force && json === lastJson && Date.now() - lastSent < 10 * 60 * 1000) return;
    inFlight = true;
    try {
      await syncSnapshot(snap);
      lastSent = Date.now();
      lastJson = json;
    } catch { /* backend nedostupan: pokušat će se kod sljedećeg otvaranja */ }
    finally { inFlight = false; }
  }, delay);
}
