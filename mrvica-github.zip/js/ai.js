// Buddy logika na klijentu: sažetak Dorinih podataka (šalje se na /sync), raščlamba odgovora, akcije,
// osjetljive teme i lokalna rezerva. AI poziv ide isključivo preko backenda (js/api.js). Ovdje nema ključeva.
// Tekst modela nikad ne ide u innerHTML; prikazuje se samo kroz textContent.

import { configured } from './api.js';
import { USER, EX, EXERCISES, FOOD, TIPS, SWAPS, ENERGY, MOODS } from './data.js';
import { store } from './store.js';
import { sessionFor, weekOf, phaseOfWeek, streaks, totals, weekProgress, bestLifts, startMonday, TOTAL_WEEKS } from './engine.js';
import { today, keyOf, fromKey, diffDays, pick } from './util.js';

export const hasKey = () => configured();
export const ERROR_TEXT = 'Buddy se malo odmara, probaj za par minuta 💛';

export const ACTIONS = {
  save: 'Spremi u Spremljeno',
  open_today: 'Otvori današnji trening',
  start_short: 'Pokreni 15-min verziju',
  swap: 'Zamijeni vježbu',
  add_note: 'Dodaj bilješku',
  show_progress: 'Pokaži napredak',
};
export const MOODS_ALLOWED = ['happy', 'excited', 'proud', 'sleepy', 'encouraging', 'thinking', 'celebrating', 'caring', 'shy'];

const VALID_KEY = (k) => {
  const [t, id] = String(k || '').split(':');
  if (t === 'ex') return !!EX[id];
  if (t === 'food') return [...FOOD.breakfast, ...FOOD.meals, ...FOOD.snacks].some((f) => f.id === id);
  if (t === 'tip') return Object.values(TIPS).flat().some((x) => x.id === id);
  return false;
};

export function validateAction(a) {
  if (!a || typeof a !== 'object' || !ACTIONS[a.id]) return null;
  const out = { id: a.id };
  // nepoznat ex ili key ne ruši akciju: zamjena tada otvara popis, a spremanje sprema samu poruku
  if (a.id === 'swap' && a.ex && EX[a.ex]) out.ex = a.ex;
  if (a.id === 'save' && a.key && VALID_KEY(a.key)) out.key = a.key;
  return out;
}

// ── Sažetak podataka (oko 400–800 tokena) ──

export function snapshot() {
  const st = store.get();
  const t = today();
  const w = weekOf(t);
  const tot = totals();
  const sk = streaks();
  const wp = weekProgress(t);
  const doneKeys = Object.keys(st.done).sort();
  const last = doneKeys[doneKeys.length - 1];
  const walkMin = Object.entries(st.done).filter(([, v]) => v.kind === 'walk').reduce((a, [k]) => a + (sessionFor(fromKey(k)).minutes || 0), 0);
  const strengthMin = Object.entries(st.done).filter(([, v]) => v.kind === 'strength').reduce((a, [k, v]) => a + (v.short ? 15 : sessionFor(fromKey(k)).minutes || 0), 0);
  const ex = {};
  for (const [id, list] of Object.entries(st.logs)) {
    const l3 = list.slice(-3).map((l) => ({ d: l.d.slice(5), s: l.sets.map((s) => (s.w ? `${s.w}x${s.r}` : `${s.r}`)).join(','), ...(l.rpe ? { rpe: l.rpe } : {}), ...(l.skipped ? { skip: 1 } : {}) }));
    const best = Math.max(0, ...list.flatMap((l) => l.sets.map((s) => s.w || 0)));
    ex[id] = { last: l3, ...(best ? { pr_kg: best } : {}) };
  }
  const notes = [...Object.entries(st.done).filter(([, v]) => v.note || v.feel).slice(-4).map(([k, v]) => `${k.slice(5)}: ${v.feel || ''} ${v.note || ''}`.trim()), ...st.notes.slice(0, 2).map((n) => n.text.slice(0, 80))];
  const today_s = sessionFor(t);
  // zadnje 3 sesije s kilažama
  const sessions = doneKeys.slice(-3).map((k) => {
    const lifts = Object.entries(st.logs).map(([id, list]) => {
      const l = list.find((x) => x.d === k);
      return l && l.sets.length ? `${id} ${l.sets.map((s2) => (s2.w ? `${s2.w}x${s2.r}` : `${s2.r}`)).join(',')}` : null;
    }).filter(Boolean);
    return { d: k, tip: st.done[k].kind, ...(st.done[k].short ? { kratka: 1 } : {}), ...(st.done[k].feel ? { osjecaj: st.done[k].feel } : {}), ...(lifts.length ? { kilaze: lifts } : {}) };
  });
  const prs = bestLifts().filter((l) => l.gain > 0 && diffDays(fromKey(l.history[l.history.length - 1].d), t) <= 14 && l.history[l.history.length - 1].w === l.best)
    .map((l) => ({ vjezba: l.id, kg: l.best, od: l.first }));
  return {
    generirano: new Date().toISOString(),
    zadnje_sesije: sessions,
    rekordi_nedavno: prs,
    preskocene: Object.entries(st.logs).filter(([, list]) => list.some((l) => l.skipped)).map(([id]) => id),
    profil: { ime: USER.name, dob: 19, visina_cm: USER.heightCm, pocetna_kg: USER.weightKg, pocetak: st.startDate, tjedan: Math.max(0, Math.min(w, TOTAL_WEEKS)), faza: phaseOfWeek(w).name, oprema: 'bučice (lakše i srednje), traka do 6 km/h, podloga, stolica' },
    danas: { datum: keyOf(t), plan: today_s.title, odradeno: !!st.done[keyOf(t)], vjezbe: today_s.items?.map((i) => i.ex) },
    trening: {
      ukupno: tot.all, snaga: tot.strength, setnje_traka: tot.walk, istezanja: tot.mobility, planirano_tjedno: 5,
      ovaj_tjedan: `${wp.completed}/${wp.planned}`, niz: sk.current, najduzi_niz: sk.best,
      zadnji: last || null, dana_od_zadnjeg: last ? diffDays(fromKey(last), t) : null,
      minuta_ukupno: walkMin + strengthMin,
    },
    vjezbe: ex,
    zamjene: st.swaps,
    dobrobit: {
      checkini: st.checkins.slice(-7).map((c) => ({ d: c.d.slice(5), energija: c.energy, raspolozenje: c.mood })),
      osjecaj_nakon_treninga: Object.entries(st.done).filter(([, v]) => v.feel).slice(-5).map(([k, v]) => `${k.slice(5)} ${v.feel}`),
      tezina_trend: (() => { const ws = st.checkins.filter((c) => c.weight).map((c) => c.weight); return ws.length >= 2 ? (ws[ws.length - 1] - ws[0] > 0.2 ? 'raste' : ws[ws.length - 1] - ws[0] < -0.2 ? 'pada' : 'stabilna') : 'nema podataka'; })(),
      biljeske: notes,
    },
    spremljeno: st.saved.slice(0, 12),
    ne_voli: st.memory.filter((m) => /ne voli|ne jede|alergi/i.test(m.text)).map((m) => m.text),
    pamtim: st.memory.map((m) => m.text),
  };
}

// ── Raščlamba odgovora ──

export function visibleText(raw) {
  let cut = raw.length;
  for (const m of ['[[', '<memory', '<mem']) { const i = raw.indexOf(m); if (i >= 0) cut = Math.min(cut, i); }
  // ne prikazuj nedovršeni početak oznake na kraju streama
  const tail = raw.slice(Math.max(0, cut - 8), cut);
  const partial = tail.match(/(\[|<m?e?m?o?r?y?)$/);
  if (partial && cut === raw.length) cut -= partial[0].length;
  return raw.slice(0, cut).replace(/\*\*(.+?)\*\*/g, '$1').replace(/^#+\s*/gm, '').trim();
}

export function parseReply(raw) {
  const text = visibleText(raw);
  let mood = null;
  const actions = [];
  const mm = raw.match(/\[\[mood:([a-z]+)\]\]/i);
  if (mm && MOODS_ALLOWED.includes(mm[1].toLowerCase())) mood = mm[1].toLowerCase();
  for (const m of raw.matchAll(/\[\[action:(\{.*?\})\]\]/g)) {
    try { const a = validateAction(JSON.parse(m[1])); if (a && actions.length < 2 && !actions.some((x) => x.id === a.id)) actions.push(a); } catch { /* odbaci */ }
  }
  let memory = { add: [], remove: [] };
  const mem = raw.match(/<memory>([\s\S]*?)<\/memory>/i);
  if (mem) {
    try {
      const j = JSON.parse(mem[1]);
      memory = {
        add: (Array.isArray(j.add) ? j.add : []).filter((x) => typeof x === 'string').map((x) => x.slice(0, 120)).slice(0, 3),
        remove: (Array.isArray(j.remove) ? j.remove : []).filter((x) => typeof x === 'string').slice(0, 3),
      };
    } catch { /* odbaci */ }
  }
  return { text, mood, actions, memory };
}

// ── Prepoznavanje osjetljivih tema (radi se lokalno, bez AI-ja) ──

const PARTS = [
  ['koljen', 'koljeno'], ['leđ', 'leđa'], ['led', 'leđa'], ['ramen', 'rame'], ['kuk', 'kuk'], ['vrat', 'vrat'],
  ['zglob', 'zglob'], ['gležanj', 'gležanj'], ['glezanj', 'gležanj'], ['lakat', 'lakat'], ['lakt', 'lakat'], ['šak', 'šaka'],
];

export function detectCare(text) {
  const t = text.toLowerCase();
  if (/(ne jedem|preskač\w* obrok|preskac\w* obrok|bojim se (jesti|hrane)|strah od hrane|krivnj\w* (kad|nakon) jed|povraća|povraca|gladuj|previše sam pojela|debel[ao]|smršav|smrsav|izgubiti kil|brojim kalorije)/.test(t)) return { kind: 'food' };
  if (/(vrtoglav|nesvjest|mučnin|mucnin|crni mi se|srce mi lupa|ne mogu disati)/.test(t)) return { kind: 'dizzy' };
  if (/(boli|bol\b|bolove|ozlijed|ozljed|istegnul|uganul|probada|žulja)/.test(t)) {
    const side = /lijev/.test(t) ? 'lijevo ' : /desn/.test(t) ? 'desno ' : '';
    const part = PARTS.find(([k]) => t.includes(k))?.[1] || null;
    return { kind: 'pain', part, side };
  }
  if (/(tužn|tuzn|loš dan|los dan|ne ide mi|nemam volje|umorn|iscrplj|ne mogu više|odustat)/.test(t)) return { kind: 'low' };
  return null;
}

const PAIN_SWAP = { koljeno: ['goblet-squat', 'reverse-lunge'], 'leđa': ['rdl', 'one-arm-row'], rame: ['ohp', 'floor-press', 'lateral-raise'], kuk: ['reverse-lunge', 'goblet-squat'], zglob: ['plank', 'floor-press'], lakat: ['triceps-ext', 'biceps-curl'] };

export function painExercise(part) {
  const todays = sessionFor(today()).items?.map((i) => i.swappedFrom || i.ex) || [];
  const cands = PAIN_SWAP[part] || [];
  return cands.find((c) => todays.includes(c)) || cands[0] || null;
}

// Fiksni, provjereni odgovori za osjetljive trenutke (namjerno bez AI-ja).
export function careReply(care) {
  if (care.kind === 'food') {
    return { text: 'Hvala ti što si mi to rekla, to traži hrabrost. 💛 Tvoje tijelo zaslužuje hranu i brigu, svaki dan. O ovome je dobro popričati s nekim od povjerenja, liječnikom ili nutricionistom. Oni ti mogu stvarno pomoći. Tu sam ako želiš samo popričati.', mood: 'caring', actions: [] };
  }
  if (care.kind === 'dizzy') {
    return { text: 'Odmah stani i sjedni ili lezi, i popij malo vode. Danas nema više treninga. Ako se ne smiri ili se ponavlja, javi se liječniku ili nekome blizu sebe. Brinem se za tebe. 💛', mood: 'caring', actions: [] };
  }
  if (care.kind === 'pain') {
    const where = care.part ? `${care.side}${care.part}` : 'to mjesto';
    const ex = painExercise(care.part);
    const actions = [ex ? { id: 'swap', ex } : { id: 'swap' }, { id: 'add_note' }];
    return {
      text: `Žao mi je što te boli ${where}. 💛 Ne guraj kroz bol. Vježbe koje tamo bole možemo zamijeniti nečim nježnijim. Ako bol ne prođe za par dana, oštra je ili otiče, javi se liječniku ili fizioterapeutu.`,
      mood: 'caring', actions,
      memory: care.part ? `Boli je ${care.side}${care.part}`.trim() : null,
    };
  }
  return null;
}

// ── Lokalna rezerva (bez ključa ili kad API ne radi) ──

export function localReply(text) {
  const t = text.toLowerCase();
  const sn = snapshot();
  const care = detectCare(text);
  if (care && care.kind !== 'low') return careReply(care);
  if (/^(lako|taman|teško|tesko)$/.test(t.trim())) {
    const r = { lako: 'Super! Kad je lako u svim serijama, sljedeći put možeš uzeti malo težu bučicu. 💪', taman: 'Savršeno, to je točno ono što želimo: izazovno, ali s lijepom formom.', teško: 'Bravo što si izdržala! Ako je bilo preteško, idući put uzmi malo lakšu bučicu ili napravi seriju manje. Svaki trening se računa.' }[t.trim().replace('tesko', 'teško')];
    return { text: r, mood: t.includes('lak') ? 'excited' : 'proud', actions: [{ id: 'add_note' }] };
  }
  if (care?.kind === 'low' || /ne ide mi/.test(t)) {
    return { text: 'Razumijem, i to je sasvim u redu. Danas probaj samo kratku verziju od 15 minuta. Ako ni to ne ide, odmor je također dio plana. Sutra je novi dan. 💛', mood: 'caring', actions: [{ id: 'start_short' }] };
  }
  if (/jed|hran|doručak|ručak|večer|grickal|gladn/.test(t)) {
    const dis = sn.ne_voli.join(' ').toLowerCase();
    const ok = (f) => !dis || !f.items.toLowerCase().split(/[ ,]+/).some((w) => w.length > 3 && dis.includes(w));
    const b = pick(FOOD.breakfast.filter(ok), new Date().getDate());
    const m = pick(FOOD.meals.filter(ok), new Date().getDate() + 2);
    const s = pick(FOOD.snacks.filter(ok), new Date().getDate() + 5);
    return { text: `Prijedlog za danas: za doručak ${b.name.toLowerCase()}, za ručak ${m.name.toLowerCase()}, a između obroka ${s.name.toLowerCase()}. Jedi redovito, svaka 3–4 sata. Hrana je gorivo za jačanje.`, mood: 'happy', actions: [{ id: 'save', key: `food:${m.id}` }] };
  }
  if (/napred|koliko|statist|rekord|kilaž|snag/.test(t)) {
    const tr = sn.trening;
    if (!tr.ukupno) return { text: 'Još nemam tvojih treninga, pa nemam što izračunati. Nakon prvog treninga ovdje ću ti pokazati brojke. 💪', mood: 'encouraging', actions: [{ id: 'open_today' }] };
    const lift = bestLifts().find((l) => l.gain > 0);
    return { text: `Do sada: ${tr.ukupno} aktivnosti (${tr.snaga} snage, ${tr.setnje_traka} šetnji). Ovaj tjedan ${tr.ovaj_tjedan}, niz ${tr.niz}, najduži niz ${tr.najduzi_niz}.${lift ? ` ${lift.name}: s ${String(lift.first).replace('.', ',')} na ${String(lift.best).replace('.', ',')} kg!` : ''}`, mood: lift ? 'proud' : 'happy', actions: [{ id: 'show_progress' }] };
  }
  if (/zamijen|zamjen|ne volim .*vježb|teško mi je/.test(t)) {
    return { text: 'Možemo zamijeniti vježbu koja ti ne paše. Izaberi koju, a ja ću predložiti nježniju.', mood: 'encouraging', actions: [{ id: 'swap' }] };
  }
  if (/(objasni|kako se radi|forma|tehnik)/.test(t)) {
    const exm = EXERCISES.find((e) => t.includes(e.name.toLowerCase().split(' ')[0].slice(0, 5)));
    if (exm) return { text: `${exm.name}: ${exm.cues.join('. ')}. Pazi da ne ${exm.mistakes[0].toLowerCase()}.`, mood: 'thinking', actions: [{ id: 'save', key: `ex:${exm.id}` }] };
  }
  return { text: 'Tu sam! Mogu ti predložiti što pojesti, pokazati napredak ili zamijeniti vježbu koja ne paše. Za razgovor bez ograničenja Buddy treba biti spojen na internet.', mood: 'happy', actions: [{ id: 'open_today' }] };
}

// ── Poruke koje Buddy šalje sam (izračunate lokalno, brojke su uvijek točne) ──

export function openingLine() {
  const sn = snapshot();
  const tr = sn.trening;
  const lift = bestLifts().find((l) => l.gain > 0 && l.history[l.history.length - 1].w === l.best && diffDays(fromKey(l.history[l.history.length - 1].d), today()) <= 3);
  if (!tr.ukupno) return { text: `Bok Dora! Ja sam Mrvica, tvoj Buddy. Prvi tjedan je za upoznavanje pokreta, bez žurbe. Pitaj me bilo što o treningu, hrani ili kako se osjećaš.`, mood: 'happy' };
  if (lift) return { text: `${lift.name}: ${String(lift.best).replace('.', ',')} kg! To je ${String(lift.gain).replace('.', ',')} kg više nego na prvom treningu. Ponosna sam na tebe. 💪`, mood: 'proud' };
  if (tr.dana_od_zadnjeg >= 4) return { text: `Drago mi je da si tu! Prošlo je ${tr.dana_od_zadnjeg} dana od zadnjeg treninga, i to je u redu. Krenimo lagano, kratka verzija je odličan povratak.`, mood: 'shy', actions: [{ id: 'start_short' }] };
  if (tr.niz >= 3) return { text: `${tr.niz} aktivnosti zaredom! Ovaj tjedan ${tr.ovaj_tjedan}. Kako se osjećaš danas?`, mood: 'excited' };
  return { text: `Bok! Ovaj tjedan imaš ${tr.ovaj_tjedan} odrađenog. Danas je na rasporedu: ${sn.danas.plan.toLowerCase()}. Kako si?`, mood: 'happy' };
}

export function weeklyRecap() {
  const st = store.get();
  const mon = startMonday();
  const t = today();
  const w = weekOf(t) - 1;
  if (w < 1) return null;
  const from = new Date(mon); from.setDate(from.getDate() + (w - 1) * 7);
  let done = 0, planned = 0;
  for (let i = 0; i < 7; i++) {
    const d = new Date(from); d.setDate(d.getDate() + i);
    const s = sessionFor(d);
    if (s.type !== 'rest') { planned++; if (st.done[keyOf(d)]) done++; }
  }
  const ci = st.checkins.filter((c) => c.d >= keyOf(from)).slice(-1)[0];
  const energy = ci ? ENERGY.find((e) => e.v === ci.energy)?.l.toLowerCase() : null;
  const text = done === 0
    ? `Tjedan ${w} je iza nas. Nije bilo treninga, i to je u redu. Ovaj tjedan krećemo ispočetka, zajedno. 💛`
    : `Tjedan ${w} gotov: ${done} od ${planned} planiranih aktivnosti${energy ? `, energija ${energy}` : ''}. ${done >= planned ? 'Puni tjedan, svaka čast!' : 'Svaka odrađena se računa.'}`;
  return { text, mood: done >= planned ? 'celebrating' : done ? 'proud' : 'encouraging', actions: [{ id: 'show_progress' }], kind: 'recap', week: w };
}

export { ENERGY, MOODS, SWAPS };
