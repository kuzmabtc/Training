// Tolerantni klijent za Buddy backend (Val Town). Prihvaća JSON ili stream i normalizira nazive polja,
// jer točan oblik odgovora nije poznat unaprijed. Nikad ne ispisuje URL ni tajnu u konzolu.

import { BUDDY_API_URL, APP_SECRET, TELEGRAM_BOT_USERNAME } from './config.js';

const isSet = (v) => typeof v === 'string' && v.length > 3 && !v.startsWith('PASTE_');
export const configured = () => isSet(BUDDY_API_URL) && isSet(APP_SECRET);
export const telegramUser = () => (isSet(TELEGRAM_BOT_USERNAME) ? TELEGRAM_BOT_USERNAME.replace(/^@/, '') : null);
export const apiOrigin = () => { try { return configured() ? new URL(BUDDY_API_URL).origin : null; } catch { return null; } };

const base = () => BUDDY_API_URL.replace(/\/+$/, '');

async function call(path, { method = 'GET', body, signal, timeout = 20000, raw = false } = {}) {
  if (!configured()) throw new Error('not-configured');
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeout);
  signal?.addEventListener('abort', () => ctl.abort());
  try {
    const res = await fetch(base() + path, {
      method,
      signal: ctl.signal,
      headers: { 'x-app-secret': APP_SECRET, ...(body ? { 'Content-Type': 'application/json' } : {}), Accept: 'application/json, text/event-stream, text/plain' },
      body: body ? JSON.stringify(body) : undefined,
      cache: 'no-store',
    });
    if (!res.ok) throw new Error(`http-${res.status}`);
    if (raw) return res;
    const type = res.headers.get('content-type') || '';
    if (type.includes('json')) return res.json();
    const txt = await res.text();
    try { return JSON.parse(txt); } catch { return txt; }
  } finally { clearTimeout(t); }
}

// ── Normalizacija ──

const pickText = (o) => {
  if (o == null) return '';
  if (typeof o === 'string') return o;
  return o.reply ?? o.text ?? o.content ?? o.message?.content ?? (typeof o.message === 'string' ? o.message : null) ?? o.answer ?? o.output ?? o.response ?? o.choices?.[0]?.message?.content ?? '';
};

const toTs = (v) => {
  if (v == null) return null;
  if (typeof v === 'number') return v < 1e12 ? v * 1000 : v;
  const n = Date.parse(v);
  return Number.isNaN(n) ? null : n;
};

const ROLE = (r) => (/^(user|human|dora|me)$/i.test(String(r || '')) ? 'user' : 'buddy');

export function normMessage(m, i = 0) {
  if (!m || typeof m !== 'object') return null;
  const text = String(pickText(m) || '').trim();
  if (!text) return null;
  const ts = toTs(m.created_at ?? m.createdAt ?? m.timestamp ?? m.ts ?? m.time ?? m.date) ?? Date.now() - 1000 * (1000 - i);
  const source = String(m.source ?? m.channel ?? m.via ?? 'web').toLowerCase();
  const id = String(m.id ?? m._id ?? m.message_id ?? `${ts}-${text.length}-${i}`);
  return {
    id: `s-${id}`, sid: id, role: ROLE(m.role ?? m.sender ?? m.from ?? m.author), text, ts,
    source: /tele/.test(source) ? 'telegram' : /proact|cron|auto|nudge|recap|system/.test(source) || m.proactive ? 'proactive' : 'web',
    proactive: !!m.proactive || /proact|cron|nudge|recap/.test(source),
    mood: m.mood || null,
  };
}

const listOf = (d, keys) => {
  if (Array.isArray(d)) return d;
  for (const k of keys) if (Array.isArray(d?.[k])) return d[k];
  return [];
};

export async function getHistory(limit = 50) {
  const d = await call(`/history?limit=${limit}`);
  return listOf(d, ['messages', 'history', 'items', 'data', 'results']).map(normMessage).filter(Boolean).sort((a, b) => a.ts - b.ts);
}

export function normFact(f, i) {
  if (typeof f === 'string') return { id: `idx-${i}`, text: f, noId: true };
  const text = String(f?.text ?? f?.fact ?? f?.content ?? f?.value ?? '').trim();
  if (!text) return null;
  return { id: String(f.id ?? f._id ?? f.key ?? `idx-${i}`), text, noId: f.id == null && f._id == null && f.key == null };
}

export async function getMemory() {
  const d = await call('/memory');
  return listOf(d, ['memory', 'facts', 'items', 'data']).map(normFact).filter(Boolean);
}
export const addMemoryApi = (text) => call('/memory', { method: 'POST', body: { text, fact: text } });
export const deleteMemoryApi = (id) => call(`/memory/${encodeURIComponent(id)}`, { method: 'DELETE' });

export const syncSnapshot = (snapshot) => call('/sync', { method: 'POST', body: snapshot, timeout: 10000 });

export async function getStatus() {
  try {
    const d = await call('/status', { timeout: 8000 });
    if (d && typeof d === 'object' && typeof d.connected === 'boolean') return d;
  } catch { /* nema /status: stanje se ne prikazuje */ }
  return null;
}

// POST /chat: podržava JSON, SSE stream (OpenAI-stil ili {delta}/{text}) i obični tekstualni stream.
export async function chat(message, { onDelta, signal } = {}) {
  const res = await call('/chat', { method: 'POST', body: { message }, signal, raw: true, timeout: 60000 });
  const type = res.headers.get('content-type') || '';
  if (type.includes('json')) {
    const d = await res.json();
    return { text: String(pickText(d) || ''), mood: d?.mood || null, actions: Array.isArray(d?.actions) ? d.actions : [], id: d?.id ?? d?.message_id ?? null };
  }
  if (!res.body) {
    const t = await res.text();
    return { text: t, mood: null, actions: [] };
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  const sse = type.includes('event-stream');
  let buf = '', full = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    const chunk = dec.decode(value, { stream: true });
    if (!sse) { full += chunk; onDelta?.(full); continue; }
    buf += chunk;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (!data || data === '[DONE]') continue;
      let piece = '';
      try {
        const j = JSON.parse(data);
        if (j.error) throw new Error('api');
        piece = j.choices?.[0]?.delta?.content ?? j.delta ?? j.token ?? (j.done ? '' : j.text ?? j.content ?? '');
        if (j.reply && !full) piece = j.reply; // završna poruka s cijelim tekstom
      } catch (e) {
        if (e.message === 'api') throw e;
        piece = data;
      }
      if (piece) { full += piece; onDelta?.(full); }
    }
  }
  if (!full.trim()) throw new Error('empty');
  return { text: full, mood: null, actions: [] };
}
