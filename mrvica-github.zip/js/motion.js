// Jedan mali pomoćnik za pokret. Sve opruge (spring) i krivulje su ovdje i u CSS tokenima (--ease-*),
// tako da cijela aplikacija ima isti osjećaj. iOS vrijednosti: krutost ~300, prigušenje ~30.

export const SPRINGS = {
  default: { stiffness: 300, damping: 30, ms: 660 },
  bouncy: { stiffness: 380, damping: 16, ms: 1190 },
  snappy: { stiffness: 520, damping: 42, ms: 500 },
  gentle: { stiffness: 220, damping: 28, ms: 650 },
};

export const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const supportsLinear = (() => {
  try { return CSS.supports('animation-timing-function', 'linear(0, 1)'); } catch { return false; }
})();

const FALLBACK = {
  default: 'cubic-bezier(0.22, 1, 0.36, 1)',
  bouncy: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
  snappy: 'cubic-bezier(0.2, 0.9, 0.3, 1)',
  gentle: 'cubic-bezier(0.32, 0.72, 0, 1)',
};

export function easing(name = 'default') {
  if (!supportsLinear) return FALLBACK[name] || FALLBACK.default;
  const v = getComputedStyle(document.documentElement).getPropertyValue(`--ease-${name}`).trim();
  return v || FALLBACK[name];
}

// Web Animations API s oprugom; pod smanjenim pokretom samo kratki crossfade ili ništa.
export function animate(el, keyframes, { spring = 'default', duration, delay = 0, fill = 'both' } = {}) {
  if (!el?.animate) return { finished: Promise.resolve() };
  if (reduced()) {
    const last = keyframes[keyframes.length - 1];
    const op = 'opacity' in last ? [{ opacity: keyframes[0].opacity ?? 1 }, { opacity: last.opacity }] : null;
    return op ? el.animate(op, { duration: 120, fill }) : { finished: Promise.resolve() };
  }
  return el.animate(keyframes, { duration: duration || SPRINGS[spring].ms, delay, easing: easing(spring), fill });
}

// Postupni ulazak elemenata liste (stagger).
export function stagger(els, { step = 35, max = 10, y = 12 } = {}) {
  if (reduced()) return;
  [...els].forEach((el, i) => {
    animate(el, [{ opacity: 0, transform: `translateY(${y}px) scale(0.98)` }, { opacity: 1, transform: 'none' }], { delay: Math.min(i, max) * step, fill: 'backwards' });
  });
}

// Fizička opruga za geste (povlačenje sheeta, maskota). Vraća stop().
export function springTo(from, to, onUpdate, { stiffness = 300, damping = 30, mass = 1, velocity = 0, onDone } = {}) {
  if (reduced()) { onUpdate(to); onDone?.(); return () => {}; }
  let x = from, v = velocity, last = performance.now(), raf;
  const tick = (now) => {
    const dt = Math.min(0.032, (now - last) / 1000);
    last = now;
    const steps = 4;
    for (let i = 0; i < steps; i++) {
      const a = (-stiffness * (x - to) - damping * v) / mass;
      v += a * (dt / steps);
      x += v * (dt / steps);
    }
    onUpdate(x);
    if (Math.abs(x - to) < 0.2 && Math.abs(v) < 0.5) { onUpdate(to); onDone?.(); return; }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
  return () => cancelAnimationFrame(raf);
}

// iOS-ov otpor gumice kad se vuče preko ruba.
export const rubberband = (dist, dim = 400, c = 0.55) => (dist * dim * c) / (dim + c * Math.abs(dist)) * Math.sign(dist || 1);

// Brojke koje se "odbroje" do vrijednosti.
export function countUp(el, to, { ms = 700, decimals = 0 } = {}) {
  if (!el) return;
  const fmt = (n) => String(Number(n.toFixed(decimals))).replace('.', ',');
  if (reduced() || !to) { el.textContent = fmt(to); return; }
  const t0 = performance.now();
  const step = (t) => {
    const p = Math.min(1, (t - t0) / ms);
    const e = 1 - Math.pow(1 - p, 3);
    el.textContent = fmt(to * e);
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

// Pritisak: 0.97 dolje, opruga natrag. Delegirano za cijeli dokument.
export function installPress(root = document) {
  // svaki element koji se može tapnuti: pritisak ga stisne, opruga ga vrati
  const SEL = '.btn, .tappable, .chip, .icon-btn, .tab, .st-btn, .ex-open, .press, .segmented button, button.list-row, a.list-row, .list-row.tappable, [data-day], [data-ex], [data-act], .emoji-scale button, .send-btn, .topbar-btn, .wd[data-day], .glass-card[role="button"]';
  let pressed = null;
  root.addEventListener('pointerdown', (e) => {
    const el = e.target.closest(SEL);
    if (!el || el.disabled || el.closest('[data-nopress]') || reduced()) return;
    pressed = el;
    const w = el.getBoundingClientRect().width;
    // velike kartice se stisnu manje, mali gumbi više (kao na iOS-u)
    const s = el.classList.contains('icon-btn') || el.classList.contains('st-btn') || w < 56 ? 0.88 : w > 220 ? 0.975 : 0.95;
    el.style.transition = `transform 140ms ${FALLBACK.snappy}`;
    el.style.transform = `scale(${s})`;
  }, { passive: true });
  const release = () => {
    if (!pressed) return;
    const el = pressed;
    pressed = null;
    el.style.transition = `transform ${SPRINGS.bouncy.ms}ms ${easing('bouncy')}`;
    el.style.transform = '';
    setTimeout(() => { if (el.style.transform === '') el.style.transition = ''; }, SPRINGS.bouncy.ms);
  };
  root.addEventListener('pointerup', release, { passive: true });
  root.addEventListener('pointercancel', release, { passive: true });
  root.addEventListener('pointerleave', release, { passive: true });
}

// Prijelaz između ekrana: View Transitions API ako postoji, inače CSS crossfade.
let vtBroken = false;
export function viewTransition(update, el) {
  if (reduced()) { update(); return; }
  // WebGL staklo čini snimke prijelaza skupima, pa tada koristimo lakši CSS prijelaz
  if (document.startViewTransition && !vtBroken && document.documentElement.dataset.glass !== 'liquid') {
    let ran = false;
    const u = () => { if (ran) return; ran = true; update(); };
    try {
      const vt = document.startViewTransition(u);
      vt.ready.catch(() => { vtBroken = true; u(); });
      vt.finished.catch(() => {});
      // ako preglednik ne stigne (spori GPU), prekini i prebaci se na CSS prijelaz
      setTimeout(() => { if (!ran) { vtBroken = true; try { vt.skipTransition(); } catch { /* */ } u(); } }, 350);
      return;
    } catch { /* nastavi na rezervu */ }
  }
  update();
  if (el) animate(el, [{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { spring: 'default', fill: 'none' });
}

// Kratka vibracija gdje je podržana (Android). iOS je ne podržava pa se tiho preskače.
export function tick(kind = 'light') {
  try { navigator.vibrate?.(kind === 'success' ? [12, 40, 18] : kind === 'heavy' ? 22 : 8); } catch { /* */ }
}
