// Spremanje stanja u localStorage (uz rezervu u memoriji ako pohrana nije dostupna).

const KEY = 'dora.trening.v1';
let memory = null;
const listeners = new Set();

const blank = () => ({
  v: 1,
  onboarded: false,
  startDate: null,
  done: {},       // 'YYYY-MM-DD' → { kind, short, at }
  logs: {},       // exId → [{ d, sets: [{ w, r }], note }]
  checkins: [],   // [{ d, energy, mood, weight }]
  saved: [],      // ['ex:goblet-squat', 'food:b1', 'tip:t3', ...]
  badges: {},     // id → 'YYYY-MM-DD'
  showWeight: false,
  chat: [],       // [{ id, role: 'user'|'buddy', text, ts, mood, actions, kind }]
  memory: [],     // [{ id, text, ts }] trajne činjenice koje je Buddy naučio
  swaps: {},      // exId → zamjenska vježba
  notes: [],      // [{ id, d, text }] bilješke i spremljene Buddy poruke
  buddy: {},      // { lastOpen, recapWeek, lastAsk }
});

function read() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...blank(), ...JSON.parse(raw) };
  } catch { /* privatni način rada ili blokirana pohrana */ }
  return memory ? { ...memory } : blank();
}

let state = read();

function write() {
  memory = state;
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch { /* nastavljamo u memoriji */ }
}

export const store = {
  get: () => state,
  set(patch) {
    state = { ...state, ...(typeof patch === 'function' ? patch(state) : patch) };
    write();
    listeners.forEach((fn) => fn(state));
  },
  subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  reset() {
    state = { ...blank(), onboarded: true, startDate: state.startDate };
    write();
    listeners.forEach((fn) => fn(state));
  },
  persistent() {
    try { localStorage.setItem('dora.ping', '1'); localStorage.removeItem('dora.ping'); return true; } catch { return false; }
  },
};

// ── Spremljeno ──

export const isSaved = (key) => store.get().saved.includes(key);
export function toggleSaved(key) {
  const saved = store.get().saved;
  const next = saved.includes(key) ? saved.filter((k) => k !== key) : [key, ...saved];
  store.set({ saved: next });
  return next.includes(key);
}

// ── Treninzi ──

export function markDone(dateKey, kind, extra = {}) {
  const done = { ...store.get().done, [dateKey]: { kind, at: Date.now(), ...extra } };
  store.set({ done });
}

export function unmarkDone(dateKey) {
  const done = { ...store.get().done };
  delete done[dateKey];
  store.set({ done });
}

export function addLog(exId, entry) {
  const logs = { ...store.get().logs };
  const list = (logs[exId] || []).filter((l) => l.d !== entry.d);
  list.push(entry);
  list.sort((a, b) => a.d.localeCompare(b.d));
  logs[exId] = list;
  store.set({ logs });
}

export function lastLog(exId, beforeKey) {
  const list = store.get().logs[exId] || [];
  for (let i = list.length - 1; i >= 0; i--) if (!beforeKey || list[i].d < beforeKey) return list[i];
  return null;
}

export function addCheckin(entry) {
  const list = store.get().checkins.filter((c) => c.d !== entry.d);
  list.push(entry);
  list.sort((a, b) => a.d.localeCompare(b.d));
  store.set({ checkins: list });
}

// ── Buddy ──

const rid = () => Math.random().toString(36).slice(2, 9);

export function addChat(msg) {
  const chat = [...store.get().chat, { id: rid(), ts: Date.now(), ...msg }].slice(-100);
  store.set({ chat });
  return chat[chat.length - 1];
}

export function updateChat(id, patch) {
  store.set({ chat: store.get().chat.map((m) => (m.id === id ? { ...m, ...patch } : m)) });
}

export function addMemory(text) {
  const t = String(text || '').trim().slice(0, 120);
  if (!t) return false;
  const mem = store.get().memory;
  if (mem.some((m) => m.text.toLowerCase() === t.toLowerCase())) return false;
  store.set({ memory: [...mem, { id: rid(), text: t, ts: Date.now() }].slice(-20) });
  return true;
}

export function removeMemory(idOrText) {
  store.set({ memory: store.get().memory.filter((m) => m.id !== idOrText && m.text.toLowerCase() !== String(idOrText).toLowerCase()) });
}

export function editMemory(id, text) {
  store.set({ memory: store.get().memory.map((m) => (m.id === id ? { ...m, text: text.slice(0, 120) } : m)) });
}

export function setSwap(exId, to) {
  const swaps = { ...store.get().swaps };
  if (to) swaps[exId] = to; else delete swaps[exId];
  store.set({ swaps });
}

export function addNote(text, d) {
  const notes = [{ id: rid(), d, text: String(text).slice(0, 600) }, ...store.get().notes].slice(0, 100);
  store.set({ notes });
  return notes[0];
}
