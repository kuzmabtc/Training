// Pomoćne funkcije: datumi, HTML, haptika.

export const DAYS = ['nedjelja', 'ponedjeljak', 'utorak', 'srijeda', 'četvrtak', 'petak', 'subota'];
export const DAYS_SHORT = ['P', 'U', 'S', 'Č', 'P', 'S', 'N']; // od ponedjeljka
export const DAYS_MON = ['Ponedjeljak', 'Utorak', 'Srijeda', 'Četvrtak', 'Petak', 'Subota', 'Nedjelja'];
export const MONTHS_GEN = ['siječnja', 'veljače', 'ožujka', 'travnja', 'svibnja', 'lipnja', 'srpnja', 'kolovoza', 'rujna', 'listopada', 'studenoga', 'prosinca'];

export const pad = (n) => String(n).padStart(2, '0');
export const keyOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const fromKey = (k) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
export const today = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
export const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
export const dayIdx = (d) => (d.getDay() + 6) % 7; // ponedjeljak = 0
export const mondayOf = (d) => addDays(d, -dayIdx(d));
export const diffDays = (a, b) => Math.round((b - a) / 86400000);

export function fmtDate(d, withDay = true) {
  const s = `${d.getDate()}. ${MONTHS_GEN[d.getMonth()]}`;
  if (!withDay) return s;
  const day = DAYS[d.getDay()];
  return `${day[0].toUpperCase() + day.slice(1)}, ${s}`;
}
export const fmtShort = (d) => `${d.getDate()}. ${d.getMonth() + 1}.`;

export function fmtTime(secs) {
  const s = Math.max(0, Math.round(secs));
  return `${Math.floor(s / 60)}:${pad(s % 60)}`;
}

export function fmtMin(secs) {
  return `${Math.round(secs / 60)} min`;
}

export const fmtKg = (n) => `${String(Math.round(n * 10) / 10).replace('.', ',')} kg`;

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function html(str) {
  const t = document.createElement('template');
  t.innerHTML = str.trim();
  return t.content.firstElementChild;
}

export const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// Haptika: Android preko vibrate, iOS 18+ preko skrivenog "switch" prekidača.
let hapticLabel;
export function haptic(kind = 'light') {
  try {
    if (navigator.vibrate) {
      navigator.vibrate(kind === 'success' ? [12, 40, 18] : kind === 'heavy' ? 20 : 8);
      return;
    }
    if (!hapticLabel) {
      hapticLabel = document.createElement('label');
      hapticLabel.setAttribute('aria-hidden', 'true');
      hapticLabel.style.cssText = 'position:fixed;left:-9999px;width:1px;height:1px;overflow:hidden;';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.setAttribute('switch', '');
      input.tabIndex = -1;
      hapticLabel.append(input);
      document.body.append(hapticLabel);
    }
    hapticLabel.click();
    if (kind === 'success') setTimeout(() => hapticLabel.click(), 120);
  } catch { /* bez haptike */ }
}

export function pick(arr, seed) {
  return arr[((seed % arr.length) + arr.length) % arr.length];
}

export const plural = (n, one, few, many) => {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
};
