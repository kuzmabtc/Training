// Service worker: sve datoteke se spremaju pri prvom učitavanju, pa aplikacija radi i bez interneta.
// Na GitHub Pages sve stranice jednog korisnika dijele isti origin, pa brišemo samo svoje stare cacheve.
const PREFIX = 'dora-trening-';
const CACHE = PREFIX + 'v5';
const FILES = [
  "./",
  "assets/icons/apple-touch-icon.png",
  "assets/icons/favicon-32.png",
  "assets/icons/icon-192.png",
  "assets/icons/icon-512.png",
  "assets/icons/icon-maskable-512.png",
  "assets/icons/icon.svg",
  "css/app.css",
  "index.html",
  "js/actions.js",
  "js/ai.js",
  "js/api.js",
  "js/app.js",
  "js/config.js",
  "js/data.js",
  "js/engine.js",
  "js/glass.js",
  "js/illustrations.js",
  "js/mascot.js",
  "js/motion.js",
  "js/store.js",
  "js/sync.js",
  "js/ui/celebrate.js",
  "js/ui/charts.js",
  "js/ui/components.js",
  "js/ui/feedback.js",
  "js/ui/icons.js",
  "js/ui/sheet.js",
  "js/util.js",
  "js/vendor/liquidglass/LICENSE.txt",
  "js/vendor/liquidglass/hti/apply-style.js",
  "js/vendor/liquidglass/hti/clone-node.js",
  "js/vendor/liquidglass/hti/clone-pseudos.js",
  "js/vendor/liquidglass/hti/dataurl.js",
  "js/vendor/liquidglass/hti/embed-images.js",
  "js/vendor/liquidglass/hti/embed-resources.js",
  "js/vendor/liquidglass/hti/embed-webfonts.js",
  "js/vendor/liquidglass/hti/index.js",
  "js/vendor/liquidglass/hti/mimes.js",
  "js/vendor/liquidglass/hti/types.js",
  "js/vendor/liquidglass/hti/util.js",
  "js/vendor/liquidglass/lg/GlassRenderer.js",
  "js/vendor/liquidglass/lg/HtmlCapture.js",
  "js/vendor/liquidglass/lg/LiquidGlass.js",
  "js/vendor/liquidglass/lg/defaults.js",
  "js/vendor/liquidglass/lg/index.js",
  "js/vendor/liquidglass/lg/shaders.js",
  "js/views/buddy.js",
  "js/views/exercises.js",
  "js/views/nutrition.js",
  "js/views/plan.js",
  "js/views/progress.js",
  "js/views/saved.js",
  "js/views/today.js",
  "js/views/workout.js",
  "manifest.webmanifest",
  "robots.txt"
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith(PREFIX) && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

// Prvo cache, a u pozadini osvježi (stale-while-revalidate) za vlastite datoteke.
self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  // Buddy backend (Val Town) i sve druge domene: nikad se ne spremaju, uvijek idu na mrežu.
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  // putanja unutar aplikacije (npr. /ime-repoa/...), da ime repozitorija ne smeta
  const rel = url.pathname.slice(new URL(self.registration.scope).pathname.length);
  if (/^(chat|history|memory|sync|status|telegram|setup)(\/|$)/.test(rel)) return;
  // config.js: prvo mreža, da se nove vrijednosti odmah vide nakon ponovnog uploada
  if (url.pathname.endsWith('/js/config.js')) {
    e.respondWith(fetch(req).then((res) => { const c = res.clone(); caches.open(CACHE).then((ca) => ca.put(req, c)); return res; }).catch(() => caches.match(req)));
    return;
  }
  e.respondWith(
    caches.open(CACHE).then(async (cache) => {
      const cached = await cache.match(req, { ignoreSearch: true });
      const network = fetch(req)
        .then((res) => { if (res.ok) cache.put(req, res.clone()); return res; })
        .catch(() => null);
      if (cached) { e.waitUntil(network); return cached; }
      const res = await network;
      if (res) return res;
      if (req.mode === 'navigate') return cache.match('./index.html');
      return new Response('', { status: 504 });
    }),
  );
});
